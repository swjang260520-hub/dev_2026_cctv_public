# -*- coding: utf-8 -*-
import os.path

import LEA
import base64
import binascii
import hashlib
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from loguru import logger
# 암복호화 라이브러리 추가

class LeaUtil:

    def __init__(self):

        self.key = self.load_encryption_key()

    def encrypt(self, plain_text):
        key = self.key
        leaECB = LEA.ECB(True, key, True)
        ct = leaECB.update(bytearray(plain_text, "utf8"))
        ct += leaECB.final()
        return binascii.hexlify(ct).decode('utf-8')

    def decrypt(self, ciper_text):
        key = self.key
        leaECB = LEA.ECB(False, key, True)
        ct = binascii.unhexlify(ciper_text)
        pt = leaECB.update(ct)
        pt += leaECB.final()
        return pt.decode('utf-8')

    def load_key(self):
        secret_path = "cctv_key.bin"
        if os.path.isfile(secret_path):
            with open(secret_path, 'r') as f:
                secret_key = f.read()
        else:
            logger.error(f'Not Found secret file - secret_path ={secret_path}')

        join_key = f"{secret_key}{self.app_key_from_mapdb()}"

        return hashlib.sha256(join_key.encode('utf-8')).digest()

    def derive_key_from_password(self, master_password, salt=None):
        if salt is None:
            salt = os.urandom(16)

        kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=10000)
        key = base64.urlsafe_b64encode(kdf.derive(master_password))

        return key, salt

    def load_encryption_key(self, key_path='cctv_key.bin'):
        """ 암호키를 복호화 함 """
        try:
            with open(key_path, 'rb') as file:
                encrpyted_key = file.readline().strip()
                salt = file.readline().strip()
                master_password = file.readline().strip()

            master_key, _ = self.derive_key_from_password(master_password, salt)

            f = Fernet(master_key)
            encryption_key = f.decrypt(encrpyted_key)

            return encryption_key

        except Exception as e:
            logger.error(f"load encrytion key error : {e}")
            return None


if __name__ == '__main__':
    lea = LeaUtil()
    logger.debug(f"{lea.key}")

    en = lea.encrypt('L*D@x6qMhK')
    logger.debug(f"{en}")
    de = lea.decrypt(en)
    logger.debug(f"{de}")