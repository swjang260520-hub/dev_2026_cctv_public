from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLineEdit, QComboBox, QCheckBox, QPushButton,
    QGroupBox, QDialogButtonBox, QMessageBox, QFileDialog
)
from PySide6.QtCore import Qt, QThread, Signal
import cv2
from loguru import logger

from LeaCrypto import LeaUtil
from core.models import CameraConfig
from ui.camera_dialog_ui import Ui_CameraDialog


class ConnectionTestWorker(QThread):
    """연결 테스트를 위한 백그라운드 워커"""
    result_signal = Signal(bool, str)  # success, message

    def __init__(self, source):
        super().__init__()
        self.source = source

    def run(self):
        try:
            cap = cv2.VideoCapture(self.source)
            success = cap.isOpened() and cap.read()[0]
            cap.release()
            msg = "카메라 연결 성공!" if success else "연결 실패 (주소 또는 네트워크 확인 필요)"
            self.result_signal.emit(success, msg)
        except Exception as e:
            logger.exception("ConnectionTestWorker 오류")
            self.result_signal.emit(False, f"테스트 오류: {str(e)}")


class CameraDialog(QDialog, Ui_CameraDialog):
    """카메라 추가/수정 다이얼로그"""

    def __init__(self, config: CameraConfig = None, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.config = config if config else CameraConfig()
        self._is_edit_mode = config is not None

        self.setupUi(self)

        # 20260528 swjang 다이얼로그창에 확인, 취소를 한글로 표시하고, 삭제 버튼 추가
        self.buttonBox.button(QDialogButtonBox.Ok).setText('확인')
        self.buttonBox.button(QDialogButtonBox.Cancel).setText('취소')

        # 20260528 swjang 삭제 버튼 클릭시 행 삭제하고 창 닫기
        self.delete_btn = self.buttonBox.addButton('삭제', QDialogButtonBox.ActionRole)
        self.delete_btn.clicked.connect(self._on_delete_clicked)

        self.delete_btn.setEnabled(self._is_edit_mode)

        # 20260520 swjang 카메라 추가시 pwd를 암/복호화 기능 추가, camears_info.json에 암호화해서 저장
        self.lea = LeaUtil()

        self.autostart_check = QCheckBox("프로그램 시작 시 자동 실행")
        self.optionsLayout.addWidget(self.autostart_check)

        self.test_worker = None

        self._load_config()
        self._signal_and_slot()


    def _signal_and_slot(self):
        self.type_combo.currentIndexChanged.connect(self._on_type_changed)
        self.browse_btn.clicked.connect(self._on_browse)
        self.test_btn.clicked.connect(self._on_test_connection)

    def _load_config(self):
        """설정 로드"""
        self.name_edit.setText(self.config.name)

        type_map = {"rtsp": 0, "http": 1, "usb": 2, "file": 3}
        self.type_combo.setCurrentIndex(type_map.get(self.config.source_type, 0))

        self.address_edit.setText(self.config.source)
        self.username_edit.setText(self.config.username)

        encrypt_pwd = self.config.password
        if encrypt_pwd and self.lea:
            try:
                # 20260520 swjang 복호화
                decrypt_pwd = self.lea.decrypt(self.config.password)
                self.password_edit.setText(decrypt_pwd)
            except Exception as e:
                logger.error('복호화 실패')
        else:
            self.password_edit.setText(encrypt_pwd or "")

        self.display_check.setChecked(self.config.display_enabled)
        self.detection_check.setChecked(self.config.detection_enabled)
        self.autostart_check.setChecked(self.config.autostart)

        self.browse_btn.setVisible(self.type_combo.currentIndex() == 3)  # 파일인 경우만

    def _on_type_changed(self, index: int):
        """연결 유형 변경"""
        self.browse_btn.setVisible(index == 3)  # 파일인 경우만

        placeholders = [
            "rtsp://192.168.1.100:554/stream",
            "http://192.168.1.100:8080/video",
            "0 (카메라 인덱스)",
            "비디오 파일 경로"
        ]
        self.address_edit.setPlaceholderText(placeholders[index])

    def _on_browse(self):
        """파일 찾아보기"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "비디오 파일 선택", "",
            "비디오 파일 (*.mp4 *.avi *.mkv *.mov);;모든 파일 (*.*)"
        )
        if file_path:
            self.address_edit.setText(file_path)

    def _on_test_connection(self):
        """연결 테스트"""
        source = self.address_edit.text().strip()
        if not source:
            QMessageBox.warning(self, "경고", "주소를 입력하세요.")
            return

        self.test_btn.setText("🔄 테스트 중...")
        self.test_btn.setEnabled(False)

        try:
            # USB 카메라인 경우
            if self.type_combo.currentIndex() == 2:
                source = int(source) if source.isdigit() else 0
            
            # RTSP인 경우 인증 정보 결합 (임시 Config 객체 활용)
            elif self.type_combo.currentIndex() == 0: # RTSP
                temp_config = CameraConfig(
                    source=source,
                    source_type="rtsp",
                    username=self.username_edit.text().strip(),
                    password=self.password_edit.text()
                )
                source = temp_config.get_opencv_source()

            # 워커 시작
            self.test_worker = ConnectionTestWorker(source)
            self.test_worker.result_signal.connect(self._on_test_finished)
            self.test_worker.finished.connect(self.test_worker.deleteLater)
            self.test_worker.start()
            
        except Exception as e:
            QMessageBox.critical(self, "오류", f"연결 오류: {str(e)}")
            self.test_btn.setText("🔗 연결 테스트")
            self.test_btn.setEnabled(True)

    def _on_test_finished(self, success, message):
        """테스트 완료 핸들러"""
        self.test_btn.setText("🔗 연결 테스트")
        self.test_btn.setEnabled(True)
        
        if success:
            QMessageBox.information(self, "성공", message)
        else:
            QMessageBox.warning(self, "실패", message)

    def accept(self):
        """확인 버튼"""
        name = self.name_edit.text().strip()
        source = self.address_edit.text().strip()

        if not name:
            QMessageBox.warning(self, "경고", "카메라명을 입력하세요.")
            return

        if not source:
            QMessageBox.warning(self, "경고", "주소를 입력하세요.")
            return

        plain_pwd = self.password_edit.text().strip()

        if plain_pwd and self.lea:
            try:
                # 20260520 swjang 암호화
                encrypt_pwd = self.lea.encrypt(plain_pwd)
                self.config.password = encrypt_pwd
            except Exception as e:
                logger.error('암호화 실패')
        else:
            self.config.password = plain_pwd

        # 설정 업데이트
        type_map = {0: "rtsp", 1: "http", 2: "usb", 3: "file"}

        self.config.name = name
        self.config.source = source
        self.config.source_type = type_map[self.type_combo.currentIndex()]
        self.config.username = self.username_edit.text().strip()
        # self.config.password = self.password_edit.text()
        self.config.display_enabled = self.display_check.isChecked()
        self.config.detection_enabled = self.detection_check.isChecked()
        self.config.autostart = self.autostart_check.isChecked()

        super().accept()

    def get_config(self) -> CameraConfig:
        """설정 반환"""
        return self.config

    def _on_delete_clicked(self):
        logger.debug('on_delete_clicked')
        self.parent._on_delete_camera()
        self.close()
