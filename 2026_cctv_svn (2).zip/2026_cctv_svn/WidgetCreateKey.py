# -*- coding: utf-8 -*-
"""
**************************************************
** DataBase 관리 설정을 위한 코드 (프로그램 코드 X) **
**************************************************
    # 주요기능
      1) DB 계정 비밀번호에 대한 암호키 생성
      2) DB 계정 비밀번호 암호화 (저장)
      3) DB 생성 및 SQL 파일을 통한 DB 초기화 기능
      * 체계 유지보수용으로 DB 초기화에 대비한 프로그램임
      * DB 초기화를 위한 sql 파일이 있어야함 (중요!)

    2026.05.19. swjang
    1. 키 생성, 파일에 키 저장 버튼 클릭
    2. 위젯에서 키생성, 키 저장하여 cctv_key.bin 파일 생성함.
    3. 환경변수에 키 저장을 추가 필요시 구현하여 사용 필요
"""

import base64
import os
import sys

#import pymysql
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QWidget, QMessageBox, QApplication, QLineEdit, QFileDialog
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from loguru import logger

from ui.setting_db_ui import Ui_Form_Db


def encrypt_pass(key, passwd):
    """
    key 값을 통해 암호화
    :param key:
    :param passwd:
    :return:
    """
    f = Fernet(key)
    en_passwd = f.encrypt(passwd.encode())
    return en_passwd

def create_key(master_key):
    """
    key 생성
    :return: 
    """
    # return Fernet.generate_key()
    return generate_and_key(master_key)

def decrypt_pass(key, passwd):
    """
    key 값을 통해 복호화
    :param key: 
    :param passwd: 
    :return: 
    """
    f = Fernet(key)
    de_passwd = f.decrypt(passwd).decode()
    return de_passwd


def derive_key_from_password(master_password, salt=None):
    if salt is None:
        salt = os.urandom(16)

    kdf = PBKDF2HMAC(algorithm=hashes.SHA256, length=32, salt=salt, iterations=10000)
    key = base64.urlsafe_b64encode(kdf.derive(master_password))

    return key, salt

def generate_and_key(master_password):
    """ 암호화키를 생성하고 마스터비밀번호로 암호화하여 저장 """
    try:
        encryption_key = os.urandom(32)

        salt = os.urandom(16)
        master_key, salt = derive_key_from_password(master_password, salt)

        f = Fernet(master_key)
        encrypted_key = f.encrypt(encryption_key)

        return encrypted_key, salt
    except Exception as e:
        logger.error(f'generate key error : {e}')
        return None

def load_encryption_key(key_path='cctv_key.bin'):
    """ 암호키를 복호화 함 """
    try:
        with open(key_path, 'rb') as file:
            encrpyted_key = file.readline().strip()
            salt = file.readline().strip()
            master_password = file.readline().strip()

        master_key, _ = derive_key_from_password(master_password, salt)
        f = Fernet(master_key)
        encryption_key = f.decrypt(encrpyted_key)

        return encryption_key

    except Exception as e:
        logger.error(f"load encrytion key error : {e}")
        return None

def encrypt_pass_with_master(input_pass, key_path):

    encryption_key = load_encryption_key(key_path)
    logger.debug(encryption_key)
    if not encryption_key:
        return False

    f = Fernet(encryption_key)
    en_passwd = f.encrypt(input_pass.encode())

    return en_passwd

def decrypt_pass_with_master(input_pass, key_path):
    encryption_key = load_encryption_key(key_path)

    if not encryption_key:
        return False

    f = Fernet(encryption_key)
    de_passwd = f.decrypt(input_pass).decode()
    return de_passwd

class WidgetSettingDb(QWidget):
    """
    1. 암호화 key 생성 -> key값 파일에 저장 (sonarknccs_key.bin)
    2. DB 접속 비밀번호 암호화 -> 암호문 파일에 저장 (sonarknccs_db.bin)
    """

    def __init__(self, parent=None):
        super(WidgetSettingDb, self).__init__(parent)

        # 화면 구성
        self.ui = Ui_Form_Db()
        self.ui.setupUi(self)

        self._signal_and_slot()

        self.conn = None
        self.cursor = None

        self.key_filename = 'cctv_key.bin'
        self.db_filename = 'cctv_db.bin'

        logger.debug(f"CCTV_MASTER_PWD={os.getenv('CCTV_MASTER_PWD')}")

        self.master_key = os.urandom(32)
        self.createkey = ''
        self.salt = ''

        self.sql_filename = ''

        self.ui.label_createkeymsg.setText(f"키 생성 결과: -")

    def _signal_and_slot(self):
        """
        파일열기, 시작, 정지, com 열기 버튼에 대한 이벤트 연결
        :return:
        """
        self.ui.pushButton_createkey.clicked.connect(self.createkey_slot)
        self.ui.pushButton_keysave.clicked.connect(self.keysave_slot)
        self.ui.pushButton_keysave_2.clicked.connect(self.keyenv_save_slot)
        self.ui.pushButton_cryptosave.clicked.connect(self.create_crypto)
        self.ui.pushButton_validpass.clicked.connect(self.validpass_slot)
        self.ui.checkBox_pwlook.stateChanged.connect(self.ck_pw_visible_slot)
        self.ui.pushButton_db_connect.clicked.connect(self.connect_db)
        self.ui.pushButton_load_sql.clicked.connect(self.load_sql_file)
        self.ui.pushButton_init_db.clicked.connect(self.read_and_excute_sql)

    def createkey_slot(self):
        """
        키 생성 후 key.bin 파일에 값 저장
        :return:
        """
        logger.debug('createkey_slot call')
        # 1. 키 생성
        self.createkey, self.salt = create_key(self.master_key)
        self.ui.lineEdit_result.setText(f"key : {self.createkey}, salt : {self.salt}, master_key : {self.master_key}")

        self.ui.label_createkeymsg.setText(f"키 생성 결과: 완료")
        logger.debug(f"create_key : {self.createkey}")

    def keysave_slot(self):
        """
        비밀번호 암호화 처리
        비밀번호를 암호화하고 파일에 저장
        :return:
        """
        # 파일에 저장
        if self.createkey != '':
            with open(self.key_filename, 'wb') as key_file:
                key_file.write(self.createkey)
                key_file.write(b"\n")
                key_file.write(self.salt)
                # key_file.write(b"\n")
                # key_file.write(self.master_key)


            QMessageBox.information(self, '알림', f'키가 저장되었습니다.\n경로:{self.key_filename}')
        else:
            QMessageBox.information(self, '알림', f'키 생성을 먼저 해주세요.')

    def keyenv_save_slot(self):

        self.set_windows_env('CCTV_MASTER_PWD', self.master_key)


    def set_windows_env(self, key, value):
        import subprocess
        try:
            if isinstance(value, bytes):
                value = base64.b64encode(value).decode('utf-8')

            # setx 명령어 실행: setx KEY "VALUE"
            subprocess.run(['set', key, value], check=True, capture_output=True)
            print(f"성공적으로 {key} 환경변수를 설정했습니다.")
        except subprocess.CalledProcessError as e:
            print(f"설정 실패: {e}")

    def create_crypto(self):
        """
        비밀번호 암호화 및 저장
        :return:
        """
        db_passwd = self.ui.lineEdit_passwd.text()
        logger.debug(f"input passwd = {db_passwd}")

        # 1. 비밀번호 암호화
        # encrypt_pw = encrypt_pass(self.createkey, db_passwd)
        encrypt_pw = encrypt_pass_with_master(db_passwd, self.key_filename)
        # 2. 암호화된 비밀번호를 파일에 저장

        with open(self.db_filename, 'wb') as db_file:
            db_file.write(encrypt_pw)
        QMessageBox.information(self, '알림', f'비밀번호를 암호화하여 저장했습니다.')

    def validpass_slot(self):
        """c
        비밀번호 확인
        :return:
        """
        with open(self.db_filename, 'rb') as db_file:
            passwd = db_file.read()
        # de_passwd = decrypt_pass(self.createkey, passwd)
        de_passwd = decrypt_pass_with_master(passwd, self.key_filename)

        self.ui.label_validpass.setText(f'{de_passwd} 입니다.')

    def ck_pw_visible_slot(self):
        if self.ui.checkBox_pwlook.checkState() == Qt.Checked:
            self.ui.lineEdit_passwd.setEchoMode(QLineEdit.Normal)
        else:
            self.ui.lineEdit_passwd.setEchoMode(QLineEdit.Password)

    def load_sql_file(self):
        self.sql_filename, _ = QFileDialog.getOpenFileName(self, 'SQL 파일 선택', '', "SQL Files(*.sql)")
        self.ui.lineEdit_sqlfilename.setText(self.sql_filename)

    def connect_db(self):
        db_name = self.ui.lineEdit_db_name.text()
        db_user = self.ui.lineEdit_db_user.text()

        logger.debug(f"db_name: {db_name} , db_user: {db_user}")

        with open(self.db_filename, 'rb') as db_file:
            passwd = db_file.read()

        de_passwd = decrypt_pass_with_master(passwd, self.key_filename)

        try:
            self.conn = pymysql.connect(
                host='localhost',
                user=db_user,
                password=de_passwd,
                db=db_name,
            )
            self.cursor = self.conn.cursor()
            self.ui.textEdit_log.append("DB 접속 성공")
        except pymysql.Error:
            print('Failed Connecting to mysql database')
            self.ui.textEdit_log.append("DB 접속 실패")

    def read_and_excute_sql(self):
        """
        SQL 파일 읽고 스크립트 실행
        - DB 데이터 생성 및 초기화
        :return: 
        """
        if self.sql_filename:
            if self.cursor:
                try:
                    # 1. SQL 파일 읽기
                    with open(self.sql_filename, 'r', encoding='utf-8') as file:
                        sql_script = file.read()

                    # 2. SQL 스크립트 읽고 실행
                    self.ui.textEdit_log.append(f"[실행] SQL 스크립트 실행 중...")
                    for statement in sql_script.split(';'):
                        command = statement.strip()
                        if command:
                            self.cursor.execute(command)
                            result = self.cursor.fetchall()
                            logger.debug(f"[실행] {command}")

                            if result:
                                for row in result:
                                    self.ui.textEdit_log.append(str(row))
                    self.conn.commit()
                    self.ui.textEdit_log.append(f"[완료] SQL 스크립트 실행이 성공적으로 끝났습니다.")
                    QMessageBox.information(self, "알림", "DB 생성 및 초기화가 완료되었습니다.")
                except Exception as e:
                    self.ui.textEdit_log.append(f"[Error] {e}")
            else:
                QMessageBox.warning(self, '알림', '먼저 DB 접속 완료 후 실행해주세요.')
        else:
            QMessageBox.warning(self, '알림', '먼저 SQL 파일을 불러와주세요.')

    def closeEvent(self, event):
        if self.cursor:
            self.cursor.close()
        if self.conn:
            self.conn.close()

if __name__ == '__main__':
    logger.info('Database Config Management app start ')
    
    # pyqt load
    app = QApplication(sys.argv)
    window = WidgetSettingDb()
    window.show()
    sys.exit(app.exec())