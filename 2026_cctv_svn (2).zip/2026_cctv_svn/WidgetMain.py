import math
import os
import sys
import time
from datetime import datetime
from typing import Optional, Dict, Any
from enum import IntEnum
import psutil
import torch

from PySide6.QtCore import Qt, Slot, QTimer, QSize, Property
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QMainWindow, QStatusBar, QLabel, QTableWidgetItem, QMessageBox, QCheckBox, 
                               QWidget, QHBoxLayout, QHeaderView, QAbstractItemView, QPushButton, QLineEdit, QVBoxLayout,
                               QGraphicsDropShadowEffect, QApplication, QProgressBar)
from collections import namedtuple
from loguru import logger
import qtawesome as qta

from WidgetCameraDialog import CameraDialog
from WidgetEventlogDialog import EventlogDialog
from WidgetSettingsDialog import SettingsDialog
from core.camera_manager import CameraManager
from core.models import CameraConfig, FrameData, CameraStatus
from core.settings_manager import SettingsManager
from WidgetDetachedCamera import DetachedCameraWindow
from core.workers import CameraWorker, InferenceWorker
from ui.camera_widget import CameraWidget
from ui.main_window_ui import Ui_MainWindow

# 테이블 컬럼 인덱스 정의 (매직 넘버 제거)
class Col(IntEnum):
    CHECK = 0
    MOVE = 1
    STATUS = 2
    NAME = 3
    DISPLAY = 4
    DETECT = 5
    MANAGE = 6
    ADDRESS = 7

class MainWindow(QMainWindow, Ui_MainWindow):
    """메인 윈도우"""

    ButtonState = namedtuple('ButtonState', ['start_enabled', 'stop_enabled', 'reconnect_enabled'])

    def get_icon_color(self):
        return self._icon_color

    def set_icon_color(self, color):
        self._icon_color = color

    iconColor = Property(QColor, get_icon_color, set_icon_color)

    def __init__(self):
        super().__init__()
        self._icon_color = QColor("#0084FF")

        # 로거 설정 (이벤트 로그 파일 저장)
        self._setup_logger()

        # 설정 관리
        self.settings_manager = SettingsManager()

        # 비즈니스 로직
        self.camera_manager = CameraManager()

        # 워커 관리
        self.camera_workers: Dict[str, CameraWorker] = {}
        self.camera_statuses: Dict[str, CameraStatus] = {}
        self.inference_worker: Optional[InferenceWorker] = None
        self.custom_class_names: Dict[str, str] = {}
        self.custom_class_colors: Dict[str, str] = {}

        self.gpu_name = "GPU"
        if torch.cuda.is_available():
            device_name = torch.cuda.get_device_name(0)
            self.gpu_name = device_name.replace("NVIDIA","").replace("GeForce ", "")
        # 위젯 관리
        self.camera_widgets: Dict[str, CameraWidget] = {}
        self.detached_windows: Dict[str, list] = {} # 새 창으로 열린 카메라 위젯 관리
        # 테이블 행 위젯 직접 참조 (findChild 대체)
        self.table_row_widgets: Dict[str, Dict[str, QWidget]] = {}
        self.camera_order: list[str] = [] # 카메라 ID의 표시 순서를 저장

        # 이벤트 로그 쓰로틀링
        self.last_event_log_time: Dict[str, float] = {}
        self.EVENT_LOG_THROTTLE_SECS = 1  # 초 단위

        # 상태별 UI 설정 (아이콘, 색상, 툴팁, 버튼 상태)
        self.STATUS_CONFIG = {
            CameraStatus.ACTIVE:       ("mdi6.video", "#3fb950", "활성", self.ButtonState(False, True,  False)),
            CameraStatus.CONNECTING:   ("mdi6.dots-horizontal", "#d29922", "연결 중", self.ButtonState(False, True,  False)),
            CameraStatus.DISCONNECTED: ("mdi6.video-off", "#6e7681", "연결 끊김", self.ButtonState(True,  False, False)),
            CameraStatus.ERROR:        ("mdi6.alert-circle", "#f85149", "오류", self.ButtonState(False, True,  True)),
            CameraStatus.PAUSED:       ("mdi6.pause-circle", "#d29922", "일시정지", self.ButtonState(False, True,  True)),
        }

        self.is_system_running = False

        self.event_detail_dialog = None

        self.setupUi(self)
        self._signal_and_slot()
        self._setup_camera_table()
        self._setup_event_table()
        self.ensurePolished()
        self._setup_icons()
        self._apply_shadow_effects()
        self._create_status_bar()

        self._load_settings_and_cameras()

        self._setup_workers()
        self._start_timers()
        self._initial_autostart()

        self.setWindowTitle('CCTV 영상 지능형 분석 체계')
        self.label_title.setText('CCTV 영상 지능형 분석 체계')

        self.class_names = None

    def _setup_logger(self):
        """Loguru 로거 설정: 이벤트 로그를 별도 파일로 저장"""
        if not os.path.exists("logs"):
            os.makedirs("logs")
            
        # 이벤트 로그 전용 핸들러 (매일 00:00 로테이션, 30일 보관)
        # filter: bind(type="event")로 태깅된 로그만 이 파일에 기록
        logger.add(
            "logs/events_{time:YYYY-MM-DD}.log",
            rotation="00:00",
            retention="30 days",
            filter=lambda record: record["extra"].get("type") == "event",
            format="{time:YYYY-MM-DD HH:mm:ss} | {message}",
            encoding="utf-8",
            enqueue=True
        )
        logger.add(
            "logs/system{time:YYYY-MM-DD}.log",
            rotation="10 MB",
            encoding="utf-8",
            enqueue=True
        )

        # 데이터 로드
    def _signal_and_slot(self):
        self.pushButton_toggle.toggled.connect(self.toggle_slot)

        self.add_btn.clicked.connect(self._on_add_camera)
        self.edit_btn.clicked.connect(self._on_edit_camera)
        self.delete_btn.clicked.connect(self._on_delete_camera)
        self.start_btn.clicked.connect(self._on_start_all)
        self.stop_btn.clicked.connect(self._on_stop_all)
        self.grid_combo.currentIndexChanged.connect(self._update_grid_layout)
        self.camera_table.itemDoubleClicked.connect(self._on_table_item_double_clicked)
        self.camera_table.cellClicked.connect(self._on_table_cell_clicked)
        self.settings_btn.clicked.connect(self._on_settings_clicked)
        self.camera_table.horizontalHeader().sectionClicked.connect(self._camera_table_header_clicked)
        self.camera_table.verticalHeader().setVisible(False)

        self.tableWidget_event.itemClicked.connect(self._on_eventlog_item_clicked)

    def _camera_table_header_clicked(self, idx: int):
        # 20260527 swjang 헤더가 클릭되었을 때 호출되는 함수, 첫 번째 헤더(index 0)를 클릭했을 때만 동작
        if idx == 0:
            # 현재 첫 번째 행의 체크 상태를 기준으로 반전 결정, (전체 선택되어 있다면 해제, 아니면 전체 선택)
            first_item = self.camera_table.item(0, 0)
            if first_item and first_item.checkState() == Qt.Checked:
                new_state = Qt.Unchecked
            else:
                new_state = Qt.Checked

            # 모든 행의 첫 번째 열 체크박스 상태 변경
            for row in range(self.camera_table.rowCount()):
                item = self.camera_table.item(row, 0)
                if item:
                    item.setCheckState(new_state)


    def _create_status_bar(self):
        """상태바"""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

        self.status_label = QLabel("체계화면 준비됨")
        self.status_bar.addWidget(self.status_label, 1)


        # 리소스 모니터링 위젯 (아이콘 + 텍스트) - QPushButton 사용 (Flat)
        # 2025.02.25 작업관리자와 값이 차이가 있어 주석 처리함
        # self.cpu_widget = QPushButton("CPU: 0%")
        # self.cpu_widget.setFlat(True)
        # self.cpu_widget.setStyleSheet("border: none; padding: 0 5px; text-align: left;")
        # self.cpu_widget.setCursor(Qt.ArrowCursor)
        #
        # self.ram_widget = QPushButton("RAM: 0%")
        # self.ram_widget.setFlat(True)
        # self.ram_widget.setStyleSheet("border: none; padding: 0 5px; text-align: left;")
        # self.ram_widget.setCursor(Qt.ArrowCursor)
        #
        # self.gpu_widget = QPushButton("GPU: -")
        # self.gpu_widget.setFlat(True)
        # self.gpu_widget.setStyleSheet("border: none; padding: 0 5px; text-align: left;")
        # self.gpu_widget.setCursor(Qt.ArrowCursor)
        #
        # self.status_bar.addPermanentWidget(self.cpu_widget)
        # self.status_bar.addPermanentWidget(self.ram_widget)
        # self.status_bar.addPermanentWidget(self.gpu_widget)

        self.active_label = QPushButton("활성: 0/0")
        self.active_label.setFlat(True)
        self.active_label.setStyleSheet("border: none; padding: 0 5px; text-align: center;")
        self.active_label.setCursor(Qt.ArrowCursor)
        self.status_bar.addPermanentWidget(self.active_label)

    def _setup_icons(self):
        """qt_material 아이콘을 설정합니다."""
        icon_color = self._icon_color
        self.pushButton_toggle.setIcon(qta.icon('mdi6.swap-horizontal', color=icon_color))
        self.pushButton_toggle.setIconSize(QSize(18, 18))

        self.start_btn.setIcon(qta.icon('mdi6.play', color=icon_color))
        self.start_btn.setIconSize(QSize(24, 24))
        self.stop_btn.setIcon(qta.icon('mdi6.stop', color=icon_color))
        self.stop_btn.setIconSize(QSize(24, 24))
        self.add_btn.setIcon(qta.icon('mdi6.plus', color=icon_color))
        self.add_btn.setIconSize(QSize(18, 18))
        self.edit_btn.setIcon(qta.icon('mdi6.pencil', color=icon_color))
        self.edit_btn.setIconSize(QSize(18, 18))
        self.delete_btn.setIcon(qta.icon('mdi6.delete', color=icon_color))
        self.delete_btn.setIconSize(QSize(18, 18))
        
        # 설정 버튼 추가 (프로그래밍 방식으로 레이아웃에 삽입)
        self.settings_btn.setIcon(qta.icon('mdi6.cog', color=icon_color))
        self.settings_btn.setIconSize(QSize(18, 18))

    def _update_ui_icons(self):
        """테마 변경 시 아이콘 색상을 업데이트합니다."""
        self._setup_icons()
        
        # 테이블 내의 관리 버튼 아이콘 업데이트
        icon_color = self._icon_color
        icon_size = QSize(22, 22)

        for row_widgets in self.table_row_widgets.values():
            if start_btn := row_widgets.get("start_btn"):
                start_btn.setIcon(qta.icon('mdi6.play', color=icon_color))
            if stop_btn := row_widgets.get("stop_btn"):
                stop_btn.setIcon(qta.icon('mdi6.stop', color=icon_color))
            if reconnect_btn := row_widgets.get("reconnect_btn"):
                reconnect_btn.setIcon(qta.icon('mdi6.refresh', color=icon_color))

    def _apply_shadow_effects(self):
        """UI 요소에 그림자 효과 적용 (QSS box-shadow 미지원 대응)"""
        self.splitter_2.setContentsMargins(2, 2, 3, 3)

        # 시스템 현황 그룹박스
        self._add_shadow(self.groupBox_status)
        self._add_shadow(self.groupBox_control)
        self._add_shadow(self.groupBox_event)
        self._add_shadow(self.groupBox_list)
        
        # 상단 타이틀 프레임
        self._add_shadow(self.frame_top)

    def _add_shadow(self, widget):
        """위젯에 그림자 효과 추가"""
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(15)
        shadow.setXOffset(0)
        shadow.setYOffset(0)
        shadow.setColor(QColor(0, 0, 0, 30))
        widget.setGraphicsEffect(shadow)

    def _setup_camera_table(self):
        self.camera_table.setColumnCount(8)
        self.camera_table.setHorizontalHeaderLabels(["✓", "이동", "상태", "카메라명", "영상", "탐지", "관리", "주소"])
        self.camera_table.setAlternatingRowColors(True)
        self.camera_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        header = self.camera_table.horizontalHeader()
        
        # 헤더 폰트 굵게 설정
        font = header.font()
        font.setBold(True)
        header.setFont(font)

        # 모든 컬럼을 사용자가 조절할 수 있도록 Interactive 모드로 설정
        header.setSectionResizeMode(QHeaderView.Interactive)

        # 초기 컬럼 너비 설정 (사용자가 조절 가능)
        self.camera_table.setColumnWidth(Col.CHECK, 25)
        self.camera_table.setColumnWidth(Col.MOVE, 55) # New column width
        self.camera_table.setColumnWidth(Col.STATUS, 35)
        self.camera_table.setColumnWidth(Col.NAME, 120)
        self.camera_table.setColumnWidth(Col.DISPLAY, 35)
        self.camera_table.setColumnWidth(Col.DETECT, 35)
        self.camera_table.setColumnWidth(Col.MANAGE, 90)
        self.camera_table.setColumnWidth(Col.ADDRESS, 250)

    def _setup_workers(self):
        """워커 설정"""
        # 추론 워커 (전역 1개) - 테스트용 더미 모드, # YOLO 없으면 더미 모드
        self._start_inference_worker()

    def _start_inference_worker(self):
        """추론 워커 시작 (재시작 포함)"""
        # 기존 워커가 있다면 정지
        if self.inference_worker is not None:
            self.inference_worker.stop()
            self.inference_worker.wait()

        model_path = self.settings_manager.get_setting('model_path', 'yolo11n.pt')
        device = self.settings_manager.get_setting('device', 'auto')
        conf = self.settings_manager.get_setting('conf_threshold', 0.4)
        iou = self.settings_manager.get_setting('iou_threshold', 0.7)
        batch_size = self.settings_manager.get_setting('batch_size', 8)
        targets = self.settings_manager.get_setting('target_classes', None)

        self.inference_worker = InferenceWorker(model_path=model_path, device=device, use_dummy=False, batch_size=batch_size)
        self.inference_worker.set_confidence(conf)
        self.inference_worker.set_iou(iou)
        self.inference_worker.set_target_classes(targets)
        self.inference_worker.inference_complete.connect(self._on_inference_complete)
        self.inference_worker.model_loaded.connect(self._on_model_loaded)
        self.inference_worker.error_occurred.connect(lambda msg: self._add_event_log("System", msg))
        self.inference_worker.start()

        # 로딩 시작 시각적 피드백
        self.status_label.setText('AI 모델 로드 및 엔진 초기화 중...')

    def toggle_slot(self, toggled):
        logger.debug(f"{toggled}")

        if toggled:
            self.widget_left.setHidden(True)

        else:
            self.widget_left.setHidden(False)

    def _start_timers(self):
        """타이머 시작"""
        # 통합 타이머 (1초 간격)
        self.main_timer = QTimer(self)
        self.main_timer.timeout.connect(self._on_timer_tick)
        self.main_timer.start(1000)
        
        self._tick_count = 0
        self._update_datetime()

    def _on_timer_tick(self):
        """통합 타이머 틱 핸들러"""
        self._tick_count += 1
        
        # 1. 날짜/시간 업데이트 (매 1초)
        self._update_datetime()
        
        # 2. 리소스 모니터링 업데이트 (매 2초)
        # if self._tick_count % 2 == 0:
        #     self._update_resource_usage()

    def _initial_autostart(self):
        """프로그램 시작 시 자동 시작 설정된 카메라들을 시작합니다."""
        autostart_count = 0
        for camera_id, worker in self.camera_workers.items():
            config = self.camera_manager.get_camera(camera_id)
            if config and config.autostart and not worker.isRunning():
                worker.start()
                autostart_count += 1
        
        if autostart_count > 0:
            self.is_system_running = True
            self.status_label.setText(f"{autostart_count}개의 카메라 자동 시작됨")
            self._add_event_log('자동시작',f"{autostart_count}개의 카메라 자동 시작됨")

    def _update_datetime(self):
        """날짜/시간 업데이트"""
        now = datetime.now()
        weekdays = ["월", "화", "수", "목", "금", "토", "일"]
        day_str = weekdays[now.weekday()]
        self.labelDateTime.setText(f"{now.strftime('%Y-%m-%d')} ({day_str}) {now.strftime('%H:%M:%S')}")

        self._update_event_log_colors()

    def _update_resource_usage(self):
        """시스템 리소스 사용량 업데이트 (CPU, RAM, GPU)"""
        # CPU & RAM
        cpu_per = psutil.cpu_percent()
        ram_per = psutil.virtual_memory().percent
        
        # 경고 임계값 설정 (예: 80%)
        warning_threshold = 80
        warning_color = "#f85149"
        normal_color = self._icon_color # 테마 색상 사용
        
        # CPU 업데이트
        # 2025.02.25. 작업관리자의 사용량과 차이가 있어 주석처리함
        # 2025.03.13. 함수 호출 부분을 주석함.
        self.cpu_widget.setText(f"CPU: {cpu_per}%")
        if cpu_per > warning_threshold:
            self.cpu_widget.setIcon(qta.icon('mdi6.cpu-64-bit', color=warning_color))
            self.cpu_widget.setStyleSheet(f"color: {warning_color}; font-weight: bold; border: none; padding: 0 5px;")
        else:
            self.cpu_widget.setIcon(qta.icon('mdi6.cpu-64-bit', color=normal_color))
            self.cpu_widget.setStyleSheet("border: none; padding: 0 5px;")

        # RAM 업데이트
        self.ram_widget.setText(f"RAM: {ram_per}%")
        if ram_per > warning_threshold:
            self.ram_widget.setIcon(qta.icon('mdi6.memory', color=warning_color))
            self.ram_widget.setStyleSheet(f"color: {warning_color}; font-weight: bold; border: none; padding: 0 5px;")
        else:
            self.ram_widget.setIcon(qta.icon('mdi6.memory', color=normal_color))
            self.ram_widget.setStyleSheet("border: none; padding: 0 5px;")

        # GPU (PyTorch 사용 시)
        if torch.cuda.is_available():
            # 현재 할당된 메모리 / 전체 메모리
            free_mem, total_mem = torch.cuda.mem_get_info(0)
            used_mem = total_mem - free_mem
            used_gb = used_mem / 1024 ** 3
            total_gb = total_mem / 1024 ** 3
            usage_percent = (used_mem / total_mem) * 100

            self.gpu_widget.setText(f"{self.gpu_name} Mem: {used_gb:.1f}/{total_gb:.1f}GB ({usage_percent:.0f}%)")
            self.gpu_widget.setIcon(qta.icon('mdi6.expansion-card', color=normal_color))
        else:
            self.gpu_widget.setText("GPU: N/A")
            self.gpu_widget.setIcon(qta.icon('mdi6.expansion-card', color="#6e7681"))

    @Slot(object)
    def _on_inference_complete(self, frame_data: FrameData):
        """추론 완료 (하이브리드 2단계: 프레임 + 탐지결과)"""
        camera_id = frame_data.camera_id

        # 커스텀 클래스 이름 적용
        if frame_data.has_detections and self.custom_class_names:
            for det in frame_data.detections:
                custom_name = self.custom_class_names.get(str(det.class_id))
                if custom_name:
                    # logger.debug(f"Mapping class {det.class_id} to {custom_name}")
                    det.class_name = custom_name

        # Update camera widget
        if camera_id in self.camera_widgets:
            self.camera_widgets[camera_id].update_frame(frame_data)
        
        # Update any detached windows
        if camera_id in self.detached_windows:
            for window in self.detached_windows[camera_id]:
                window.update_frame(frame_data)

        # Log detection events (throttled)
        if frame_data.has_detections:
            now = time.time()
            last_log_time = self.last_event_log_time.get(camera_id, 0)

            if (now - last_log_time) > self.EVENT_LOG_THROTTLE_SECS:
                self.last_event_log_time[camera_id] = now

                camera_config = self.camera_manager.get_camera(camera_id)
                camera_name = camera_config.name if camera_config else camera_id

                # Create a summary of detections
                detection_summary = []
                for det in frame_data.detections:
                    summary = f"{det.class_name} ({det.confidence:.0%})"
                    detection_summary.append(summary)

                message = "객체 탐지: " + ", ".join(detection_summary)
                self._add_event_log(camera_name, message)

    def _setup_event_table(self):
        """이벤트 로그 테이블 초기 설정"""
        self.tableWidget_event.setColumnCount(3)
        self.tableWidget_event.setHorizontalHeaderLabels(["일시", "카메라명", "내용"])

        header = self.tableWidget_event.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        # header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        # header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
       # 헤더 폰트 굵게 설정
        font = header.font()
        font.setBold(True)
        header.setFont(font)
        
        self.tableWidget_event.setEditTriggers(QAbstractItemView.NoEditTriggers)
        
        # 필터 입력창 생성 및 배치 (테이블 상단에 추가)
        self.event_filter_edit = QLineEdit()
        self.event_filter_edit.setObjectName("SearchBar")
        self.event_filter_edit.setPlaceholderText("이벤트 로그 필터링 (예: 오류, 탐지, bus)...")
        self.event_filter_edit.setClearButtonEnabled(True)
        self.event_filter_edit.textChanged.connect(self._filter_event_log)
        
        # 기존 테이블을 레이아웃에서 찾아 필터와 함께 배치
        parent = self.tableWidget_event.parentWidget()
        if parent and parent.layout():
            layout = parent.layout()
            if layout.indexOf(self.tableWidget_event) != -1:
                container = QWidget()
                container_layout = QVBoxLayout(container)
                container_layout.setContentsMargins(0, 0, 0, 0)
                layout.replaceWidget(self.tableWidget_event, container)
                container_layout.addWidget(self.event_filter_edit)
                container_layout.addWidget(self.tableWidget_event)

    def _filter_event_log(self, text: str):
        """이벤트 로그 필터링"""
        search_text = text.lower()
        for row in range(self.tableWidget_event.rowCount()):
            match = False
            # 모든 컬럼(시간, 카메라명, 내용) 검색
            for col in range(self.tableWidget_event.columnCount()):
                item = self.tableWidget_event.item(row, col)
                if item and search_text in item.text().lower():
                    match = True
                    break
            self.tableWidget_event.setRowHidden(row, not match)

    def _add_event_log(self, camera_name: str, message: str):
        """이벤트 로그 테이블에 새 항목 추가"""
        # 파일 로그 저장 (type='event' 태그를 사용하여 위에서 설정한 필터에 걸리게 함)
        logger.bind(type="event").info(f"[{camera_name}] {message}")

        row = 0
        self.tableWidget_event.insertRow(row)

        now_dt = datetime.now()
        timestamp = now_dt.strftime("%H:%M:%S")

        time_item = QTableWidgetItem(timestamp)
        time_item.setTextAlignment(Qt.AlignCenter)
        time_item.setData(Qt.UserRole, now_dt)  # 시간 계산을 위해 datetime 객체 저장
        
        name_item = QTableWidgetItem(camera_name)
        name_item.setTextAlignment(Qt.AlignCenter)
        message_item = QTableWidgetItem(message)
        message_item.setToolTip(message)

        # 초기 색상 설정 (강조색)
        red_color = QColor("#f85149")
        for item in [time_item, name_item, message_item]:
            item.setForeground(red_color)

        self.tableWidget_event.setItem(row, 0, time_item)
        self.tableWidget_event.setItem(row, 1, name_item)
        self.tableWidget_event.setItem(row, 2, message_item)

        # 행 500개로 제한
        if self.tableWidget_event.rowCount() > 500:
            self.tableWidget_event.removeRow(500)

        # 현재 필터 적용 (새로 추가된 행 숨김 처리)
        if hasattr(self, 'event_filter_edit'):
            filter_text = self.event_filter_edit.text().lower()
            if filter_text:
                match = (filter_text in timestamp.lower() or
                         filter_text in camera_name.lower() or
                         filter_text in message.lower())
                self.tableWidget_event.setRowHidden(row, not match)

    def _update_event_log_colors(self):
        """설정된 시간이 지난 로그의 강조 색상을 해제"""
        duration_min = self.settings_manager.get_setting('log_highlight_duration', 1)
        limit_seconds = duration_min * 60
        now = datetime.now()

        # 강조색 (Red)
        highlight_color = QColor("#f85149")

        for row in range(self.tableWidget_event.rowCount()):
            time_item = self.tableWidget_event.item(row, 0)
            if not time_item: continue

            log_time = time_item.data(Qt.UserRole)
            if not isinstance(log_time, datetime): continue

            elapsed = (now - log_time).total_seconds()

            # 시간이 지났으면 색상 초기화 (기본색으로)
            if elapsed > limit_seconds:
                if time_item.foreground().color().name() == highlight_color.name():
                    for col in range(3):
                        self.tableWidget_event.item(row, col).setData(Qt.ForegroundRole, None)

    def _on_model_loaded(self, success: bool, class_name):
        """모델 로드 완료"""
        logger.debug(f'_on_model_loaded - {success} - {class_name}')

        self.class_names = class_name

        model_name = self.settings_manager.get_setting('model_path', 'Unknown')
        
        if success:
            msg = f"객체탐지 모델({model_name}) 로드 완료"
            self.status_label.setText(msg)
            self.status_label.setStyleSheet("color: #3fb950; font-weight: bold;")
            self._add_event_log("System", msg)
        else:
            msg = f"객체탐지 모델({model_name}) 로드 실패 (더미 모드)"
            self.status_label.setText(msg)
            self.status_label.setStyleSheet("color: #f85149; font-weight: bold;")
            self._add_event_log("System", msg)
            
            QMessageBox.warning(self, "모델 로드 실패", 
                                f"'{model_name}' 모델을 로드할 수 없습니다.\n시스템이 더미 모드로 동작합니다.")

    def _load_settings_and_cameras(self):
        """시작 시 설정과 카메라 정보를 로드하고 UI에 적용합니다."""
        
        # 1. 앱 설정 로드
        settings = self.settings_manager.load_app_settings()

        self.custom_class_names = settings['system_settings'].get('custom_class_names', {})
        self.custom_class_colors = settings['system_settings'].get('custom_class_colors', {})

        # 2. 카메라 정보 로드
        camera_configs = self.settings_manager.load_cameras_info()
        loaded_camera_ids_from_file = []
        for config in camera_configs:
            self.camera_manager.add_camera(config) # Add all cameras to manager first
            loaded_camera_ids_from_file.append(config.camera_id)

        # 설정에서 카메라 순서 로드. 없으면 현재 로드된 순서 사용
        if 'camera_order' in settings:
            # 설정에 있는 순서대로 카메라를 추가 (존재하는 카메라만)
            self.camera_order = [cid for cid in settings['camera_order'] if cid in loaded_camera_ids_from_file]
            # 설정에 없지만 새로 로드된 카메라가 있다면 뒤에 추가
            for cid in loaded_camera_ids_from_file:
                if cid not in self.camera_order:
                    self.camera_order.append(cid)
        else:
            self.camera_order = loaded_camera_ids_from_file # Use order from file if no saved order

        # camera_order에 따라 카메라 위젯 및 워커 설정
        # _add_camera_internal을 호출하되, 테이블 행 추가는 건너뛰도록 합니다.
        # 실제 테이블 행 추가는 _rebuild_camera_table에서 camera_order에 따라 수행합니다.
        for camera_id in self.camera_order:
            config = self.camera_manager.get_camera(camera_id)
            if config:
                self._add_camera_internal(config, skip_table_add=True)
        
        # 카메라 테이블 다시 그리기
        self._rebuild_camera_table()

        # 3. 로드된 설정 UI에 적용
        if 'window' in settings:
            win = settings['window']
            if win.get('maximized', False):
                self.showMaximized()
            else:
                self.resize(win.get('width', 1280), win.get('height', 720))
                self.move(win.get('x', 100), win.get('y', 100))

        if 'splitter_sizes' in settings:
            self.splitter.setSizes(settings['splitter_sizes'])

        if 'grid_index' in settings:
            self.grid_combo.setCurrentIndex(settings['grid_index'])

        if 'left_panel_hidden' in settings:
            self.pushButton_toggle.setChecked(settings['left_panel_hidden'])

        # 테마 및 부제목 적용
        theme = self.settings_manager.get_setting('theme', 'Light')
        subtitle = self.settings_manager.get_setting('subtitle', '')
        self.apply_theme(theme)
        if hasattr(self, 'label_subtitle'):
            self.label_subtitle.setText(subtitle)

    def _save_app_settings(self):
        """현재 앱 상태를 설정에 저장합니다."""
        settings = {
            'window': {
                'x': self.x(), 'y': self.y(),
                'width': self.width(), 'height': self.height(),
                'maximized': self.isMaximized()
            },
            'splitter_sizes': self.splitter.sizes(),
            'grid_index': self.grid_combo.currentIndex(),
            'left_panel_hidden': self.pushButton_toggle.isChecked(),
            'camera_order': self.camera_order,
        }
        self.settings_manager.save_app_settings(settings)

    def apply_theme(self, theme_name):
        """테마 적용"""
        # PyInstaller 빌드 환경 대응 (스타일 파일은 내장 리소스)
        if getattr(sys, 'frozen', False):
            base_dir = sys._MEIPASS
        else:
            base_dir = os.path.dirname(os.path.abspath(__file__))

        if theme_name == 'Dark':
            style_path = os.path.join(base_dir, "styles", "dark_style.qss")
        else:
            style_path = os.path.join(base_dir, "styles", "light_style.qss")
            
        if os.path.exists(style_path):
            with open(style_path, "r", encoding="utf-8") as f:
                QApplication.instance().setStyleSheet(f.read())
        
        # 테마에 맞춰 그림자 색상 업데이트
        self._update_shadows(theme_name)
        
        # 스타일 적용 후 속성 업데이트 및 아이콘 갱신
        self.ensurePolished()
        # 속성 업데이트가 완료된 후 아이콘을 갱신하기 위해 타이머 사용
        QTimer.singleShot(0, self._update_ui_icons)

    def _update_shadows(self, theme_name):
        """테마에 따라 그림자 강도를 조절합니다."""
        if theme_name == 'Dark':
            # 다크 모드: 배경이 어두우므로 그림자를 아주 진하게 설정 (Alpha 200)
            shadow_color = QColor(0, 0, 0, 200)
        else:
            # 라이트 모드: 은은한 그림자 (Alpha 50)
            shadow_color = QColor(0, 0, 0, 50)
            
        # 그림자 효과가 적용된 위젯들 업데이트
        widgets = [self.groupBox_status, self.groupBox_control, 
                   self.groupBox_event, self.groupBox_list, self.frame_top]
                   
        for widget in widgets:
            if widget and widget.graphicsEffect():
                effect = widget.graphicsEffect()
                if isinstance(effect, QGraphicsDropShadowEffect):
                    effect.setColor(shadow_color)

    def _add_camera_internal(self, config: CameraConfig, skip_table_add: bool = False):
        """ 카메라 추가 """
        # self.camera_manager.add_camera(config) # _load_settings_and_cameras에서 이미 추가됨
        self.camera_statuses[config.camera_id] = CameraStatus.DISCONNECTED
        if not skip_table_add:
            # 테이블 행 추가
            self._add_table_row(config)

        # 위젯 생성
        widget = CameraWidget(config)
        widget.set_custom_colors(self.custom_class_colors) # 커스텀 색상 적용
        widget.open_in_new_window.connect(self._on_open_in_new_window)
        widget.double_clicked.connect(self._on_open_in_new_window)     # 20260601 swjang 영상 화면에 더블 클릭했을때 새창 표시
        self.camera_widgets[config.camera_id] = widget

        # 워커 설정
        self._setup_worker(config, widget)

        # 그리드 업데이트
        self._update_grid_layout()

        self._update_counts()

    def _setup_worker(self, config: CameraConfig, widget: CameraWidget):
        """워커 생성 및 시그널 연결"""
        worker = CameraWorker(config)
        worker.frame_captured.connect(self._on_frame_captured)
        worker.status_changed.connect(self._on_camera_status_changed)
        worker.error_occurred.connect(self._on_camera_error)
        # worker.fps_updated.connect(widget.update_fps)
        worker.resolution_detected.connect(widget.update_resolution)
        worker.status_changed.connect(widget.update_status)
        self.camera_workers[config.camera_id] = worker

        # "전체 시작" 상태이면 새로 추가된 카메라도 시작
        if self.is_system_running:
            if config.display_enabled and not worker.isRunning():
                worker.start()

    def _find_row_by_camera_id(self, camera_id: str) -> int:
        """카메라 ID로 테이블 행 인덱스 찾기"""
        for row in range(self.camera_table.rowCount()):
            item = self.camera_table.item(row, Col.CHECK)
            if item and item.data(Qt.UserRole) == camera_id:
                return row
        return -1

    def _add_table_row(self, config: CameraConfig):
        """테이블에 행 추가"""
        row = self.camera_table.rowCount()
        self.camera_table.insertRow(row)

        # 컬럼별 아이템/위젯 생성
        status_label = self._create_status_widget()
        manage_buttons = self._create_manage_buttons(config.camera_id)
        move_buttons_widget = self._create_move_buttons_widget(config.camera_id)

        self.camera_table.setItem(row, Col.CHECK, self._create_check_item(config))
        self.camera_table.setCellWidget(row, Col.MOVE, move_buttons_widget) # New MOVE column
        self.camera_table.setCellWidget(row, Col.STATUS, self._center_widget(status_label))
        self.camera_table.setItem(row, Col.NAME, QTableWidgetItem(config.name))
        
        # 영상/탐지 체크박스
        self.camera_table.setCellWidget(row, Col.DISPLAY, 
            self._create_table_checkbox(config.display_enabled, 
                lambda checked: self._on_display_toggled(config.camera_id, checked)))
        
        self.camera_table.setCellWidget(row, Col.DETECT, 
            self._create_table_checkbox(config.detection_enabled, 
                lambda checked: self._on_detection_toggled(config.camera_id, checked)))

        self.camera_table.setItem(row, Col.ADDRESS, self._create_address_item(config))
        self.camera_table.setCellWidget(row, Col.MANAGE, self._create_manage_button_container(manage_buttons))

        # 위젯 참조 저장 (already handled in _create_move_buttons_widget for up/down buttons)
        self.table_row_widgets[config.camera_id].update({
            "status_label": status_label,
            **{f"{name}_btn": btn for name, btn in manage_buttons.items()}
        })

    def _create_check_item(self, config: CameraConfig) -> QTableWidgetItem:
        """체크박스 아이템 생성"""
        item = QTableWidgetItem()
        item.setCheckState(Qt.Checked if config.enabled else Qt.Unchecked)
        item.setData(Qt.UserRole, config.camera_id)
        return item

    def _create_status_widget(self) -> QLabel:
        """상태 아이콘 라벨 생성"""
        label = QLabel()
        label.setObjectName("status_lbl")
        icon_name, color, tooltip, _ = self.STATUS_CONFIG[CameraStatus.DISCONNECTED]
        label.setPixmap(qta.icon(icon_name, color=color).pixmap(20, 20))
        label.setToolTip(tooltip)
        return label

    def _create_address_item(self, config: CameraConfig) -> QTableWidgetItem:
        """주소 아이템 생성"""
        source_text = config.source[:30] + "..." if len(config.source) > 30 else config.source
        item = QTableWidgetItem(source_text)
        item.setToolTip(config.source)
        return item

    def _create_table_checkbox(self, is_checked: bool, slot) -> QWidget:
        """테이블 내에 사용될 중앙 정렬된 체크박스를 생성합니다."""
        checkbox = QCheckBox()
        checkbox.setChecked(is_checked)
        checkbox.toggled.connect(slot)
        return self._center_widget(checkbox)

    def _create_move_buttons_widget(self, camera_id: str) -> QWidget:
        """테이블 내 '이동' 컬럼에 들어갈 위/아래 버튼들을 생성합니다."""
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        up_btn = self._create_tool_button('mdi6.chevron-up', "위로 이동", lambda: self._on_move_camera_up(camera_id))
        down_btn = self._create_tool_button('mdi6.chevron-down', "아래로 이동", lambda: self._on_move_camera_down(camera_id))
        
        layout.addWidget(up_btn)
        layout.addWidget(down_btn)
        layout.setAlignment(Qt.AlignCenter)
        
        # 버튼 참조를 저장하여 활성화/비활성화 제어
        if camera_id not in self.table_row_widgets:
            self.table_row_widgets[camera_id] = {}
        self.table_row_widgets[camera_id]["up_btn"] = up_btn
        self.table_row_widgets[camera_id]["down_btn"] = down_btn

        return widget

    def _create_manage_buttons(self, camera_id: str) -> Dict[str, QPushButton]:
        """테이블 내 '관리' 컬럼에 들어갈 버튼들을 생성하고 딕셔너리로 반환합니다."""
        # 버튼 생성
        start_btn = self._create_tool_button('mdi6.play', "시작", lambda: self._on_individual_start(camera_id))
        stop_btn = self._create_tool_button('mdi6.stop', "정지", lambda: self._on_individual_stop(camera_id))
        reconnect_btn = self._create_tool_button('mdi6.refresh', "재연결", lambda: self._on_individual_reconnect(camera_id))
        
        return {"start": start_btn, "stop": stop_btn, "reconnect": reconnect_btn}

    def _create_manage_button_container(self, buttons: Dict[str, QPushButton]) -> QWidget:
        """관리 버튼들을 담을 컨테이너 위젯을 생성합니다."""
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setSpacing(2)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(buttons["start"])
        layout.addWidget(buttons["stop"])
        layout.addWidget(buttons["reconnect"])
        layout.setAlignment(Qt.AlignCenter)
        return widget

    def _create_tool_button(self, icon_name: str, tooltip: str, slot) -> QPushButton:
        """아이콘 기반의 작은 툴 버튼을 생성합니다."""
        button = QPushButton()
        button.setIcon(qta.icon(icon_name, color=self._icon_color))
        button.setIconSize(QSize(22, 22))
        button.setFixedSize(23, 23)
        button.setToolTip(tooltip)
        button.clicked.connect(slot)
        # 260905 swjang 버튼이 포커스를 가져가지 않도록 설정 버튼을 클릭해도 포커스가 테이블 셀에 그대로 남아있게 유지
        button.setFocusPolicy(Qt.NoFocus)
        return button

    def _center_widget(self, widget: QWidget) -> QWidget:
        """위젯을 중앙에 배치하기 위한 컨테이너 위젯을 반환합니다."""
        container = QWidget()
        layout = QHBoxLayout(container)
        layout.addWidget(widget)
        layout.setAlignment(Qt.AlignCenter)
        layout.setContentsMargins(0, 0, 0, 0)
        return container

    @Slot(str, bool)
    def _on_display_toggled(self, camera_id: str, checked: bool):
        """영상 표시 상태 변경. 표시가 꺼지면 탐지도 자동으로 끔."""
        config = self.camera_manager.get_camera(camera_id)
        if not config:
            return

        # 1. Update display config
        config.display_enabled = checked
        self.camera_manager.update_camera(camera_id, config)
        self._update_grid_layout()
        self.settings_manager.save_cameras_info(self.camera_manager.get_all_cameras())
        logger.debug(f"Camera '{config.name}' display toggled: {checked}")

        # 2. If display is turned off, also turn off detection checkbox
        if not checked:
            row = self._find_row_by_camera_id(camera_id)
            if row != -1:
                container = self.camera_table.cellWidget(row, Col.DETECT)
                if container:
                    checkbox_container = container.findChild(QWidget)
                    if checkbox_container:
                        detect_checkbox = checkbox_container.findChild(QCheckBox)
                        # Only change it if it's currently checked, to avoid an unnecessary signal
                        if detect_checkbox and detect_checkbox.isChecked():
                            detect_checkbox.setChecked(False)

    @Slot(str, bool)
    def _on_detection_toggled(self, camera_id: str, checked: bool):
        """탐지 상태 변경"""
        config = self.camera_manager.get_camera(camera_id)
        if config:
            config.detection_enabled = checked
            self.camera_manager.update_camera(camera_id, config)
            self.settings_manager.save_cameras_info(self.camera_manager.get_all_cameras())
            logger.debug(f"Camera '{config.name}' detection toggled: {checked}")

            # 위젯에 즉시 반영 (아이콘 업데이트 및 바운딩 박스 표시 설정)
            if camera_id in self.camera_widgets:
                widget = self.camera_widgets[camera_id]
                widget.update_config(config)       # 상단 아이콘(돋보기) 상태 업데이트
                widget.set_detection_visible(checked) # 현재 프레임의 바운딩 박스 즉시 숨김/표시

    @Slot(str)
    def _on_move_camera_up(self, camera_id: str):
        """카메라를 위로 이동"""
        current_index = self.camera_order.index(camera_id)
        if current_index > 0:
            self.camera_order[current_index], self.camera_order[current_index - 1] = \
                self.camera_order[current_index - 1], self.camera_order[current_index]
            self._rebuild_camera_table()
            self._update_grid_layout()
            self._save_app_settings()

    @Slot(str)
    def _on_move_camera_down(self, camera_id: str):
        """카메라를 아래로 이동"""
        current_index = self.camera_order.index(camera_id)
        if current_index < len(self.camera_order) - 1:
            self.camera_order[current_index], self.camera_order[current_index + 1] = \
                self.camera_order[current_index + 1], self.camera_order[current_index]
            self._rebuild_camera_table()
            self._update_grid_layout()
            self._save_app_settings()

    @Slot()
    def _update_grid_layout(self):
        """그리드 레이아웃 업데이트"""
        # 기존 위젯을 레이아웃에서 제거. 위젯의 부모를 None으로 설정하여 완전히 제거.
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.setParent(None)

        # 기존 스트레치 초기화 (균등 배치를 위해 필요)
        for r in range(self.grid_layout.rowCount()):
            self.grid_layout.setRowStretch(r, 0)
        for c in range(self.grid_layout.columnCount()):
            self.grid_layout.setColumnStretch(c, 0)

        # 표시할 위젯 필터링 (camera_order 순서에 따라)
        visible_widgets = []
        for camera_id in self.camera_order:
            if camera_id in self.camera_widgets:
                widget = self.camera_widgets[camera_id]
                config = self.camera_manager.get_camera(camera_id)
                if config and config.display_enabled:
                    visible_widgets.append(widget)

        if not visible_widgets:
            return

        # 그리드 크기 결정
        grid_index = self.grid_combo.currentIndex()
        count = len(visible_widgets)

        cols = 1
        if grid_index == 0:  # 자동
            if count > 0:
                cols = math.ceil(math.sqrt(count))
        else:
            cols = grid_index  # 1, 2, 3, 4

        for i, widget in enumerate(visible_widgets):
            row = i // cols
            col = i % cols
            self.grid_layout.addWidget(widget, row, col)

        # 균등 배치를 위해 행/열 스트레치 설정
        total_rows = math.ceil(count / cols)
        for r in range(total_rows):
            self.grid_layout.setRowStretch(r, 1)
        for c in range(cols):
            self.grid_layout.setColumnStretch(c, 1)

    def _update_counts(self):
        """카운트 업데이트. camera_statuses를 기반으로 UI의 카운트를 업데이트합니다."""
        total_count = len(self.camera_statuses)
        active_count = sum(1 for status in self.camera_statuses.values() if status == CameraStatus.ACTIVE)
        disabled_count = total_count - active_count

        self.total_count_label.setText(str(total_count))
        self.active_count_label.setText(str(active_count))
        self.disable_count_label.setText(str(disabled_count))

        self.active_label.setText(f"카메라 Total : {total_count}, Active : {active_count}, Disabled : {disabled_count}, CUDA_Available : {torch.cuda.is_available()} ")

    def _rebuild_camera_table(self):
        """camera_order에 따라 카메 라 테이블을 완전히 다시 그립니다."""
        self.camera_table.clearContents()
        self.camera_table.setRowCount(0)

        for camera_id in self.camera_order:
            config = self.camera_manager.get_camera(camera_id)
            if config:
                self._add_table_row(config) # _add_table_row 내부에서 rowCount()를 사용하여 행 추가
        self._update_move_button_states() # 버튼 상태 업데이트

    def _update_move_button_states(self):
        """이동 버튼들의 활성화/비활성화 상태를 업데이트합니다."""
        for row in range(self.camera_table.rowCount()):
            # Col.CHECK에 QTableWidgetItem이 있으므로 item()으로 접근
            check_item = self.camera_table.item(row, Col.CHECK)
            if not check_item: # Check if item exists
                continue
            camera_id = check_item.data(Qt.UserRole)
            
            if camera_id in self.table_row_widgets:
                up_btn = self.table_row_widgets[camera_id]["up_btn"]
                down_btn = self.table_row_widgets[camera_id]["down_btn"]

                up_btn.setEnabled(row > 0)
                down_btn.setEnabled(row < self.camera_table.rowCount() - 1)

    @Slot(QTableWidgetItem)
    def _on_table_item_double_clicked(self, item: QTableWidgetItem):
        """테이블 행 더블클릭 시 편집 모드 진입"""
        if not item:
            return

        clicked_row = item.row()

        # 모든 체크박스 해제
        for row in range(self.camera_table.rowCount()):
            chk_item = self.camera_table.item(row, Col.CHECK)
            if chk_item and chk_item.row() != clicked_row:
                chk_item.setCheckState(Qt.Unchecked)

        # 더블클릭한 행의 체크박스 선택
        chk_item_to_select = self.camera_table.item(clicked_row, Col.CHECK)
        if chk_item_to_select:
            chk_item_to_select.setCheckState(Qt.Checked)

        # 편집 함수 호출
        self._on_edit_camera()

    @Slot(int, int)
    def _on_table_cell_clicked(self, row: int, col: int):
        """테이블 셀 클릭 시 행 선택 (체크박스 컬럼 클릭 시에도 행 선택)"""
        if col == Col.CHECK:
            self.camera_table.selectRow(row)


    def _on_eventlog_item_clicked(self, item):
        """메인 테이블 행 클릭 시 상세창 데이터 갱신"""

        logger.debug(f'_on_eventlog_item_clicked - {item}')

        row = item.row()

        # 1. 선택한 행의 데이터 추출
        selected_data = [
            self.tableWidget_event.item(row, 0).text() if self.tableWidget_event.item(row, 0) else "-",
            self.tableWidget_event.item(row, 1).text() if self.tableWidget_event.item(row, 1) else "-",
            self.tableWidget_event.item(row, 2).text() if self.tableWidget_event.item(row, 2) else "-"
        ]

        # 2. 상세창이 없거나 닫혀있다면 새로 생성
        if self.event_detail_dialog is None:
            self.event_detail_dialog = EventlogDialog(self)

        # 3. 데이터 업데이트
        self.event_detail_dialog.update_data(selected_data)

        # 4. 창 표시 (이미 떠 있다면 위치만 유지되고 내용만 바뀜)
        # exec()는 모달(창을 닫기 전까지 메인 못씀)이므로,
        # 메인과 동시에 쓰고 싶다면 show()를 사용해야 합니다.
        self.event_detail_dialog.show()
        self.event_detail_dialog.raise_()  # 창을 맨 위로 올림
        self.event_detail_dialog.activateWindow()  # 포커스 부여


    def _get_selected_camera_id(self) :
        """
        테이블에서 체크된 카메라 ID를 반환합니다.
        20260527 swjang 테이블에서 체크된 모든 카메라 ID 리스트를 반환토록 수정
        """
        checked_ids = []
        for row in range(self.camera_table.rowCount()):
            item = self.camera_table.item(row, Col.CHECK)
            if item and item.checkState() == Qt.Checked:
                camera_id = item.data(Qt.UserRole)
                if camera_id:
                    checked_ids.append(camera_id)

        # if len(checked_ids) == 1:
        #     return checked_ids
        #
        # if len(checked_ids) > 1:
        #     QMessageBox.warning(self, "경고", f"하나의 카메라만 선택하여 {operation}할 수 있습니다.")
        # else:  # 0 checked
        #     QMessageBox.warning(self, "경고", f"{operation}할 카메라를 선택하세요.")
        # return None
        return checked_ids

    def _update_table_row(self, camera_id: str, config: CameraConfig):
        """테이블 행 업데이트"""
        row = self._find_row_by_camera_id(camera_id)
        if row != -1:
            # 이름 업데이트
            self.camera_table.item(row, Col.NAME).setText(config.name)

            # 영상 표시 체크박스 업데이트
            display_container = self.camera_table.cellWidget(row, Col.DISPLAY)
            if display_container:
                display_checkbox = display_container.findChild(QCheckBox)
                if display_checkbox:
                    display_checkbox.setChecked(config.display_enabled)

            # 탐지 체크박스 업데이트
            detect_container = self.camera_table.cellWidget(row, Col.DETECT)
            if detect_container:
                detect_checkbox = detect_container.findChild(QCheckBox)
                if detect_checkbox:
                    detect_checkbox.setChecked(config.detection_enabled)

            # 주소 업데이트
            source_text = config.source[:20] + "..." if len(config.source) > 20 else config.source
            address_item = self.camera_table.item(row, Col.ADDRESS)
            address_item.setText(source_text)
            address_item.setToolTip(config.source)

    @Slot()
    def _on_add_camera(self):
        """카메라 추가"""
        dialog = CameraDialog(parent=self)
        if dialog.exec():
            config = dialog.get_config()
            self.camera_manager.add_camera(config)
            self._add_camera_internal(config, skip_table_add=True) # skip_table_add=True로 호출

            # 새 카메라를 camera_order의 마지막에 추가
            self.camera_order.append(config.camera_id)
            self._rebuild_camera_table() # 테이블을 다시 그려 새 카메라 반영
            self._update_grid_layout()
            
            self.settings_manager.save_cameras_info(self.camera_manager.get_all_cameras())
            self._save_app_settings() # 카메라 순서 변경 사항 저장

    @Slot()
    def _on_edit_camera(self):
        """카메라 수정"""

        selected_ids = self._get_selected_camera_id()
        if not selected_ids:
            QMessageBox.warning(self, "경고", "수정할 카메라를 선택하세요.")
            return

        camera_id = selected_ids[0]

        config = self.camera_manager.get_camera(camera_id)
        if not config:
            return

        dialog = CameraDialog(config, parent=self)
        if dialog.exec():
            new_config = dialog.get_config()

            # 워커 재시작 필요 여부
            need_restart = config.source != new_config.source

            # 업데이트
            self.camera_manager.update_camera(camera_id, new_config)
            self._update_table_row(camera_id, new_config)
            self.settings_manager.save_cameras_info(self.camera_manager.get_all_cameras())
            # 20260528 swjang 수정시 시스템 현황이 갱신 기능 누락
            self._update_counts()

            if camera_id in self.camera_widgets:
                self.camera_widgets[camera_id].update_config(new_config)

            if need_restart and camera_id in self.camera_workers:
                worker = self.camera_workers[camera_id]
                if worker.isRunning():
                    worker.stop()
                    worker.update_config(new_config)
                    worker.start()

    @Slot()
    def _on_delete_camera(self):
        """선택된 모든 카메라 삭제"""
        # 1. 체크된 모든 ID 가져오기
        camera_ids = self._get_selected_camera_id()

        if not camera_ids:
            QMessageBox.warning(self, '경고', '삭제할 카메라를 선택하세요')
            return

        # 2. 사용자 확인 갯수 표시
        count = len(camera_ids)
        msg = f"선택한 {count}개의 카메라를 삭제하시겠습니까?" if count > 1 else "선택한 카메라를 삭제하시겠습니까?"
        reply = QMessageBox.question(self, "확인", msg, QMessageBox.Yes | QMessageBox.No)

        if reply == QMessageBox.Yes:
            # 3. 루프를 돌며 삭제 처리
            for camera_id in camera_ids:
                self._remove_camera(camera_id)
            # 4. 설정 저장 및 UI 업데이트(루프 밖에서 한 번만 수행)
            self.settings_manager.save_cameras_info(self.camera_manager.get_all_cameras())
            self._update_counts()
            logger.info(f"{count}개의 카메라가 삭제되었습니다.")

    def _remove_camera(self, camera_id: str):
        """카메라 제거 및 리소스 정리"""
        # 워커 정지 및 제거
        if camera_id in self.camera_workers:
            self.camera_workers[camera_id].stop()
            del self.camera_workers[camera_id]

        # 위젯 제거
        if camera_id in self.camera_widgets:
            widget = self.camera_widgets[camera_id]
            self.grid_layout.removeWidget(widget)
            widget.deleteLater()
            del self.camera_widgets[camera_id]

        # 테이블에서 제거
        row = self._find_row_by_camera_id(camera_id)
        if row != -1:
            self.camera_table.removeRow(row)

        # 매니저에서 제거
        self.camera_manager.remove_camera(camera_id)

        # 상태 dict에서 제거
        if camera_id in self.camera_statuses:
            del self.camera_statuses[camera_id]

        # camera_order에서 제거
        if camera_id in self.camera_order:
            self.camera_order.remove(camera_id)

        # 위젯 참조 제거
        if camera_id in self.table_row_widgets:
            del self.table_row_widgets[camera_id]

        # 그리드 재구성
        self._update_grid_layout()
        self._rebuild_camera_table() # Rebuild table after removing
        self._update_counts()
        self._save_app_settings() # Save changes to camera_order

    @Slot()
    def _on_start_all(self):
        """전체 시작"""
        for camera_id, worker in self.camera_workers.items():
            config = self.camera_manager.get_camera(camera_id)
            # if config and config.enabled and not worker.isRunning():
            if config and config.display_enabled and not worker.isRunning():
                worker.start()

        self.is_system_running = True
        self.status_label.setText("전체 카메라 시작됨")

    @Slot()
    def _on_stop_all(self):
        """전체 정지"""
        for worker in self.camera_workers.values():
            if worker.isRunning():
                worker.stop()

        self.is_system_running = False
        self.status_label.setText("전체 카메라 정지됨")

    @Slot(str)
    def _on_individual_start(self, camera_id: str):
        """개별 카메라 시작"""
        if camera_id in self.camera_workers:
            worker = self.camera_workers[camera_id]
            if not worker.isRunning():
                worker.start()
                logger.debug(f"Started individual camera: {camera_id}")

    @Slot(str)
    def _on_individual_stop(self, camera_id: str):
        """개별 카메라 정지"""
        if camera_id in self.camera_workers:
            worker = self.camera_workers[camera_id]
            if worker.isRunning():
                worker.stop()
                logger.debug(f"Stopped individual camera: {camera_id}")

    @Slot(str)
    def _on_individual_reconnect(self, camera_id: str):
        """개별 카메라 재연결"""
        if camera_id in self.camera_workers:
            worker = self.camera_workers[camera_id]
            worker.reconnect()
            logger.debug(f"Triggered manual reconnect for camera: {camera_id}")

    @Slot()
    def _on_settings_clicked(self):
        """설정 버튼 클릭 시"""
        dialog = SettingsDialog(self.settings_manager.system_settings, self)

        # 20260522 swjang 설정화면에 모델의 클래스 이름 전달
        if self.class_names:
            dialog.set_class_names(self.class_names)

        if dialog.exec():
            new_settings = dialog.get_settings()
            
            # 변경사항 확인
            theme_changed = new_settings['theme'] != self.settings_manager.get_setting('theme')
            model_changed = (new_settings['model_path'] != self.settings_manager.get_setting('model_path') or
                             new_settings['device'] != self.settings_manager.get_setting('device'))

            # 모델 변경 시 커스텀 클래스 이름 초기화 로직
            if model_changed and new_settings.get('custom_class_names'):
                reply = QMessageBox.question(
                    self,
                    "모델 변경 확인",
                    "모델이 변경되었습니다. 기존의 사용자 정의 라벨 설정이 새 모델과 호환되지 않을 수 있습니다.\n\n"
                    "사용자 정의 라벨 설정을 초기화하시겠습니까?",
                    QMessageBox.Yes | QMessageBox.No
                )
                if reply == QMessageBox.Yes:
                    new_settings['custom_class_names'] = {}
                    logger.info("Custom class names reset due to model change.")

            conf_changed = new_settings['conf_threshold'] != self.settings_manager.get_setting('conf_threshold')
            iou_changed = new_settings['iou_threshold'] != self.settings_manager.get_setting('iou_threshold')
            batch_changed = new_settings.get('batch_size') != self.settings_manager.get_setting('batch_size')
            targets_changed = new_settings.get('target_classes') != self.settings_manager.get_setting('target_classes')
            custom_names_changed = new_settings.get('custom_class_names') != self.settings_manager.get_setting('custom_class_names')
            custom_colors_changed = new_settings.get('custom_class_colors') != self.settings_manager.get_setting('custom_class_colors')
            
            # 새 설정으로 업데이트
            self.settings_manager.update_settings(new_settings)
            self._save_app_settings()
            
            # 커스텀 클래스 이름 설정 업데이트 (항상 최신 값 반영)
            self.custom_class_names = new_settings.get('custom_class_names', {})
            self.custom_class_colors = new_settings.get('custom_class_colors', {})

            if theme_changed:
                self.apply_theme(new_settings['theme'])
                logger.info(f"Theme changed to {new_settings['theme']}")
            
            # 부제목 업데이트
            if hasattr(self, 'label_subtitle'):
                self.label_subtitle.setText(new_settings.get('subtitle', ''))
            
            if custom_names_changed:
                logger.info(f"Custom class names updated: {self.custom_class_names}")

            if custom_colors_changed:
                logger.info(f"Custom class colors updated: {self.custom_class_colors}")
                # 모든 카메라 위젯에 새 색상 적용
                for widget in self.camera_widgets.values():
                    widget.set_custom_colors(self.custom_class_colors)
                # 분리된 창에도 적용
                for windows in self.detached_windows.values():
                    for window in windows:
                        if hasattr(window, 'camera_widget'):
                            window.camera_widget.set_custom_colors(self.custom_class_colors)
            
            if self.inference_worker:
                if conf_changed:
                    self.inference_worker.set_confidence(new_settings['conf_threshold'])
                    logger.info(f"Confidence threshold updated to {new_settings['conf_threshold']}")
                
                if iou_changed:
                    self.inference_worker.set_iou(new_settings['iou_threshold'])
                    logger.info(f"IOU threshold updated to {new_settings['iou_threshold']}")
                
                if batch_changed:
                    self.inference_worker.set_batch_size(new_settings['batch_size'])
                    logger.info(f"Batch size updated to {new_settings['batch_size']}")

                if targets_changed:
                    self.inference_worker.set_target_classes(new_settings['target_classes'])
                    logger.info(f"Target classes updated: {new_settings['target_classes']}")

                if model_changed:
                    self._start_inference_worker()
                    logger.info(f"Inference worker restarted with model: {new_settings['model_path']}")

    # ==================== 프레임/추론 처리 ====================

    @Slot(object)
    def _on_frame_captured(self, frame_data: FrameData):
        """프레임 수신 (하이브리드 1단계: 원본 프레임)"""
        camera_id = frame_data.camera_id
        config = self.camera_manager.get_camera(camera_id)

        if not config:
            return

        if config.detection_enabled:
            # 탐지 활성화: 추론 워커로 전달
            self.inference_worker.add_frame(frame_data)
        else:
            # 탐지 비활성화: 바로 UI 업데이트
            if camera_id in self.camera_widgets:
                self.camera_widgets[camera_id].update_frame(frame_data)
            
            # 분리된 창에도 업데이트
            if camera_id in self.detached_windows:
                for window in self.detached_windows[camera_id]:
                    window.update_frame(frame_data)



    @Slot(str, object)
    def _on_camera_status_changed(self, camera_id: str, status: CameraStatus):
        """카메라 상태 변경"""
        self.camera_statuses[camera_id] = status
        
        # 클래스 상수로 정의된 설정 사용
        icon_name, color, tooltip, button_state = self.STATUS_CONFIG.get(
            status, ("mdi6.help-circle", "#6e7681", "알 수 없음", self.ButtonState(False, False, False))
        )

        # 위젯 직접 참조를 통해 UI 업데이트
        row_widgets = self.table_row_widgets.get(camera_id)
        if row_widgets:
            # 1. 상태 아이콘 업데이트
            if status_label := row_widgets.get("status_label"):
                status_label.setPixmap(qta.icon(icon_name, color=color).pixmap(24, 24))
                status_label.setToolTip(tooltip)
            
            # 2. 관리 버튼 상태 업데이트
            if start_btn := row_widgets.get("start_btn"):
                start_btn.setEnabled(button_state.start_enabled)
            if stop_btn := row_widgets.get("stop_btn"):
                stop_btn.setEnabled(button_state.stop_enabled)
            if reconnect_btn := row_widgets.get("reconnect_btn"):
                reconnect_btn.setEnabled(button_state.reconnect_enabled)

        # 분리된 창에도 상태 전파
        if camera_id in self.detached_windows:
            for window in self.detached_windows[camera_id]:
                window.update_status(status)

        self._update_counts()

    @Slot(str, str)
    def _on_camera_error(self, camera_id: str, message: str):
        """카메라 오류 발생"""
        config = self.camera_manager.get_camera(camera_id)
        camera_name = config.name if config else camera_id
        
        # 이벤트 로그에 추가
        log_message = f"연결 오류: {message}"
        self._add_event_log(camera_name, log_message)

        # 테이블 상태 아이콘에 툴팁 설정
        row_widgets = self.table_row_widgets.get(camera_id)
        if row_widgets and (status_label := row_widgets.get("status_label")):
            status_label.setToolTip(log_message)

    @Slot(str)
    def _on_open_in_new_window(self, camera_id: str):
        """카메라 새 창으로 열기 (Viewer-only)"""
        config = self.camera_manager.get_camera(camera_id)
        if not config:
            return

        logger.debug(f"camera status : {self.camera_statuses.get(camera_id)}")

        if self.camera_statuses.get(camera_id) != CameraStatus.ACTIVE:
            return

        # 새 창 생성 및 표시
        detached_window = DetachedCameraWindow(config, self)
        detached_window.camera_widget.set_custom_colors(self.custom_class_colors) # 커스텀 색상 적용
        detached_window.showFullScreen()

        # 참조 유지를 위해 딕셔너리에 추가
        if camera_id not in self.detached_windows:
            self.detached_windows[camera_id] = []
        self.detached_windows[camera_id].append(detached_window)
        
        # 현재 상태 즉시 전달
        current_status = self.camera_statuses.get(camera_id, CameraStatus.DISCONNECTED)
        detached_window.update_status(current_status)

        # 창이 닫힐 때 리스트에서 제거하도록 연결
        detached_window.finished.connect(
            lambda: self._on_detached_window_closed(detached_window, camera_id)
        )

    def _on_detached_window_closed(self, window: DetachedCameraWindow, camera_id: str):
        """분리된 창이 닫혔을 때 호출되는 슬롯"""
        if camera_id in self.detached_windows and window in self.detached_windows[camera_id]:
            self.detached_windows[camera_id].remove(window)
            if not self.detached_windows[camera_id]:
                del self.detached_windows[camera_id]
        logger.debug(f"Detached window for camera {camera_id} closed and removed.")

    def closeEvent(self, event):
        """종료 이벤트"""
        self._save_app_settings()
        
        # 모든 워커 정지
        for worker in self.camera_workers.values():
            worker.stop()

        if self.inference_worker:
            self.inference_worker.stop()

        event.accept()