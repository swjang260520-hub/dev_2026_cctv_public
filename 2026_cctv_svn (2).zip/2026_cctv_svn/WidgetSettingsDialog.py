import os
import sys
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QFormLayout, QComboBox,
                               QDoubleSpinBox, QSpinBox, QDialogButtonBox, QGroupBox,
                               QHBoxLayout, QPushButton, QListWidget, QColorDialog,
                               QListWidgetItem, QLabel, QLineEdit, QGraphicsDropShadowEffect, QMessageBox)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPixmap, QIcon

class SettingsDialog(QDialog):
    """시스템 설정 다이얼로그"""
    
    # COCO 데이터셋 클래스 정의 (ID: Name)
    COCO_CLASSES = {
        0: "person", 1: "bicycle", 2: "car", 3: "motorcycle", 4: "airplane", 5: "bus", 6: "train", 7: "truck", 8: "boat", 9: "traffic light",
        10: "fire hydrant", 11: "stop sign", 12: "parking meter", 13: "bench", 14: "bird", 15: "cat", 16: "dog", 17: "horse", 18: "sheep", 19: "cow",
        20: "elephant", 21: "bear", 22: "zebra", 23: "giraffe", 24: "backpack", 25: "umbrella", 26: "handbag", 27: "tie", 28: "suitcase", 29: "frisbee",
        30: "skis", 31: "snowboard", 32: "sports ball", 33: "kite", 34: "baseball bat", 35: "baseball glove", 36: "skateboard", 37: "surfboard", 38: "tennis racket", 39: "bottle",
        40: "wine glass", 41: "cup", 42: "fork", 43: "knife", 44: "spoon", 45: "bowl", 46: "banana", 47: "apple", 48: "sandwich", 49: "orange",
        50: "broccoli", 51: "carrot", 52: "hot dog", 53: "pizza", 54: "donut", 55: "cake", 56: "chair", 57: "couch", 58: "potted plant", 59: "bed",
        60: "dining table", 61: "toilet", 62: "tv", 63: "laptop", 64: "mouse", 65: "remote", 66: "keyboard", 67: "cell phone", 68: "microwave", 69: "oven",
        70: "toaster", 71: "sink", 72: "refrigerator", 73: "book", 74: "clock", 75: "vase", 76: "scissors", 77: "teddy bear", 78: "hair drier", 79: "toothbrush"
    }

    def __init__(self, current_settings, parent=None):
        super().__init__(parent)
        self.setWindowTitle("시스템 설정")
        self.resize(600, 800)
        self.settings = current_settings.copy()
        self._setup_ui()
        
    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # 일반 설정 그룹
        general_group = QGroupBox("일반 설정")
        self._add_shadow(general_group)
        general_form = QFormLayout(general_group)
        general_form.setContentsMargins(10, 15, 10, 10)
        general_form.setVerticalSpacing(8)
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Light", "Dark"])
        self.theme_combo.setCurrentText(self.settings.get('theme', 'Light'))
        general_form.addRow("테마:", self.theme_combo)
        
        self.subtitle_edit = QLineEdit()
        self.subtitle_edit.setText(self.settings.get('subtitle', ''))
        self.subtitle_edit.setPlaceholderText("시스템 부제목 입력")
        general_form.addRow("부제목:", self.subtitle_edit)
        
        # YOLO 설정 그룹
        yolo_group = QGroupBox("YOLO 탐지 설정")
        self._add_shadow(yolo_group)
        form_layout = QFormLayout(yolo_group)
        
        # 모델 선택
        self.model_combo = QComboBox()
        
        # models 폴더의 .pt 파일 스캔
        # PyInstaller 환경에서는 실행 파일 위치 기준, 개발 환경에서는 파일 위치 기준
        if getattr(sys, 'frozen', False):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            
        models_dir = os.path.join(base_dir, "models")
        model_files = []
        if os.path.exists(models_dir):
            model_files = [f for f in os.listdir(models_dir) if f.endswith(".pt") or f.endswith(".onnx") or f.endswith(".engine")]
            model_files.sort()

        self.model_combo.addItems(model_files)
        self.model_combo.setCurrentText(self.settings.get('model_path', 'yolo11n.pt'))
        form_layout.addRow("모델 파일:", self.model_combo)
        
        # 디바이스 선택
        self.device_combo = QComboBox()
        self.device_combo.addItems(["auto", "cpu", "cuda", "mps"])
        self.device_combo.setCurrentText(self.settings.get('device', 'auto'))
        self.device_combo.setToolTip("cuda: NVIDIA GPU, mps: Mac GPU, cpu: CPU 전용")
        form_layout.addRow("가속 장치:", self.device_combo)
        
        # 배치 크기
        self.batch_spin = QSpinBox()
        self.batch_spin.setRange(1, 64)
        self.batch_spin.setValue(self.settings.get('batch_size', 8))
        self.batch_spin.setToolTip("한 번에 추론할 이미지 수입니다. 높으면 처리량 증가, 낮으면 지연 감소.")
        form_layout.addRow("배치 크기:", self.batch_spin)

        # 신뢰도 임계값
        self.conf_spin = QDoubleSpinBox()
        self.conf_spin.setRange(0.1, 1.0)
        self.conf_spin.setSingleStep(0.05)
        self.conf_spin.setValue(self.settings.get('conf_threshold', 0.4))
        self.conf_spin.setToolTip("이 값보다 낮은 확률의 객체는 무시합니다.")
        form_layout.addRow("탐지 신뢰도:", self.conf_spin)
        
        # IOU 임계값 (NMS)
        self.iou_spin = QDoubleSpinBox()
        self.iou_spin.setRange(0.1, 1.0)
        self.iou_spin.setSingleStep(0.05)
        self.iou_spin.setValue(self.settings.get('iou_threshold', 0.7))
        self.iou_spin.setToolTip("겹치는 박스를 제거하는 기준값(0.7)입니다. 낮을수록 중복 박스가 더 많이 제거됩니다.")
        form_layout.addRow("IOU 임계값:", self.iou_spin)
        
        # 알림 로그 표시 시간 (하이라이트)
        self.log_duration_combo = QComboBox()
        self.log_duration_combo.addItems(["1분", "3분", "5분", "10분"])
        current_duration = self.settings.get('log_highlight_duration', 1)
        duration_index_map = {1: 0, 3: 1, 5: 2, 10: 3}
        self.log_duration_combo.setCurrentIndex(duration_index_map.get(current_duration, 0))
        form_layout.addRow("이벤트 로그 \n알림 강조 시간:", self.log_duration_combo)
        
        # 탐지 대상 객체 그룹
        target_group = QGroupBox("탐지 대상 객체")
        self._add_shadow(target_group)
        target_layout = QVBoxLayout(target_group)
        
        # 1. 선택된 객체 목록 (ListWidget)
        self.target_list = QListWidget()
        self.target_list.itemClicked.connect(self._on_list_item_clicked)
        target_layout.addWidget(self.target_list)
        
        # 2. 추가 컨트롤 (콤보박스 + 추가/삭제 버튼)
        control_layout = QHBoxLayout()
        
        self.class_id_edit = QLineEdit()
        self.class_id_edit.setPlaceholderText("ID")
        self.class_id_edit.setFixedWidth(60)
        self.class_id_edit.setToolTip("클래스 ID (숫자)")
        
        self.class_name_edit = QLineEdit()
        self.class_name_edit.setPlaceholderText("클래스명")
        self.class_name_edit.setToolTip("표시할 클래스 이름")

        # 색상 선택 버튼
        self.btn_color = QPushButton()
        self.btn_color.setFixedSize(24, 24)
        self.btn_color.setToolTip("색상 선택")
        self._current_color = "#888888"  # 기본값
        self._update_color_btn_style()
        self.btn_color.clicked.connect(self._on_pick_color)
        
        self.btn_add = QPushButton("추가")
        self.btn_del = QPushButton("삭제")
        
        control_layout.addWidget(self.class_id_edit)
        control_layout.addWidget(self.class_name_edit, 1)
        control_layout.addWidget(self.btn_color)
        control_layout.addWidget(self.btn_add)
        control_layout.addWidget(self.btn_del)

        self.label_class_names = QLabel("현 모델의 id/객체명 : ")
        target_layout.addWidget(self.label_class_names)
        target_layout.addLayout(control_layout)
        
        # 초기 상태 설정
        current_targets = self.settings.get('target_classes', None)
        custom_names = self.settings.get('custom_class_names', {})
        custom_colors = self.settings.get('custom_class_colors', {})

        if current_targets is not None:
            for cls_id in current_targets:
                name = custom_names.get(str(cls_id)) or custom_names.get(cls_id)
                color = custom_colors.get(str(cls_id)) or custom_colors.get(cls_id)
                self._add_item_to_list(cls_id, name, color)

        layout.addWidget(general_group, 0)
        layout.addWidget(target_group, 1)
        layout.addWidget(yolo_group, 0)
        
        # 버튼 박스
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        # 20260601 swjang 다이얼로그창에 확인, 닫기를 한글로 표시
        buttons.button(QDialogButtonBox.Ok).setText('확인')
        buttons.button(QDialogButtonBox.Cancel).setText('닫기')

        layout.addWidget(buttons)
        
        # 이벤트 연결
        self.btn_add.clicked.connect(self._on_add_class)
        self.btn_del.clicked.connect(self._on_remove_class)

    def _add_shadow(self, widget):
        """위젯에 그림자 효과 추가"""
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(15)
        shadow.setXOffset(0)
        shadow.setYOffset(2)
        
        # 테마에 따른 그림자 색상 설정
        if self.settings.get('theme') == 'Dark':
            shadow.setColor(QColor(0, 0, 0, 200))
        else:
            shadow.setColor(QColor(0, 0, 0, 50))
            
        widget.setGraphicsEffect(shadow)

    def _update_color_btn_style(self):
        """색상 버튼 스타일 업데이트"""
        self.btn_color.setStyleSheet(f"background-color: {self._current_color}; border: 1px solid #555; border-radius: 4px;")

    def _on_pick_color(self):
        """색상 선택 다이얼로그"""
        color = QColorDialog.getColor(QColor(self._current_color), self, "색상 선택")
        if color.isValid():
            self._current_color = color.name()
            self._update_color_btn_style()

    def _on_list_item_clicked(self, item):
        """리스트 아이템 클릭 시 입력창에 정보 채우기"""
        cls_id = item.data(Qt.UserRole)
        name = item.data(Qt.UserRole + 1)
        color = item.data(Qt.UserRole + 2)

        self.class_id_edit.setText(str(cls_id))
        self.class_name_edit.setText(name if name else "")
        
        if color:
            self._current_color = color
        else:
            self._current_color = "#888888"
        self._update_color_btn_style()

    def _add_item_to_list(self, cls_id, name=None, color=None):
        """리스트에 항목 추가 (이미 존재하면 이름 업데이트)"""
        # 이미 있는지 확인
        for i in range(self.target_list.count()):
            item = self.target_list.item(i)
            if item.data(Qt.UserRole) == cls_id:
                # 이름/색상 업데이트
                if name is not None:
                    item.setText(f"{name} ({cls_id})")
                    item.setData(Qt.UserRole + 1, name)
                if color is not None:
                    item.setData(Qt.UserRole + 2, color)
                    self._set_item_icon(item, color)
                return
        
        if name is None:
            name = self.COCO_CLASSES.get(cls_id, "Unknown")
            
        item = QListWidgetItem(f"{name} ({cls_id})")
        item.setData(Qt.UserRole, cls_id)
        item.setData(Qt.UserRole + 1, name)
        if color:
            item.setData(Qt.UserRole + 2, color)
            self._set_item_icon(item, color)
        self.target_list.addItem(item)

    def _set_item_icon(self, item, color_str):
        """리스트 아이템에 색상 아이콘 설정"""
        pixmap = QPixmap(12, 12)
        pixmap.fill(QColor(color_str))
        item.setIcon(QIcon(pixmap))

    def _on_add_class(self):
        """입력된 클래스 추가"""
        id_text = self.class_id_edit.text().strip()
        name_text = self.class_name_edit.text().strip()
        
        if not id_text:
            QMessageBox.warning(self, "입력 오류", "클래스 ID를 입력해주세요.")
            self.class_id_edit.setFocus()
            return

        if not id_text.isdigit():
            QMessageBox.warning(self, "입력 오류", "클래스 ID는 숫자여야 합니다.")
            self.class_id_edit.setFocus()
            return
            
        cls_id = int(id_text)
        self._add_item_to_list(cls_id, name_text if name_text else None, self._current_color)
        
        # 입력창 초기화
        self.class_id_edit.clear()
        self.class_name_edit.clear()
        self.class_id_edit.setFocus()

    def _on_remove_class(self):
        """선택된 항목 삭제"""
        row = self.target_list.currentRow()
        if row >= 0:
            # 삭제 전 확인 절차 추가 (선택 사항)
            item = self.target_list.item(row)
            confirm = QMessageBox.question(self, "삭제 확인",
                                         f"'{item.text()}' 항목을 삭제하시겠습니까?",
                                         QMessageBox.Yes | QMessageBox.No)
            if confirm == QMessageBox.Yes:
                self.target_list.takeItem(row)
        
    def get_settings(self):
        """설정값 반환"""
        duration_values = {0: 1, 1: 3, 2: 5, 3: 10}
        
        target_classes = []
        custom_class_names = {}
        custom_class_colors = {}

        for i in range(self.target_list.count()):
            item = self.target_list.item(i)
            cls_id = item.data(Qt.UserRole)
            name = item.data(Qt.UserRole + 1)
            color = item.data(Qt.UserRole + 2)

            target_classes.append(cls_id)
            if name:
                custom_class_names[str(cls_id)] = name
            if color:
                custom_class_colors[str(cls_id)] = color
        
        # 리스트가 비어있으면 None으로 설정하여 '전체 탐지'로 처리
        if not target_classes:
            target_classes = None
                
        return {
            'model_path': self.model_combo.currentText(),
            'device': self.device_combo.currentText(),
            'theme': self.theme_combo.currentText(),
            'subtitle': self.subtitle_edit.text(),
            'batch_size': self.batch_spin.value(),
            'conf_threshold': self.conf_spin.value(),
            'iou_threshold': self.iou_spin.value(),
            'log_highlight_duration': duration_values[self.log_duration_combo.currentIndex()],
            'target_classes': target_classes,
            'custom_class_names': custom_class_names,
            'custom_class_colors': custom_class_colors
        }

    def set_class_names(self, class_names):
        # 20260522 swjang 모델 초기화될때 모델의 클래스명과id가 표시되도록 수정
        # 20260601 swjang 텍스트가 길면 UI가 화면 밖으로 밀려나므로 말줄임과 툴팁 사용
        class_names_list = [f"{k}({v})" for k, v in sorted(class_names.items())]
        class_names_str = ", ".join(class_names_list)
        if len(class_names_list) > 6:
            summary_text = ', '.join(class_names_list[:6]) + f"... 총 {len(class_names)}개"
        else:
            summary_text = class_names_str
        self.label_class_names.setText(f"현 모델의 id(객체명) : {summary_text}")
        self.label_class_names.setToolTip(class_names_str)
