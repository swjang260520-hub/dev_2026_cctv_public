import PyInstaller.__main__
import os
import shutil

# --- 빌드 설정 ---
APP_NAME = "CCTV_System"
MAIN_SCRIPT = "main.py"

# 실행 파일에 포함할 데이터 파일 및 폴더 목록
# 형식: ('원본 경로', '실행 파일 내의 목적지 경로')
DATA_TO_INCLUDE = [
    ('styles', 'styles')
]

# PyInstaller 명령줄 옵션
PYINSTALLER_OPTIONS = [
    '--noconfirm', 
    '--noconsole',  # GUI 앱을 위한 콘솔 창 숨김
    '--clean',      # 빌드 전 캐시 및 임시 파일 정리
    # '--onefile',  # 모든 것을 단일 실행 파일로 묶음 (시작이 느려질 수 있음)
    '--hidden-import=numpy', # numpy 강제 포함 추가
]
# ------------------

def build():
    """PyInstaller 빌드 프로세스를 실행합니다."""
    command = [
        '--name', APP_NAME,
        *PYINSTALLER_OPTIONS
    ]

    # 데이터 파일 추가
    for source, dest in DATA_TO_INCLUDE:
        command.extend(['--add-data', f'{source}{os.pathsep}{dest}'])

    # 메인 스크립트 추가
    command.append(MAIN_SCRIPT)

    print("="*40)
    print(f"PyInstaller 빌드를 시작합니다...")
    print(f"명령어: pyinstaller {' '.join(command)}")
    print("="*40)

    try:
        PyInstaller.__main__.run(command)
        print("\n" + "="*40)
        print("✅ 빌드 성공!")
        print(f"실행 파일은 'dist\\{APP_NAME}' 폴더에서 찾을 수 있습니다.")
        
        copy_models()

        copy_styles()

        # copy_cv2()
        # 압축 실행
        # create_zip()
        copy_json()

        print("="*40)
    except Exception as e:
        print(f"\n❌ 빌드 중 오류가 발생했습니다: {e}")

def copy_models():
    """빌드된 폴더에 models 폴더를 생성하고 .pt 파일을 복사합니다."""
    src_dir = "models"
    # dist/APP_NAME/models
    dest_dir = os.path.join("dist", APP_NAME, "models")

    if not os.path.exists(src_dir):
        print(f"\n[주의] 프로젝트 루트에 '{src_dir}' 폴더가 없습니다. 모델 복사를 건너뜁니다.")
        return

    # 목적지 폴더 생성
    if not os.path.exists(dest_dir):
        os.makedirs(dest_dir)
        print(f"\n[설정] 배포 폴더 내에 '{dest_dir}' 폴더를 생성했습니다.")

    print(f"[복사] 모델 파일(.pt)을 복사합니다...")
    
    count = 0
    for file in os.listdir(src_dir):
        if file.endswith(".pt"):
            src_path = os.path.join(src_dir, file)
            dest_path = os.path.join(dest_dir, file)
            shutil.copy2(src_path, dest_path)
            print(f"  └─ {file}")
            count += 1
    
    if count == 0:
        print("  └─ 복사할 .pt 파일이 없습니다.")
    else:
        print(f"  └─ 총 {count}개의 모델 파일 복사 완료.")

import os
import shutil

def copy_cv2():
    """cv2_cv310_env 폴더의 모든 내용(폴더 포함)을 빌드된 _internal/cv2 폴더로 복사합니다."""
    src_dir = "cv2_cv310_env"
    dest_dir = os.path.join("dist", APP_NAME, "_internal", "cv2")

    # 1. 소스 폴더가 존재하는지 먼저 확인 (없으면 복사 불가)
    if not os.path.exists(src_dir):
        print(f"\n[에러] 소스 폴더 '{src_dir}'가 없습니다. 복사를 중단합니다.")
        return

    # 2. 기존 목적지 폴더가 있다면 완전히 삭제 (깨끗한 상태에서 복사하기 위함)
    if os.path.exists(dest_dir):
        try:
            shutil.rmtree(dest_dir)
            print(f"\n[정보] 기존 '{dest_dir}' 폴더를 삭제했습니다.")
        except Exception as e:
            print(f"\n[에러] 폴더 삭제 중 오류 발생: {e}")
            return

    # 3. 폴더 전체 복사 (하위 폴더 및 파일 모두 포함)
    try:
        # shutil.copytree는 목적지 폴더가 없어야 하며, 폴더 자체를 생성하면서 내부를 복사합니다.
        shutil.copytree(src_dir, dest_dir)
        print(f"[성공] '{src_dir}'의 모든 파일과 폴더를 '{dest_dir}'로 복사 완료했습니다.")
    except Exception as e:
        print(f"\n[에러] 복사 중 오류 발생: {e}")


def create_zip():
    """빌드된 폴더를 압축하여 배포 파일을 생성합니다."""
    print(f"\n[압축] 배포용 압축 파일 생성 중...")
    
    base_name = os.path.join("dist", APP_NAME)
    root_dir = "dist"
    base_dir = APP_NAME
    
    try:
        if not os.path.exists(os.path.join(root_dir, base_dir)):
             print(f"❌ 압축 대상 폴더를 찾을 수 없습니다: {os.path.join(root_dir, base_dir)}")
             return

        archive_path = shutil.make_archive(base_name, 'zip', root_dir, base_dir)
        print(f"✅ 압축 완료: {archive_path}")
    except Exception as e:
        print(f"❌ 압축 실패: {e}")


def copy_styles():
    """빌드된 폴더에 models 폴더를 생성하고 .pt 파일을 복사합니다."""
    src_dir = "styles"
    # dist/APP_NAME/models
    dest_dir = os.path.join("dist", APP_NAME, "styles")

    if not os.path.exists(src_dir):
        print(f"\n[주의] 프로젝트 루트에 '{src_dir}' 폴더가 없습니다.")
        return

    # 목적지 폴더 생성
    if not os.path.exists(dest_dir):
        os.makedirs(dest_dir)
        print(f"\n[설정] 배포 폴더 내에 '{dest_dir}' 폴더를 생성했습니다.")

    print(f"[복사] 스타일 (styles) 을 복사합니다...")

    count = 0
    for file in os.listdir(src_dir):      
        src_path = os.path.join(src_dir, file)
        dest_path = os.path.join(dest_dir, file)
        
        if os.path.isdir(src_path):
            if os.path.exists(dest_path):
                shutil.rmtree(dest_path)
            shutil.copytree(src_path, dest_path)
        else:
            shutil.copy2(src_path, dest_path)
            
        print(f"  └─ {file}")
        count += 1


def copy_json():
    """설정 파일 및 키 파일을 빌드된 폴더로 복사합니다."""
    # 복사할 파일 목록 (파일명, 설명)
    files_to_copy = [
        ('app_settings.json', '앱 설정 파일'),
        ('cameras_info.json', '카메라 설정 파일'),
        ('cctv_key.bin', '보안 키 파일')
    ]

    # 목적지 경로: dist/CCTV_System
    dest_dir = os.path.join("dist", APP_NAME)

    if not os.path.exists(dest_dir):
        print(f"\n[에러] 목적지 폴더를 찾을 수 없습니다: {dest_dir}")
        return

    print(f"\n[복사] 설정 및 보안 파일을 복사합니다...")

    success_count = 0
    for file_name, description in files_to_copy:
        if os.path.exists(file_name):
            try:
                shutil.copy2(file_name, os.path.join(dest_dir, file_name))
                print(f"  └─ {file_name} ({description}) 복사 완료")
                success_count += 1
            except Exception as e:
                print(f"  └─ ❌ {file_name} 복사 중 오류 발생: {e}")
        else:
            print(f"  └─ ⚠️ {file_name} 파일을 찾을 수 없어 건너뜁니다.")

    print(f"  └─ 총 {success_count}개의 파일 복사 완료.")



if __name__ == "__main__":
    build()