"""
core/detector.py
YOLO 객체 탐지 비즈니스 로직 - UI 의존성 없음
"""

import time
import os
import sys
import random
from typing import Optional, List, Dict, Tuple
from abc import ABC, abstractmethod
from loguru import logger
import numpy as np

os.environ["NO_ALBUMENTATIONS_UPDATE"] = "1"
os.environ["ALBUMENTATIONS_OFFLINE"] = "1"
os.environ["ALBUMENTATIONS_DISABLE_VERSION_CHECK"] = "1"

from .models import Detection, FrameData

# --- 선택적 라이브러리 임포트 및 사용 가능 여부 확인 ---
try:
    import tensorrt as trt
    TRT_AVAILABLE = True
except ImportError:
    TRT_AVAILABLE = False
    logger.debug("TensorRT가 설치되지 않았습니다. .engine 모델을 사용할 수 없습니다.")

try:
    import onnxruntime
    ONNX_AVAILABLE = True
except ImportError:
    ONNX_AVAILABLE = False
    logger.debug("ONNX Runtime이 설치되지 않았습니다. .onnx 모델을 사용할 수 없습니다.")
# ----------------------------------------------------


class DetectorBase(ABC):
    """모든 탐지기 클래스를 위한 추상 기본 클래스"""

    def __init__(self, model_path: str, device: str):
        self.model_path = model_path
        self.device = device
        self._is_loaded = False
        self._class_names: Dict[int, str] = {}
        self.input_shape: Tuple[int, int] = (640, 640) # 기본값

    @abstractmethod
    def load_model(self) -> bool:
        """모델 로드"""
        raise NotImplementedError

    def detect(self, frame_data: FrameData, conf_threshold: float, iou_threshold: float, classes: Optional[List[int]]) -> FrameData:
        """단일 프레임에 대한 객체 탐지 수행 (기본 구현)"""
        if not self.is_loaded or frame_data.frame is None:
            return frame_data
        
        # 단일 프레임을 리스트에 담아 배치 처리 메서드 호출
        results = self.detect_batch([frame_data], conf_threshold, iou_threshold, classes)
        return results[0]

    @abstractmethod
    def detect_batch(self, frame_data_list: List[FrameData], conf_threshold: float, iou_threshold: float, classes: Optional[List[int]]) -> List[FrameData]:
        """배치 객체 탐지 수행"""
        raise NotImplementedError

    def _get_model_path(self) -> str:
        """PyInstaller 환경을 고려하여 모델 파일의 절대 경로를 반환합니다."""
        if getattr(sys, 'frozen', False):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

        models_dir = os.path.join(base_dir, "models")
        
        if not os.path.isabs(self.model_path):
             return os.path.join(models_dir, self.model_path)
        return self.model_path

    def _load_class_names(self, model_file_path: str):
        """모델 파일 경로에 기반하여 동반된 .json 파일에서 클래스 이름을 로드합니다."""
        class_file = os.path.splitext(model_file_path)[0] + '.json'
        if os.path.exists(class_file):
            import json
            with open(class_file, 'r') as f:
                class_data = json.load(f)
                self._class_names = {int(k): v for k, v in class_data.items()}
        else:
            logger.warning(f"{class_file}을 찾을 수 없습니다. 클래스 이름이 'class_xx' 형식으로 표시됩니다.")
            self._class_names = {i: f'class_{i}' for i in range(80)} # 기본 80개로 가정

    def _common_preprocess(self, img: np.ndarray) -> Tuple[np.ndarray, float, Tuple[float, float]]:
        """여러 탐지기에서 공유하는 표준 전처리 로직입니다."""
        import cv2
        
        input_h, input_w = 640, 640
        h, w = img.shape[:2]

        r = min(input_h / h, input_w / w)
        resized_w, resized_h = int(w * r), int(h * r)
        
        if resized_w != w or resized_h != h:
            resized_img = cv2.resize(img, (resized_w, resized_h), interpolation=cv2.INTER_LINEAR)
        else:
            resized_img = img

        dw, dh = (input_w - resized_w) / 2, (input_h - resized_h) / 2
        top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
        left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
        
        padded_img = cv2.copyMakeBorder(resized_img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(114, 114, 114))

        transposed_img = padded_img.transpose(2, 0, 1)[::-1]  # BGR->RGB, HWC->CHW
        normalized_img = np.ascontiguousarray(transposed_img, dtype=np.float32) / 255.0
        
        return normalized_img, r, (dw, dh)

    def _common_postprocess(self, output: np.ndarray, ratio: float, pad: Tuple[float, float], orig_shape: Tuple[int, int], conf_thres: float, iou_thres: float, classes: Optional[List[int]]) -> List[Detection]:
        """여러 탐지기에서 공유하는 표준 후처리 로직입니다."""
        num_classes = len(self._class_names)
        
        # Ultralytics의 출력 형식 (batch, 4+num_classes, num_proposals)을 가정
        output = output.transpose(0, 2, 1)[0] # (num_proposals, 4+num_classes)
        
        conf_mask = output[:, 4] > conf_thres
        output = output[conf_mask]
        if not output.shape[0]: return []
        
        class_conf = output[:, 5:]
        class_ids = np.argmax(class_conf, axis=1)
        class_scores = np.max(class_conf, axis=1) * output[:, 4]

        final_conf_mask = class_scores > conf_thres
        output, class_ids, class_scores = output[final_conf_mask], class_ids[final_conf_mask], class_scores[final_conf_mask]
        if not output.shape[0]: return []

        if classes:
            class_filter_mask = np.isin(class_ids, classes)
            output, class_ids, class_scores = output[class_filter_mask], class_ids[class_filter_mask], class_scores[class_filter_mask]
        if not output.shape[0]: return []

        box = output[:, :4]
        cx, cy, w, h = box[:, 0], box[:, 1], box[:, 2], box[:, 3]
        x1 = (cx - w / 2 - pad[0]) / ratio
        y1 = (cy - h / 2 - pad[1]) / ratio
        x2 = (cx + w / 2 - pad[0]) / ratio
        y2 = (cy + h / 2 - pad[1]) / ratio
        boxes = np.stack((x1, y1, x2, y2), axis=1)

        # Non-Maximum Suppression (NMS)
        try:
            import torch, torchvision
            indices = torchvision.ops.nms(torch.from_numpy(boxes), torch.from_numpy(class_scores), iou_thres).numpy()
        except (ImportError, Exception):
            logger.warning("torchvision.ops.nms를 사용할 수 없어 NMS를 건너뜁니다.")
            indices = np.arange(len(boxes))

        detections = []
        orig_h, orig_w = orig_shape
        for i in indices:
            x1, y1, x2, y2 = boxes[i]
            # 좌표가 원본 이미지 경계를 벗어나지 않도록 클리핑
            x1, y1 = max(0, int(x1)), max(0, int(y1))
            x2, y2 = min(orig_w, int(x2)), min(orig_h, int(y2))

            class_id = class_ids[i]
            detections.append(Detection(
                class_id=class_id, class_name=self.class_names.get(class_id, "unknown"),
                confidence=float(class_scores[i]),
                x=x1, y=y1, width=x2 - x1, height=y2 - y1
            ))
        return detections

    @property
    def is_loaded(self) -> bool: return self._is_loaded
    @property
    def class_names(self) -> Dict[int, str]: return self._class_names


class YOLODetector(DetectorBase):
    """YOLO 객체 탐지기 (ultralytics, .pt 파일용)"""
    def __init__(self, model_path: str, device: str = "auto"):
        super().__init__(model_path, device)
        self._model = None
        
    def load_model(self) -> bool:
        try:
            from ultralytics import YOLO
            model_file = self._get_model_path()
            self._model = YOLO(model_file)
            logger.info(f"YOLO 모델 로드 완료: {model_file} ({self.device})")
            if self.device != "auto": self._model.to(self.device)
            self._class_names = self._model.names
            self._is_loaded = True
            return True
        except Exception as e:
            logger.exception(f"YOLO 모델 로드 중 오류 발생: {e}")
            self._is_loaded = False
            return False
    
    def detect_batch(self, frame_data_list: List[FrameData], conf_threshold: float, iou_threshold: float, classes: Optional[List[int]]) -> List[FrameData]:
        if not self.is_loaded or self._model is None or not frame_data_list: return frame_data_list
        start_time = time.time()
        try:
            frames = [fd.frame for fd in frame_data_list]
            use_half = (self.device == 'cuda' or (self.device == 'auto' and hasattr(self._model.device, 'type') and self._model.device.type == 'cuda'))
            results_batch = self._model(frames, conf=conf_threshold, iou=iou_threshold, classes=classes, verbose=False, half=use_half)
            
            avg_inference_time_ms = ((time.time() - start_time) * 1000) / len(frame_data_list)
            for i, results in enumerate(results_batch):
                detections = self._parse_ultralytics_results([results], frame_data_list[i].frame.shape[:2])
                frame_data_list[i].detections = detections
                frame_data_list[i].inference_time_ms = avg_inference_time_ms
        except Exception as e:
            logger.exception(f"배치 탐지 오류: {e}")
        return frame_data_list

    def _parse_ultralytics_results(self, results: list, orig_shape: Tuple[int, int]) -> List[Detection]:
        detections = []
        if not results: return detections
        result = results[0]
        if result.boxes is None: return detections

        orig_h, orig_w = orig_shape
        for box in result.boxes:
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            # 좌표가 원본 이미지 경계를 벗어나지 않도록 클리핑
            x1, y1 = max(0, int(x1)), max(0, int(y1))
            x2, y2 = min(orig_w, int(x2)), min(orig_h, int(y2))

            class_id = int(box.cls)
            detections.append(Detection(
                class_id=class_id, class_name=self.class_names.get(class_id, "unknown"),
                confidence=float(box.conf), x=x1, y=y1, width=x2 - x1, height=y2 - y1
            ))
        return detections


if ONNX_AVAILABLE:
    class ONNXDetector(DetectorBase):
        """YOLO 객체 탐지기 (ONNX Runtime, .onnx 파일용)"""
        def __init__(self, model_path: str, device: str = "auto"):
            super().__init__(model_path, device)
            self.session = None
            self.input_name = None
            self.output_name = None

        def load_model(self) -> bool:
            try:
                model_file = self._get_model_path()
                providers = []
                if self.device == 'cuda':
                    providers = [('TensorRTExecutionProvider', {'trt_fp16_enable': True}), ('CUDAExecutionProvider', {'device_id': 0}), 'CPUExecutionProvider']
                else: # cpu or auto
                    providers = ['CPUExecutionProvider']
                
                self.session = onnxruntime.InferenceSession(model_file, providers=providers)
                logger.info(f"ONNX 모델 로드 완료: {model_file} (실행 프로바이더: {self.session.get_providers()})")

                input_meta = self.session.get_inputs()[0]
                self.input_name = input_meta.name
                self.input_shape = tuple(input_meta.shape[2:])

                self.output_name = self.session.get_outputs()[0].name
                
                self._load_class_names(model_file)
                self._is_loaded = True
                return True
            except Exception as e:
                logger.exception(f"ONNX 모델 로드 중 오류 발생: {e}")
                self._is_loaded = False
                return False

        def detect_batch(self, frame_data_list: List[FrameData], conf_threshold: float, iou_threshold: float, classes: Optional[List[int]]) -> List[FrameData]:
            if not self.is_loaded or self.session is None or not frame_data_list: return frame_data_list
            start_time = time.time()
            
            # 배치 전처리
            batch_input = []
            ratios_paddings = []
            orig_shapes = []
            for fd in frame_data_list:
                input_image, ratio, pad = self._common_preprocess(fd.frame)
                batch_input.append(input_image)
                ratios_paddings.append((ratio, pad))
                orig_shapes.append(fd.frame.shape[:2])
            
            batch_input_np = np.concatenate(batch_input, axis=0)

            # 추론
            outputs = self.session.run([self.output_name], {self.input_name: batch_input_np})
            
            avg_inference_time_ms = ((time.time() - start_time) * 1000) / len(frame_data_list)
            
            # 배치 후처리
            for i in range(len(frame_data_list)):
                output = outputs[0][i:i+1] # i번째 결과 추출
                ratio, pad = ratios_paddings[i]
                orig_shape = orig_shapes[i]
                detections = self._common_postprocess(output, ratio, pad, orig_shape, conf_threshold, iou_threshold, classes)
                frame_data_list[i].detections = detections
                frame_data_list[i].inference_time_ms = avg_inference_time_ms
                
            return frame_data_list


if TRT_AVAILABLE:
    class TensorRTDetector(DetectorBase):
        """YOLO 객체 탐지기 (TensorRT, .engine 파일용)"""
        def __init__(self, model_path: str, device: str = "cuda"):
            super().__init__(model_path, device)
            if self.device != "cuda":
                logger.warning("TensorRTDetector는 'cuda' 장치만 지원합니다. 강제로 'cuda'로 설정됩니다.")
                self.device = "cuda"
            self.engine, self.context, self.inputs, self.outputs, self.bindings, self.stream = None, None, None, None, None, None

        def load_model(self) -> bool:
            try:
                import torch
                TRT_LOGGER = trt.Logger(trt.Logger.WARNING)
                runtime = trt.Runtime(TRT_LOGGER)
                model_file = self._get_model_path()
                with open(model_file, 'rb') as f: self.engine = runtime.deserialize_cuda_engine(f.read())
                if self.engine is None: raise RuntimeError("TensorRT 엔진 로드 실패")
                self.context = self.engine.create_execution_context()
                self.inputs, self.outputs, self.bindings, self.stream = self._allocate_buffers()
                self.input_shape = tuple(self.engine.get_binding_shape(0)[2:])
                self._load_class_names(model_file)
                self._is_loaded = True
                logger.info(f"TensorRT 엔진 로드 완료: {model_file}")
                return True
            except Exception as e:
                logger.exception(f"TensorRT 엔진 로드 중 오류 발생: {e}")
                self._is_loaded = False
                return False

        def _allocate_buffers(self):
            import torch
            inputs, outputs, bindings = [], [], []
            stream = torch.cuda.Stream()
            for binding in self.engine:
                size = trt.volume(self.engine.get_binding_shape(binding)) * self.engine.max_batch_size
                dtype = trt.nptype(self.engine.get_binding_dtype(binding))
                
                # PyTorch를 사용하여 GPU 메모리 할당
                t_dtype = torch.from_numpy(np.array([], dtype=dtype)).dtype
                device_mem = torch.empty(size, dtype=t_dtype, device=self.device)
                
                bindings.append(int(device_mem.data_ptr()))
                if self.engine.binding_is_input(binding): inputs.append(device_mem)
                else: outputs.append(device_mem)
            return inputs, outputs, bindings, stream

        def detect_batch(self, frame_data_list: List[FrameData], conf_threshold: float, iou_threshold: float, classes: Optional[List[int]]) -> List[FrameData]:
            # 참고: 이 구현은 간단한 단일 처리 반복입니다. 진정한 배치 처리를 위해서는 버퍼 관리를 수정해야 합니다.
            for fd in frame_data_list:
                self.detect(fd, conf_threshold, iou_threshold, classes)
            return frame_data_list
        
        def detect(self, frame_data: FrameData, conf_threshold: float, iou_threshold: float, classes: Optional[List[int]]) -> FrameData:
            if not self.is_loaded or frame_data.frame is None: return frame_data
            import torch
            start_time = time.time()
            input_image, ratio, pad = self._common_preprocess(frame_data.frame)
            
            # 입력 데이터를 GPU 텐서로 복사
            self.inputs[0].copy_(torch.from_numpy(input_image.ravel()))
            
            # 추론 실행 (torch stream 사용)
            self.context.execute_async_v2(bindings=self.bindings, stream_handle=self.stream.cuda_stream)
            
            # 결과 가져오기 (CPU로 이동 시 자동 동기화됨)
            output_data = self.outputs[0].cpu().numpy().reshape(1, -1, self.engine.get_binding_shape(1)[2])
            
            detections = self._common_postprocess(output_data, ratio, pad, frame_data.frame.shape[:2], conf_threshold, iou_threshold, classes)
            frame_data.detections = detections
            frame_data.inference_time_ms = (time.time() - start_time) * 1000
            return frame_data


class DummyDetector(DetectorBase):
    """테스트용 더미 탐지기"""
    def __init__(self, model_path: str = "dummy", device: str = "cpu"):
        super().__init__(model_path, device)
        self._class_names = {0: "person", 1: "car", 2: "dog"}
    
    def load_model(self) -> bool:
        self._is_loaded = True
        return True
    
    def detect_batch(self, frame_data_list: List[FrameData], **kwargs) -> List[FrameData]:
        for fd in frame_data_list: self.detect(fd, **kwargs)
        return frame_data_list

    def detect(self, frame_data: FrameData, **kwargs) -> FrameData:
        if frame_data.frame is None: return frame_data
        h, w = frame_data.frame.shape[:2]
        num_detections = random.randint(0, 3)
        detections = []
        for _ in range(num_detections):
            det_w, det_h = random.randint(50, 200), random.randint(50, 200)
            det_x, det_y = random.randint(0, max(0, w - det_w)), random.randint(0, max(0, h - det_h))
            class_id = random.choice(list(self.class_names.keys()))
            detections.append(Detection(
                class_id=class_id, class_name=self.class_names[class_id],
                confidence=random.uniform(0.5, 0.99),
                x=det_x, y=det_y, width=det_w, height=det_h
            ))
        frame_data.detections = detections
        frame_data.inference_time_ms = random.uniform(5, 25)
        return frame_data


def create_detector(model_path: str, device: str = "auto") -> DetectorBase:
    """
    모델 경로와 장치에 따라 적절한 탐지기 인스턴스를 생성하는 팩토리 함수.
    :param model_path: 모델 파일 경로 또는 "dummy"
    :param device: "auto", "cpu", "cuda" 등
    :return: DetectorBase를 상속받은 탐지기 객체
    """
    if model_path == "dummy":
        logger.info("더미 탐지기를 생성합니다.")
        return DummyDetector(model_path, device)

    file_extension = os.path.splitext(model_path)[1].lower()
    
    if file_extension == ".pt":
        logger.info(f"YOLO(.pt) 탐지기를 생성합니다: {model_path}")
        return YOLODetector(model_path, device)
    
    elif file_extension == ".engine":
        if TRT_AVAILABLE:
            logger.info(f"TensorRT(.engine) 탐지기를 생성합니다: {model_path}")
            return TensorRTDetector(model_path, device)
        else:
            raise ValueError(".engine 파일을 사용하려면 'tensorrt'가 설치되어야 합니다.")
    
    elif file_extension == ".onnx":
        if ONNX_AVAILABLE:
            logger.info(f"ONNX Runtime(.onnx) 탐지기를 생성합니다: {model_path}")
            return ONNXDetector(model_path, device)
        else:
            raise ValueError(".onnx 파일을 사용하려면 'onnxruntime' 또는 'onnxruntime-gpu'가 설치되어야 합니다.")
            
    else:
        raise ValueError(f"지원하지 않는 모델 파일 형식입니다: {file_extension}. (.pt, .engine, .onnx, dummy만 지원)")