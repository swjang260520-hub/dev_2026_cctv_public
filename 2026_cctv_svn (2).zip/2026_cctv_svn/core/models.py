"""
core/models.py
순수 Python 데이터 모델 - UI 의존성 없음
"""

from dataclasses import dataclass, field
from typing import Optional, List, Tuple, Dict
from enum import Enum, auto
from urllib.parse import quote
import numpy as np
import time
import uuid

from LeaCrypto import LeaUtil


class CameraStatus(Enum):
    """카메라 상태"""
    DISCONNECTED = auto()
    CONNECTING = auto()
    ACTIVE = auto()
    ERROR = auto()
    PAUSED = auto()


@dataclass
class Detection:
    """단일 탐지 결과"""
    class_id: int
    class_name: str
    confidence: float
    x: int
    y: int
    width: int
    height: int
    
    @property
    def bbox_xyxy(self) -> Tuple[int, int, int, int]:
        """(x1, y1, x2, y2) 형식"""
        return (self.x, self.y, self.x + self.width, self.y + self.height)
    
    @property
    def bbox_xywh(self) -> Tuple[int, int, int, int]:
        """(x, y, width, height) 형식"""
        return (self.x, self.y, self.width, self.height)
    
    @property
    def center(self) -> Tuple[int, int]:
        """중심점"""
        return (self.x + self.width // 2, self.y + self.height // 2)


@dataclass
class FrameData:
    """프레임 + 탐지결과 묶음 (하이브리드 핵심)"""
    camera_id: str
    frame: np.ndarray
    timestamp: float = field(default_factory=time.time)
    frame_number: int = 0
    detections: List[Detection] = field(default_factory=list)
    inference_time_ms: float = 0.0
    fps: float = 0.0
    
    @property
    def has_detections(self) -> bool:
        return len(self.detections) > 0
    
    @property
    def detection_count(self) -> int:
        return len(self.detections)
    
    @property
    def frame_size(self) -> Tuple[int, int]:
        """(width, height)"""
        if self.frame is not None:
            return (self.frame.shape[1], self.frame.shape[0])
        return (0, 0)


@dataclass
class CameraConfig:
    """카메라 설정"""
    camera_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    name: str = "새 카메라"
    source: str = ""
    source_type: str = "rtsp"
    username: str = ""
    password: str = ""
    enabled: bool = False
    autostart: bool = False
    display_enabled: bool = True
    detection_enabled: bool = False
    recording_enabled: bool = False
    reconnect_interval: float = 5.0
    buffer_size: int = 1
    target_fps: int = 30
    disable_resize: bool = False  # False: 기본 분할 화면 모드 (640px 제한), True: 단독/최대화 화면 모드 (FHD 1920px 제한)

    lea = LeaUtil()


    def get_full_url(self) -> str:
        """인증 정보가 포함된 전체 URL 반환"""
        if self.source_type == "rtsp" and self.username:
            if "://" in self.source:
                safe_user = quote(str(self.username), safe='')
                # 20260520 swjang rtsp url 만들때 pwd를 복호화 함
                password = CameraConfig.lea.decrypt(self.password)
                safe_pass = quote(str(password) if password is not None else '', safe='')
                print("password: ", self.password, safe_pass)

                protocol, rest = self.source.split("://", 1)
                return f"{protocol}://{safe_user}:{safe_pass}@{rest}"
        return self.source
    
    def get_opencv_source(self):
        """OpenCV VideoCapture에 전달할 소스 반환 (USB 카메라는 int, 나머지는 str)"""
        if self.source_type == "usb":
            if isinstance(self.source, int):
                return self.source
            source_str = str(self.source)
            return int(source_str) if source_str.isdigit() else 0
        return self.get_full_url()

    def to_dict(self) -> Dict:
        """딕셔너리로 변환"""
        return {
            'camera_id': self.camera_id,
            'name': self.name,
            'source': self.source,
            'source_type': self.source_type,
            'username': self.username,
            'password': self.password,
            'enabled': self.enabled,
            'autostart': self.autostart,
            'display_enabled': self.display_enabled,
            'detection_enabled': self.detection_enabled,
            'recording_enabled': self.recording_enabled,
            'target_fps': self.target_fps,
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'CameraConfig':
        """딕셔너리에서 생성"""
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class CameraState:
    """카메라 런타임 상태"""
    camera_id: str
    status: CameraStatus = CameraStatus.DISCONNECTED
    current_fps: float = 0.0
    frame_width: int = 0
    frame_height: int = 0
    total_frames: int = 0
    detection_count: int = 0
    last_error: str = ""
    last_frame_time: float = 0.0