"""
gui/workers.py
QThread 기반 워커 클래스 - Signal/Slot으로 UI와 통신
"""

from PySide6.QtCore import QThread, Signal, QMutex, QWaitCondition
import time
from typing import Optional, Dict
from loguru import logger

# 순수 Python 로직 임포트
from .models import CameraConfig, CameraStatus, FrameData
from .camera_manager import CameraCapture
from .detector import create_detector, DetectorBase, DummyDetector


class CameraWorker(QThread):
    """
    카메라 영상 수신 워커
    - 카메라당 1개 스레드
    - 프레임을 수신하여 Signal로 전달
    """
    
    # 시그널 정의
    frame_captured = Signal(object)              # FrameData
    status_changed = Signal(str, object)         # (camera_id, CameraStatus)
    error_occurred = Signal(str, str)            # (camera_id, error_message)
    resolution_detected = Signal(str, int, int)  # (camera_id, width, height)
    
    def __init__(self, config: CameraConfig, parent=None):
        super().__init__(parent)
        self.config = config
        self._capture = CameraCapture(config)
        
        self._running = False
        self._paused = False
        self._mutex = QMutex()
        self._pause_condition = QWaitCondition()
        self._reconnect_condition = QWaitCondition()

        self._failure_count = 0
        self.MAX_FAILURES = 5
        self.MAX_BACKOFF_S = 300  # 5분

    def run(self):
        """메인 캡처 루프"""
        self._running = True
        
        while self._running:
            try:
                # 연결 시도
                self.status_changed.emit(self.config.camera_id, CameraStatus.CONNECTING)
                
                if not self._capture.connect():
                    raise ConnectionError(f"카메라 연결 실패: {self.config.source}")

                # 연결 성공 시 실패 카운트 리셋
                self._mutex.lock()
                if self._failure_count > 0:
                    self._failure_count = 0
                    self.error_occurred.emit(self.config.camera_id, "카메라 연결 성공.")
                self._mutex.unlock()

                # 해상도 전달
                w, h = self._capture.frame_size
                self.resolution_detected.emit(self.config.camera_id, w, h)

                # ================================================================= #
                # <<< FPS 기반 재생 속도 조절 로직 추가 >>>
                # ================================================================= #
                delay_ms = 0
                # 간단한 휴리스틱: 소스가 rtsp로 시작하지 않으면 파일로 간주
                is_video_file = not str(self.config.source).startswith("rtsp://")

                fps = self._capture.source_fps
                if is_video_file and fps > 0:
                    delay_ms = int(1000 / fps)
                    # logger.info(f"'{self.config.camera_id}'는 동영상 파일입니다. FPS({fps:.2f})에 맞춰 {delay_ms}ms 딜레이를 적용합니다.")
                # ================================================================= #

                # 전송률 제한 (Throttling) 설정
                target_emit_fps = self.config.target_fps
                min_emit_interval = 1.0 / target_emit_fps if target_emit_fps > 0 else 0
                last_emit_time = 0.0

                self.status_changed.emit(self.config.camera_id, CameraStatus.ACTIVE)
                
                # 프레임 캡처 루프
                while self._running:
                    # 일시정지 처리
                    self._mutex.lock()
                    while self._paused and self._running:
                        self.status_changed.emit(self.config.camera_id, CameraStatus.PAUSED)
                        self._pause_condition.wait(self._mutex)
                    self._mutex.unlock()
                    
                    if not self._running:
                        break
                    
                    # 프레임 읽기
                    frame_data = self._capture.read_frame()
                    
                    if frame_data is None:
                        if is_video_file:
                            logger.info(f"동영상 파일 '{self.config.camera_id}' 재생이 완료되었습니다.")
                            break  # 동영상 파일이 끝나면 정상적으로 루프 종료
                        raise ConnectionError("프레임 수신 실패")
                    
                    # 프레임 전달 (전송률 제한)
                    current_time = time.time()
                    if min_emit_interval == 0 or (current_time - last_emit_time >= min_emit_interval):
                        self.frame_captured.emit(frame_data)
                        last_emit_time = current_time
                    
                    # CPU 부하 조절 -> FPS 기반 딜레이로 변경
                    if delay_ms > 0:
                        self.msleep(delay_ms)
                    else:
                        # 실시간 스트림의 경우 최소한의 딜레이로 CPU 부하 줄임
                        self.msleep(1)
                    
            except Exception as e:
                logger.exception(f"CameraWorker 오류 ({self.config.camera_id})")
                self._mutex.lock()
                self._failure_count += 1
                self.status_changed.emit(self.config.camera_id, CameraStatus.ERROR)
                self.error_occurred.emit(self.config.camera_id, f"오류: {e} ({self._failure_count}/{self.MAX_FAILURES})")

                if self._running:
                    if self._failure_count >= self.MAX_FAILURES:
                        self.status_changed.emit(self.config.camera_id, CameraStatus.PAUSED)
                        self.error_occurred.emit(self.config.camera_id, f"{self.MAX_FAILURES}회 연속 실패. 자동 재시도를 중단합니다.")
                        self._reconnect_condition.wait(self._mutex)  # 무한 대기
                    else:
                        # Exponential backoff
                        backoff_time_s = min(
                            self.config.reconnect_interval * (2 ** (self._failure_count - 1)),
                            self.MAX_BACKOFF_S
                        )
                        self.error_occurred.emit(self.config.camera_id, f"{backoff_time_s:.0f}초 후 재시도합니다.")
                        self._reconnect_condition.wait(self._mutex, int(backoff_time_s * 1000))
                self._mutex.unlock()
                    
            finally:
                self._capture.release()
        
        self.status_changed.emit(self.config.camera_id, CameraStatus.DISCONNECTED)

    def reconnect(self):
        """수동 재연결 요청"""
        self._mutex.lock()
        self._reconnect_condition.wakeAll()
        self._mutex.unlock()
    
    def pause(self):
        """일시정지"""
        self._mutex.lock()
        self._paused = True
        self._mutex.unlock()
    
    def resume(self):
        """재개"""
        self._mutex.lock()
        self._paused = False
        self._pause_condition.wakeAll()
        self._mutex.unlock()
    
    def stop(self):
        """정지"""
        self._running = False
        self.resume()
        
        # 재연결 대기 중인 경우 스레드를 깨움
        self._mutex.lock()
        self._reconnect_condition.wakeAll()
        self._mutex.unlock()
        
        self.wait(3000)
    
    def update_config(self, config: CameraConfig):
        """설정 업데이트"""
        self.config = config


class InferenceWorker(QThread):
    """
    YOLO 추론 워커
    - 전체 시스템에서 1~2개 (GPU당 1개)
    - 여러 카메라의 프레임을 받아 배치 처리
    """
    
    # 시그널
    inference_complete = Signal(object)  # FrameData (프레임 + 탐지결과)
    model_loaded = Signal(bool, object)  # 모델 로드 완료 (성공여부, 클래스 이름 딕셔너리)
    error_occurred = Signal(str)         # 에러 발생 시그널
    
    def __init__(self, model_path: str = "yolo11n.pt", 
                 device: str = "auto",
                 use_dummy: bool = False,
                 batch_size: int = 8,
                 parent=None):
        super().__init__(parent)
        self.model_path = model_path
        self.device = device
        self.use_dummy = use_dummy
        self.batch_size = batch_size
        
        self._running = False
        self._detector: Optional[DetectorBase] = None
        
        # 프레임 큐 (카메라별 최신 프레임만 유지)
        self._frame_queue: Dict[str, FrameData] = {}
        self._queue_mutex = QMutex()
        self._queue_condition = QWaitCondition()
        
        # 설정
        self.conf_threshold = 0.4
        self.iou_threshold = 0.7
        self.target_classes = None  # None이면 전체
        
        # 프레임 드랍을 위한 FPS 제한 (UI 버벅임 방지)
        self.inference_fps_limit = 10.0  # 카메라당 초당 최대 추론 횟수
        self._last_inference_time: Dict[str, float] = {}
        
        # 성능 모니터링 통계
        self._stats_last_time = time.time()
        self._stats_processed = 0
        self._stats_dropped = 0
    
    def run(self):
        """추론 루프"""
        self._running = True
        
        # 모델 로드
        success = False
        try:
            model_to_load = "dummy" if self.use_dummy else self.model_path
            self._detector = create_detector(model_to_load, self.device)
            success = self._detector.load_model()
        except Exception as e:
            logger.error(f"탐지기 생성 또는 모델 로드 실패: {e}")
            self.error_occurred.emit(f"모델 로드 실패: {e}")
            success = False

        if not success:
            logger.warning("모델 로드 실패, 더미 모드로 자동 전환합니다.")
            self.error_occurred.emit("모델 로드에 실패하여 더미 모드로 작동합니다.")
            self._detector = DummyDetector() # Fallback to dummy
            self._detector.load_model()

        self.model_loaded.emit(success, self._detector.class_names)
        
        # 추론 루프
        while self._running:
            # 큐에서 프레임 가져오기
            self._queue_mutex.lock()
            
            # 큐가 비어있으면 대기
            while not self._frame_queue and self._running:
                self._queue_condition.wait(self._queue_mutex, 100)
            
            if not self._running:
                self._queue_mutex.unlock()
                break
            
            # 현재 큐의 모든 프레임 가져오기
            frames_to_process = dict(self._frame_queue)
            self._frame_queue.clear()
            self._queue_mutex.unlock()
            
            if not frames_to_process:
                continue
            
            # --- 프레임 드랍 (FPS 제한) ---
            now = time.time()
            min_interval = 1.0 / self.inference_fps_limit if self.inference_fps_limit > 0 else 0
            
            targets = []
            for cid, data in frames_to_process.items():
                if now - self._last_inference_time.get(cid, 0) >= min_interval:
                    targets.append(data)
                    self._last_inference_time[cid] = now
        #### 성능 측정 때문에 추가한 코드 - 시작
                else:
                    self._stats_dropped += 1

            # 통계 업데이트 및 로그 출력
            self._stats_processed += len(targets)

            if now - self._stats_last_time >= 5.0:
                elapsed = now - self._stats_last_time
                fps = self._stats_processed / elapsed if elapsed > 0 else 0
                logger.debug(f"[Inference] FPS: {fps:.2f} | Processed: {self._stats_processed} | Dropped: {self._stats_dropped} (Last {elapsed:.1f}s)")

                self._stats_last_time = now
                self._stats_processed = 0
                self._stats_dropped = 0
        #### 성능 측정 때문에 추가한 코드 - 끝
            if not targets:
                continue

            # 추론 수행
            try:
                frame_list = targets
                
                for i in range(0, len(frame_list), self.batch_size):
                    batch_frames = frame_list[i : i + self.batch_size]
                    
                    results = self._detector.detect_batch(
                        batch_frames,
                        conf_threshold=self.conf_threshold,
                        iou_threshold=self.iou_threshold,
                        classes=self.target_classes
                    )
                    
                    # 결과 전달
                    for result in results:
                        self.inference_complete.emit(result)
                    
            except Exception as e:
                logger.exception("InferenceWorker 추론 오류")
                self.error_occurred.emit(f"추론 오류: {str(e)}")
    
    def add_frame(self, frame_data: FrameData):
        """추론 큐에 프레임 추가"""
        self._queue_mutex.lock()
        # 카메라별 최신 프레임만 유지
        self._frame_queue[frame_data.camera_id] = frame_data
        self._queue_condition.wakeOne()
        self._queue_mutex.unlock()
    
    def set_confidence(self, threshold: float):
        """신뢰도 임계값 설정"""
        self.conf_threshold = threshold

    def set_iou(self, threshold: float):
        """IOU 임계값 설정"""
        self.iou_threshold = threshold

    def set_batch_size(self, size: int):
        """배치 크기 설정"""
        self.batch_size = size
        
    def set_target_classes(self, classes: Optional[list]):
        """탐지 대상 클래스 설정"""
        self.target_classes = classes
        
    def set_inference_fps_limit(self, fps: float):
        """추론 FPS 제한 설정"""
        self.inference_fps_limit = fps
    
    def stop(self):
        """정지"""
        self._running = False
        self._queue_condition.wakeAll()
        self.wait(5000)