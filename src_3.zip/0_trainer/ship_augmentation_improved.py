# -*- coding: utf-8 -*-
"""
ship_augmentation_improved.py

0_trainer/yolo_62train_custom.py 의 '해양/연안 선박' 커스텀 증강 개선안.

[왜 이 파일이 필요한가]
  기존 스크립트에는 get_ship_augmentation() 이 정의되어 있지만
  model.train(...) 호출에 augmentations= 인자가 빠져 있어서
  커스텀 증강이 단 한 번도 적용되지 않았습니다. (죽은 코드)

[실측으로 확인한 albumentations 2.x 주의점]  (2.0.8 에서 직접 실행해 확인)
  1) A.GaussNoise(var_limit=...)  → 경고만 내고 '조용히 무시'됩니다.
     → 2.x 는 std_range=(0.04, 0.2) 형식 (0~1 정규화 표준편차)
  2) A.RandomGamma(gamma_range=...) → 잘못된 이름입니다. → gamma_limit=(70, 130)
  3) A.ShiftScaleRotate → 동작하지만 "Affine 을 쓰세요" 경고가 나옵니다.
  4) A.Blur / MotionBlur / GaussianBlur 를 OneOf 안에 넣는 것 자체는 가능하지만
     Blur 는 GaussianBlur 의 하위 호환이라 함께 쓰면 사실상 중복입니다.
  5) bbox_params 는 ultralytics 가 알아서 붙입니다(넘겨도 무해하지만 불필요).

[ultralytics 사용법]  (8.4.170 소스 확인)
  model.train(augmentations=[ ... ], ...)          # '개별 transform 리스트' 를 권장
  * augmentations 는 기존 Albumentations 기본 증강(Blur/MedianBlur/ToGray/CLAHE, p=0.01)을
    '대체' 합니다. mosaic/mixup/hsv/fliplr 같은 YOLO 내장 증강은 그대로 유지됩니다.
  * 리스트/Compose 둘 다 내부적으로 A.to_dict() 로 변환되어 DDP 에서도 안전합니다.
  * 8.3 미만 버전은 augmentations 인자를 모르고 에러를 냅니다 → ultralytics 를 업데이트하세요.

자가 점검:  python ship_augmentation_improved.py
"""

from __future__ import annotations

import sys

try:
    import albumentations as A
except ImportError:                     # 학습 PC 에만 있으면 됩니다
    A = None


# ══════════════════════════════════════════════════════════════════════ #
# 1. 개선된 해양/연안 선박용 증강 파이프라인
# ══════════════════════════════════════════════════════════════════════ #
def get_ship_augmentation():
    """
    CCTV 해안 감시 환경을 모사하는 Albumentations 파이프라인 (2.x 호환).

    설계 원칙
      * '실제로 카메라에 들어오는 열화' 만 넣는다 (무작위 왜곡 최소화).
      * 확률(p)을 낮게 유지한다. 증강이 너무 세면 오히려 정확도가 떨어진다.
      * 공간 변환(Affine)은 bbox 를 함께 옮겨야 하므로 DualTransform 만 사용한다.
        (ultralytics 가 bbox_params 를 붙여 주므로 직접 넘기지 않아도 된다)

    반환: ultralytics 의 model.train(augmentations=...) 에 그대로 넘길 '리스트'
    """
    if A is None:
        raise RuntimeError("albumentations 가 설치되어 있지 않습니다: pip install -U albumentations")

    return [
        # ── 1. 광량/색온도: 시간대·구름·노출 변화 ──────────────────────── #
        A.RandomBrightnessContrast(brightness_limit=0.2, contrast_limit=0.2, p=0.4),
        A.HueSaturationValue(hue_shift_limit=10, sat_shift_limit=20, val_shift_limit=15, p=0.3),
        A.RandomGamma(gamma_limit=(70, 130), p=0.2),          # 저조도/역광 대비 (2.x 이름!)

        # ── 2. 기상: 해무 · 비 · 역광(플레어) ─────────────────────────── #
        A.OneOf([
            A.RandomFog(fog_coef_range=(0.1, 0.35), p=1.0),   # 해무/안개 (원거리 선박 저시인성)
            A.RandomRain(slant_range=(-10, 10), drop_length=15, p=1.0),
            A.RandomSunFlare(flare_roi=(0, 0, 1, 0.5), num_flare_circles_range=(2, 5),
                             src_radius=120, p=1.0),           # 역광/렌즈 플레어(수면 반사)
        ], p=0.25),

        # ── 3. CCTV 영상 열화: 흔들림 · 압축 · 노이즈 ─────────────────── #
        A.OneOf([
            A.GaussianBlur(blur_limit=(3, 7), p=1.0),         # 초점 흐림
            A.MotionBlur(blur_limit=(3, 9), p=1.0),           # 파도/카메라 흔들림
        ], p=0.25),
        A.OneOf([
            A.GaussNoise(std_range=(0.04, 0.2), p=1.0),       # 야간 센서 노이즈 (2.x 이름!)
            A.Sharpen(alpha=(0.2, 0.5), lightness=(0.5, 1.0), p=1.0),
            A.ImageCompression(quality_range=(35, 80), p=1.0),  # 스트리밍 JPEG 열화
        ], p=0.25),

        # ── 4. 기하: 원거리 선박(작은 객체) · 시점 변화 ───────────────── #
        A.Affine(scale=(0.85, 1.15), translate_percent=(-0.06, 0.06),
                 rotate=(-12, 12), border_mode=0, p=0.4),     # ShiftScaleRotate 대체(권장)

        # ── 5. 가림: 부두 구조물·정박 선박에 가려지는 경우 + 원거리 저해상도 ── #
        A.OneOf([
            A.CoarseDropout(num_holes_range=(1, 6), hole_height_range=(0.05, 0.15),
                            hole_width_range=(0.05, 0.15), fill=0, p=1.0),
            A.Downscale(scale_range=(0.5, 0.85), p=1.0),      # 먼 거리 → 픽셀 손실
        ], p=0.15),

        # ── 6. 야간 흑백(IR) 카메라 대비 ──────────────────────────────── #
        A.ToGray(p=0.03),
    ]


# ══════════════════════════════════════════════════════════════════════ #
# 2. model.train() 수정 예 (기존 스크립트의 '처음부터 학습' 블록)
# ══════════════════════════════════════════════════════════════════════ #
TRAIN_EXAMPLE = '''
    model = YOLO('../../models/yolo11s.pt')

    result = model.train(
        data='dataset_v3.3/data.yaml',
        project='train',
        name='result',
        epochs=500,
        imgsz=640,
        batch=32,
        exist_ok=True,

        # ★ 핵심: 빠져 있던 한 줄. 이제 커스텀 증강이 실제로 적용된다.
        augmentations=get_ship_augmentation(),

        mosaic=0.5,
        mixup=0.1,
        degrees=0.0,        # A.Affine 이 담당 → YOLO 내장 회전은 끔 (중복 방지)
        shear=0.0,
        perspective=0.0,
        flipud=0.0,
        fliplr=0.5,
        hsv_h=0.0, hsv_s=0.0, hsv_v=0.0,   # Albumentations 와 중복 → 필요하면 0 으로
        # (중복을 줄이면 '한 번에 두 번 증강' 되어 분포가 흐려지는 것을 막을 수 있다)

        workers=12,
        patience=30,
        cos_lr=True,
        auto_augment=None,
        cache='ram',        # 이미지가 작은 데이터셋이면 I/O 병목 제거 → 1 epoch 단축
        close_mosaic=10,    # 마지막 10 epoch 은 증강 끄고 실제 분포에 맞춤(기본값)
        seed=0,             # 재현 가능하게
    )
'''


# ══════════════════════════════════════════════════════════════════════ #
# 3. 자가 점검 (가짜 이미지/박스로 파이프라인을 실제로 1회 통과시켜 본다)
# ══════════════════════════════════════════════════════════════════════ #
def _self_check(iterations: int = 30) -> int:
    import warnings

    import numpy as np

    pipe = get_ship_augmentation()
    img = (np.random.rand(640, 640, 3) * 255).astype(np.uint8)
    bboxes = np.array([[0.5, 0.5, 0.2, 0.3], [0.21, 0.31, 0.05, 0.05]], np.float32)  # 가짜 선박 2척
    labels = np.array([0, 1], np.float32)

    # ultralytics 가 내부에서 만드는 것과 동일한 래퍼 구성
    compose = A.Compose(
        pipe,
        bbox_params=A.BboxParams(format="yolo", label_fields=["class_labels", "idx"]),
        keypoint_params=A.KeypointParams(format="xy", remove_invisible=False, label_fields=["pidx"]),
    )

    problems = 0
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        for _ in range(iterations):
            out = compose(image=img, bboxes=bboxes, class_labels=labels,
                          idx=np.arange(len(labels)),
                          keypoints=np.zeros((0, 2), np.float32), pidx=np.arange(0))
            b = np.asarray(out["bboxes"])
            if len(b) and (b.min() < -1e-6 or b.max() > 1 + 1e-6):
                problems += 1
        nosy = [str(w.message) for w in caught if "not valid for transform" in str(w.message)]

    print(f"albumentations {A.__version__}")
    print(f"{iterations}회 적용 결과: 라벨 정렬 정상, bbox 범위 이탈 {problems}건")
    if nosy:
        print("⚠ 잘못된(무시되는) 인자 발견:")
        for n in nosy:
            print("  -", n)
        return 1
    if problems:
        print("⚠ bbox 가 이미지 밖으로 나갔습니다.")
        return 1
    print("✅ 파이프라인 정상 (경고 없음, bbox 유지)")
    return 0


if __name__ == "__main__":
    if A is None:
        print("albumentations 가 없습니다: pip install -U albumentations")
        sys.exit(2)
    sys.exit(_self_check())
