import os.path

from ultralytics.cfg import entrypoint

if __name__ == '__main__':

    print("Launching YOLO Solutions Inference UI")

    model = os.path.join('runs','detect','train8', 'weights', 'last.pt')
    model = "runs\detect\train8\weights\last.pt"

    entrypoint(f"yolo solutions inference model='{model}')")