from multiprocessing import freeze_support

from PySide6.scripts.pyside_tool import project
from click.core import batch
from torchvision.utils import save_image
from ultralytics import YOLO


"""
1단계 학습 yolo_62train.py
 - YOLO 기본 증강으로 베이스 모델을 만들기 위한 학습
2단계 학습 yolo_62train_custom.py
 - Alumentation 픽셀 증강을 얹어셔 당직실, 단독망 환경에 최적화 파인 튜닝 
 - 인터넷 연결 요청 코드 주석 
    - C:\anaconda3\envs\py311_yolo11\Lib\site-packages\ultralytics\utils\downloads.py 에 def get_github_assets 주석 추가
 -  학습 파라미터:
    - 학습 규모: 300 Epochs, 이미지 크기 640, 배치 사이즈 32.
    - 기본 증강: randaugment, mosaic(0.5), mixup(0.1), degrees(5.0), shear(2.0) 등 YOLO 내장 증강 적용.
    - 과적합 방지: patience=30 (30회 성능 개선 없을 시 조기 종료).
"""
if __name__ == '__main__':

    freeze_support()

    model = YOLO('yolo11s.pt')

    # 20251127 swjang 이미지 데이터 로드시 시간이 많이 걸리는 문제가 있어 workers=0 추가
    # 멀티프로세싱을 하지 않고 메인 프로세스에서 데이터 로드 처리
    result = model.train(data='datasets_datacenter_260212\data.yaml',
                         project='my_train',
                         name='datacenter_260212',
                         epochs=300,
                         imgsz=640,
                         batch=32,
                         auto_augment='randaugment',
                         mosaic=0.5,
                         mixup=0.1,
                         degrees=5.0,
                         shear=2.0,
                         workers=0,
                         patience=30)