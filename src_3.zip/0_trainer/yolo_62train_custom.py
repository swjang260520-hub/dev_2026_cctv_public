import os
from multiprocessing import freeze_support
import albumentations as A
from ultralytics import YOLO
import warnings
# UserWarning 중 'Error fetching version info'가 포함된 경고를 무시함
warnings.filterwarnings("ignore", message="Error fetching version info")

# 해안가 선박 식별을 위한 Custom Albumentations 파이프라인 정의
def get_ship_augmentation():
    return A.Compose([
        # 1. 기상 및 광원 환경 모사
        A.RandomBrightnessContrast(brightness_limit=0.2, contrast_limit=0.2, p=0.5),
        A.HueSaturationValue(hue_shift_limit=20, sat_shift_limit=30, val_shift_limit=20, p=0.5),

        # 2. 해무 및 시인성 저하 모사
        A.OneOf([
            A.GaussianBlur(blur_limit=(3, 7), p=1.0),
            A.MotionBlur(blur_limit=(3, 7), p=1.0),
            A.Blur(blur_limit=(3, 7), p=1.0),
        ], p=0.3),

        # 3. CCTV 디지털 노이즈 및 선명도 개선
        A.OneOf([
            A.GaussNoise(var_limit=(10.0, 50.0), p=1.0),
            A.Sharpen(alpha=(0.2, 0.5), lightness=(0.5, 1.0), p=1.0),
        ], p=0.3),

        # 4. 기하학적 변형 (선박의 위치 및 각도 변화)
        A.ShiftScaleRotate(shift_limit=0.0625, scale_limit=0.1, rotate_limit=15, p=0.5),
    ], bbox_params=A.BboxParams(format='yolo', label_fields=['class_labels']))


if __name__ == '__main__':
    freeze_support()

    # [학습 전략]
    # 1. exist_ok=True: 폴더가 'result2', 'result3'로 늘어나는 것을 방지하고 'result' 폴더를 고정 사용함
    # 2. last.pt 존재 여부: 학습 중단 시 생성된 체크포인트를 확인하여 resume=True로 이어서 학습함
    # 3. 초기화 방법: 완전히 처음부터 다시 학습하려면 'train/result' 폴더를 수동으로 삭제 후 실행

    # 체크포인트 경로 설정
    last_checkpoint = 'runs/detect/train/result/weights/last.pt'

    if os.path.exists(last_checkpoint):
        print("중단된 체크포인트 발견: 이어서 학습을 시작합니다.")
        model = YOLO(last_checkpoint)
        result = model.train(resume=True)
    else:
        # 모델 로드 - 처음부터 학습
        print("체크포인트 없음: 새로운 학습을 시작합니다.")
        model = YOLO('../../models/yolo11s.pt')

        # [중요] YOLOv11의 기본 증강 설정과 Albumentations의 조화를 위해
        # 일부 내장 증강 강도를 조절합니다.
        result = model.train(
            data='dataset_v3.3/data.yaml',
            project='train',
            name='result',
            epochs=500,
            imgsz=640,
            batch=32,       # [메모리] RTX 4070 VRAM에 최적화된 배치 사이즈

            exist_ok=True,  # 폴더가 이미 있으면 새로 만들지 않고 사용

            # YOLO 내장 증강 설정 (Albumentations와 중복되지 않게 조정)
            mosaic=0.5,  # 배경 다양성 확보
            mixup=0.1,  # 객체 중첩 학습
            degrees=0.0,  # Albumentations의 ShiftScaleRotate에서 처리
            shear=0.0,  # Albumentations에서 처리
            perspective=0.0,
            flipud=0.0,  # 선박이 뒤집히는 경우는 거의 없음
            fliplr=0.5,  # 좌우 반전은 유효함

            # [Data Loading 설정]
            # workers=12: i9-14900K(24코어) 자원을 활용하여 데이터 로딩 속도 향상
            workers=12,
            # [Early Stopping 설정]
            # patience=30: 30 epoch 동안 성능 개선이 없으면 학습을 조기 종료하여 오버피팅을 방지함
            # - 500 epoch라는 긴 학습 기간에 적절한 안전장치이며 표준적인 설정임
            # - resume=True로 재시작 시 patience 카운터는 초기화되어 다시 30 epoch를 확인함
            # - 만약 너무 빨리 종료된다고 판단되면 50~100으로 상향 조정 가능
            patience=30,
            cos_lr=True,        # [학습률] 코사인 스케줄러 적용으로 더 정밀한 수렴 유도
            auto_augment=None,  # 커스텀 증강을 위해 None 설정
        )