
from ultralytics import YOLO

if __name__ == '__main__':


    # 1단계 결과에서 이어서 학습
    # model_path = input("model path:") # "my_train\datacenter_2602125\weights\best.pt"
    model_path = "jin/result2/weights/best.pt"
    model = YOLO(model_path)

    result = model.val(data='datasets_jin_20260423\data.yaml')
    print(result)