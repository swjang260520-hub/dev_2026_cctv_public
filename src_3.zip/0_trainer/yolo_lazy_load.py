import sys

from loguru import logger

from PySide6.QtCore import QObject, Signal, QThread, Slot
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QMainWindow, QPushButton, QApplication



class ModelLoader(QObject):

    finished = Signal(object)
    error = Signal(str)

    def __init__(self, model_path: str, parent=None):
        super().__init__(parent)
        self.model_path = model_path

    def load_model(self):
        try:
            logger.debug('model loading...')
            from ultralytics import YOLO
            model = YOLO(self.model_path)
            # _ = model.predict(source='bus.jpg', imgsz=640, verbose=False)

            self.finished.emit(model)

        except Exception as e:
            self.error.emit(str(e))


class LoadingWindow(QWidget):

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        self.label = QLabel("Loading...")
        layout.addWidget(self.label)
        self.setLayout(layout)


class MainWindow(QMainWindow):

    def __init__(self, model, parent=None):
        super().__init__()
        self.model = model

        central_widget = QWidget()
        layout = QVBoxLayout(central_widget)

        self.info_label = QLabel('모델 로딩 완료! 이제 추론 시작 할 수 있습니다.')
        self.btn_infer = QPushButton("샘플 이미지 추론")

        layout.addWidget(self.info_label)
        layout.addWidget(self.btn_infer)

        self.setCentralWidget(central_widget)

        self.btn_infer.clicked.connect(self.run_sample_inference)

    def run_sample_inference(self):
        results = self.model('bus.jpg', show=False)

        self.info_label.setText('샘플 이미지 추론 완료(콘솔/로그 확인)')


class AppController(QApplication) :
    """
    전체 흐름 제어
     - 로딩화면 표시, Qthread에서 모델 로딩. 완료되면 메인 윈도우로 전환
    """
    def __init__(self, model_path, argv):

        super().__init__(argv)

        self.loading_window = LoadingWindow()
        self.loading_window.show()

        self.thread = QThread()
        self.worker = ModelLoader(model_path)
        self.worker.moveToThread(self.thread)

        self.thread.started.connect(self.worker.load_model)
        self.worker.finished.connect(self.on_model_loaded)
        self.worker.error.connect(self.on_model_error)

        self.thread.start()

        self.main_window = None

    @Slot(object)
    def on_model_loaded(self, model):
        logger.debug('on_model_loaded')
        self.loading_window.close()

        self.main_window = MainWindow(model)
        self.main_window.show()


    def on_model_error(self, msg):
        self.loading_window.label.setText(f'모델 로딩 실패 {msg}')

    def run(self):
        sys.exit(self.app.exec())


if __name__ == '__main__':

    controller = AppController('yolo11n.pt', sys.argv)
    sys.exit(controller.exec())