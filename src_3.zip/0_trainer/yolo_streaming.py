import cv2
from ultralytics import YOLO

model = YOLO('yolo11n.pt')

video_path = '../airport.mp4'
cap = cv2.VideoCapture(video_path)

while cap.isOpened():
    ret, frame = cap.read()

    if ret:
        result = model(frame)
        annotated_frame = result[0].plot()

        cv2.imshow('YOLO inference', annotated_frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    else:
        break

cap.release()
cv2.destroyAllWindows()