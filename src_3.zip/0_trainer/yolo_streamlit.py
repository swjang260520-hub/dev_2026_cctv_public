import sys

import streamlit as st
from ultralytics import YOLO
from PIL import Image

st.title('YOLOv11n')

model = YOLO('yolo11n.pt')

uploaded_file = st.file_uploader("Upload a file", type=["png", "jpg", "jpeg"])

if uploaded_file is not None:
    image = Image.open(uploaded_file)
    if st.button("Predict"):
        result = model(image)
        res_plotted = result[0].plot()

        st.image(res_plotted, caption="YOLO Result", use_column_width=True)
