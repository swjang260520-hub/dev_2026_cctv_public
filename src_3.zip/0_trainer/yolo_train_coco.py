# yolo detect train data=coco.yaml model=yolo11n.pt epochs=300 imgsz=640 patience=50
# yolo train data=coco.yaml model='last.pt' epochs=300 imgsz=640 patience=50 resume=True
# yolo train model='last.pt' epochs=300 imgsz=640 patience=50 resume=True

from ultralytics import YOLO

if __name__ == '__main__':

    model = YOLO('yolo11n.pt')

    model.train(
        data='coco.yaml',
        epochs=300,         # 충분히 길게
        patience=50,       # 조기 종료 설정
        batch=-1,          # GPU 메모리 자동 최적화
        imgsz=640,
        #save_period=10,    # 10 에포크마드 저장
        workers=0,
        cache=True         # RAM이 넉넉하면 학습속도 향상(이미지 캐싱)
    )