# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_data_files
from PyInstaller.utils.hooks import collect_dynamic_libs
from PyInstaller.utils.hooks import copy_metadata

datas = [('styles', 'styles')]
binaries = []
datas += collect_data_files('qtawesome')
datas += collect_data_files('ultralytics')
datas += collect_data_files('onvif')
datas += copy_metadata('ultralytics')
datas += copy_metadata('torch')
datas += copy_metadata('torchvision')
binaries += collect_dynamic_libs('cv2')


a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=['numpy', 'PySide6.QtSvg', 'PySide6.QtSvgWidgets', 'LeaCrypto', 'LEA', 'cryptography.fernet', 'cryptography.hazmat.primitives.hashes', 'cryptography.hazmat.primitives.kdf.pbkdf2', 'ultralytics', 'torch', 'torchvision', 'onvif', 'zeep'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['pytest'],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='CCTV_System',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='CCTV_System',
)
