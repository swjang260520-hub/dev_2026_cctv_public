# coding = UTF-8
import LEA


class LeaUtil():

    def __init__(self, key, **kwargs):
        """
        LEA 암호화 알고리즘
        :param enc_mode:s
        :param key:
        :param iv:
        """
        self.key = key
        if len(self.key) != 24:
            raise AttributeError(f'Key length must 24 byte. key_len={len(key)}')

        self.enc_mode = 'ECB'
        self.iv = None
        for k, v in kwargs.items():
            if k == 'enc_mode':
                self.enc_mode = v
            if k == 'iv':
                self.iv = v

    def doEncrypt(self, plain_text):
        """
        plain_text 를 enc_text 로 변환(bytearray)
		LEA.ECB(do_enc, key, PKCS5Padding)
		do_enc(bool) : 암호화(True) 복호화(False) 여부
		key(bytearray) : 마스터 키. 키 길이는 16바이트, 24바이트 또는 32바이트
		PKCS5Padding : PKCS5 패딩을 사용하여 암.복호화를 할 것인지 설정
        :param enc_mode: ECB, CBC, CTR, CFB, OFB
        :param plain_text:
        :return:
        """
        key = self.key
        enc_mode = self.enc_mode
        print("doEnc enc_mode=", enc_mode)
        if enc_mode != 'ECB':
            if self.iv is None:
                raise AttributeError(f'IV is required in mode. enc={enc_mode}')
            else:
                iv = self.iv

        if enc_mode == 'ECB':
            leaEnc = LEA.ECB(True, key, True)
        elif enc_mode == 'CBC':
            leaEnc = LEA.CBC(True, key, iv, True)
        elif enc_mode == 'CTR':
            leaEnc = LEA.CTR(True, key, iv, True)
        elif enc_mode == 'CFB':
            leaEnc = LEA.CFB(True, key, iv)
        elif enc_mode == 'OFB':
            leaEnc = LEA.OFB(True, key, iv)
        else:
            leaEnc = None
            raise AttributeError('Unknown Mode')

        ct = leaEnc.update(bytearray(plain_text, "utf8"))
        ct += leaEnc.final()
        return ct

    def doDecrypt(self, enc_text):
        """
        plain_text 를 enc_text 로 변환(bytearray)
        :param enc_mode: ECB, CBC, CTR, CFB, OFB
        :param plain_text:
        :return:
        """
        key = self.key
        enc_mode = self.enc_mode

        if enc_mode != 'ECB':
            if self.iv is None:
                raise AttributeError('IV is required in mode.' % env.mode)
            else:
                iv = self.iv

        if enc_mode == 'ECB':
            leaEnc = LEA.ECB(False, key, True)
        elif enc_mode == 'CBC':
            leaEnc = LEA.CBC(False, key, iv, True)
        elif enc_mode == 'CTR':
            leaEnc = LEA.CTR(False, key, iv, True)
        elif enc_mode == 'CFB':
            leaEnc = LEA.CFB(False, key, iv)
        elif enc_mode == 'OFB':
            leaEnc = LEA.OFB(False, key, iv)
        else:
            leaEnc = None
            raise AttributeError('Unknown Mode')

        pt = leaEnc.update(enc_text)
        pt += leaEnc.final()
        return pt.decode('utf8')

if __name__ == '__main__':
    key = bytearray(b"blacksnakeblacksnake1234")
    iv = bytearray(b"1234567812345678")

    lea = LeaUtil(key)
    enc = lea.doEncrypt("장성욱입니다.")

    print("ECB mode")
    print("enc=", enc)
    print("dec=", lea.doDecrypt(enc))


    lea2 = LeaUtil(key, enc_mode='CFB', iv=iv)
    enc = lea2.doEncrypt("장성욱입니다.")
    print("enc=", enc)
    print("dec=", lea2.doDecrypt(enc))
