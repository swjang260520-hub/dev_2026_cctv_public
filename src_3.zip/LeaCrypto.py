# -*- coding: utf-8 -*-
import os.path

import LEA
import base64
import binascii
import hashlib
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from loguru import logger
# 암복호화 라이브러리 추가

class LeaUtil:

    def __init__(self):

        self.key = self.load_encryption_key()

    def encrypt(self, plain_text):
        key = self.key
        if key is None:
            raise RuntimeError(
                "암호키를 읽지 못했습니다. cctv_key.bin 파일을 확인하세요."
            )
        leaECB = LEA.ECB(True, key, True)
        ct = leaECB.update(bytearray(plain_text, "utf8"))
        ct += leaECB.final()
        return binascii.hexlify(ct).decode('utf-8')

    def decrypt(self, ciper_text):
        key = self.key
        if key is None:
            raise RuntimeError(
                "암호키를 읽지 못했습니다. cctv_key.bin 파일을 확인하세요."
            )
        leaECB = LEA.ECB(False, key, True)
        ct = binascii.unhexlify(ciper_text)
        pt = leaECB.update(ct)
        pt += leaECB.final()
        return pt.decode('utf-8')

    def load_key(self):
        secret_path = "cctv_key.bin"
        if os.path.isfile(secret_path):
            with open(secret_path, 'r') as f:
                secret_key = f.read()
        else:
            logger.error(f'Not Found secret file - secret_path ={secret_path}')

        join_key = f"{secret_key}{self.app_key_from_mapdb()}"

        return hashlib.sha256(join_key.encode('utf-8')).digest()

    def derive_key_from_password(self, master_password, salt=None):
        if salt is None:
            salt = os.urandom(16)

        kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=10000)
        key = base64.urlsafe_b64encode(kdf.derive(master_password))

        return key, salt

    # ------------------------------------------------------------------ #
    # 암호키 파일(cctv_key.bin) 해석
    # ------------------------------------------------------------------ #
    #: 키 파일 꼬리 구조 (실제 배포된 파일 / WidgetCreateKey 가 쓰는 형식)
    #:    [ Fernet 암호문(base64) ] \n [ salt 16 bytes ] \n [ master 32 bytes ]
    SALT_SIZE = 16
    MASTER_SIZE = 32

    @classmethod
    def _key_file_candidates(cls, data: bytes):
        """
        cctv_key.bin 바이트에서 가능한 (encrypted_key, salt, master_password)
        조합을 '그럴듯한 순서' 로 돌려준다.

        [수정] 기존 구현은 readline() 으로 3줄을 읽었다.
        salt/master_password 는 os.urandom() 바이너리라 0x0A('\n') 가 섞일 수 있고
        (48 bytes 기준 약 17% 확률), 그 순간 줄이 밀려 키 복원이 깨진다.

        그래서 (1) 뒤에서부터 salt/master 길이를 고정으로 잘라내는 방식 →
        (2) 줄 단위 분해 → (3) 환경변수 보충 순으로 후보를 만들고,
        load_encryption_key() 가 '실제로 복호화에 성공하는' 후보를 채택한다.
        (암호문·salt·master 가 모두 맞아야 Fernet 복호화가 성공하므로
         이 방식이 사실상의 무결성 검증이 된다)
        """
        candidates = []
        seen = set()

        def push(candidate):
            if candidate and all(candidate) and candidate not in seen:
                seen.add(candidate)
                candidates.append(candidate)

        # 뒤에 붙은 개행 1개는 있어도/없어도 모두 시도한다
        variants = [data]
        if data.endswith(b"\n"):
            variants.append(data[:-1])

        # --- 1) 꼬리 고정 길이 레이아웃 --------------------------------- #
        for d in variants:
            need = cls.SALT_SIZE + cls.MASTER_SIZE + 2      # salt + master + 구분자 2개
            if len(d) < need:
                continue
            if d[-(cls.MASTER_SIZE + 1):-cls.MASTER_SIZE] != b"\n":
                continue
            master = d[-cls.MASTER_SIZE:]
            salt_end = -(cls.MASTER_SIZE + 1)
            salt = d[salt_end - cls.SALT_SIZE:salt_end]
            sep = salt_end - cls.SALT_SIZE
            if d[sep - 1:sep] == b"\n":
                push((d[:sep - 1], salt, master))

        # --- 2) 줄 단위 분해 -------------------------------------------- #
        for d in variants:
            parts = [p.strip() for p in d.split(b"\n") if p.strip()]
            if len(parts) >= 3:
                push((parts[0], parts[1], parts[2]))
            elif len(parts) == 2:
                # master_password 줄이 없는 파일 (현행 keysave_slot 이 만들던 형식)
                env_pw = os.environ.get("CCTV_MASTER_PWD", "")
                if env_pw:
                    try:
                        push((parts[0], parts[1], base64.b64decode(env_pw)))
                    except Exception:
                        pass

        return candidates

    @classmethod
    def _parse_key_file(cls, data: bytes):
        """가장 그럴듯한 (encrypted_key, salt, master_password) 하나를 돌려준다."""
        candidates = cls._key_file_candidates(data)
        return candidates[0] if candidates else None

    def load_encryption_key(self, key_path='cctv_key.bin'):
        """암호키 파일을 읽어 Fernet 키를 복원한다 (실패 시 None)."""
        try:
            with open(key_path, 'rb') as file:
                data = file.read()
        except FileNotFoundError:
            logger.error(f"암호키 파일을 찾을 수 없습니다: {key_path}")
            return None
        except Exception as e:
            logger.error(f"암호키 파일 읽기 실패({key_path}): {e}")
            return None

        candidates = self._key_file_candidates(data)
        if not candidates:
            logger.error(
                f"암호키 파일 형식을 해석할 수 없습니다: {key_path} ({len(data)} bytes)"
            )
            return None

        last_error = None
        for encrpyted_key, salt, master_password in candidates:
            try:
                master_key, _ = self.derive_key_from_password(master_password, salt)

                f = Fernet(master_key)
                # 복호화 성공 = 3개 값이 모두 맞았다는 뜻 (무결성 검증 역할)
                return f.decrypt(encrpyted_key)
            except Exception as e:
                last_error = e

        logger.error(
            f"load encrytion key error : {last_error} "
            f"({key_path}, {len(data)} bytes, 후보 {len(candidates)}개 시도)"
        )
        return None


if __name__ == '__main__':
    # [보안] 키 원문과 하드코딩된 테스트 문자열을 제거. 무작위 문자열로 왕복만 검증한다.
    import secrets
    lea = LeaUtil()
    sample = secrets.token_urlsafe(16)
    en = lea.encrypt(sample)
    de = lea.decrypt(en)
    logger.info(f"LEA 암복호화 자체 테스트: {'성공' if de == sample else '실패'}")
