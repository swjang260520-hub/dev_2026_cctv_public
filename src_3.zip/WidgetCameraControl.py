"""
WidgetCameraControl.py
서비스 안정성을 위한 중앙 집중형 관제 & ONVIF PTZ 카메라 통합 제어 위젯
- 영상 수신/AI 추론은 메인 시스템(MainWindow) 파이프라인의 FrameData를 공유받아 화면만 렌더링 (RTSP/VRAM 중복 낭비 0%)
- 하단 제어 패널에서 ONVIF PTZ 모터 제어(Pan/Tilt/Zoom/Speed/Stop) 전용 수행
"""

import sys
import os
from typing import Optional
from loguru import logger

from PySide6.QtWidgets import QApplication, QWidget, QMessageBox
from PySide6.QtCore import Qt, Signal, Slot, QSize
from PySide6.QtGui import QColor
import qtawesome as qta

# 컴파일된 UI 모듈 임포트
from ui.camera_control_ui import Ui_CameraControl
from core.models import CameraConfig, CameraStatus, FrameData
from ui.camera_widget import CameraWidget
from core.cgi_ptz import PelcoDPTZController, PelcoDCgiWorker

# ONVIF 라이브러리 임포트 시도
try:
    from onvif import ONVIFCamera
    HAS_ONVIF = True
except ImportError:
    HAS_ONVIF = False
    logger.warning("onvif-zeep 패키지가 설치되지 않았습니다. PTZ 제어 기능이 더미 시뮬레이션 모드로 작동합니다.")


class WidgetCameraControl(QWidget, Ui_CameraControl):
    """
    서비스 안정형 RTSP 관제 뷰어 & ONVIF / Pelco-D PTZ 카메라 제어 위젯
    - 메인 관제 파이프라인(MainWindow)으로부터 FrameData 및 상태를 공유받음
    - 독립적인 ONVIF 및 Pelco-D HTTP CGI PTZ 제어(Pan/Tilt/Zoom/Speed) 제공
    """
    
    ptz_command_requested = Signal(str)            # (command_name)
    detection_toggled = Signal(str, bool)          # (camera_id, enabled)
    connection_requested = Signal(str, str)        # (camera_id, rtsp_url)
    disconnection_requested = Signal(str)          # (camera_id)
    
    def __init__(self, config: Optional[CameraConfig] = None, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.resize(1280, 720)

        # 카메라 설정 초기화
        self.config = config 
        self.camera_id = self.config.camera_id

        # 1. 중앙 frame_video 영역에 CameraWidget 삽입
        self._init_camera_widget()
        
        # 2. PTZ 제어용 변수 및 QThread 워커
        self.onvif_cam = None
        self.ptz_service = None
        self.ptz_profile_token = None
        self.ptz_controller = PelcoDPTZController()
        self.ptz_cgi_worker: Optional[PelcoDCgiWorker] = None

        # 3. UI 초기화 및 시그널 연결
        if self.config:
            self.chk_enable_detection.setChecked(self.config.detection_enabled)

        self._setup_icons()
        self._init_signals()

    def _init_camera_widget(self):
        """중앙 비디오 영역에 CameraWidget 연동"""
        self.camera_view = CameraWidget(self.config, parent=self)
        self.lbl_video_display.setVisible(False)
        self.layout_video.addWidget(self.camera_view)

    def _setup_icons(self):
        """QtAwesome 아이콘 및 크기 배치"""
        self.btn_pan_up.setIcon(qta.icon("fa5s.arrow-up", color="#ffffff"))
        self.btn_pan_down.setIcon(qta.icon("fa5s.arrow-down", color="#ffffff"))
        self.btn_pan_left.setIcon(qta.icon("fa5s.arrow-left", color="#ffffff"))
        self.btn_pan_right.setIcon(qta.icon("fa5s.arrow-right", color="#ffffff"))
        
        self.btn_ptz_stop.setIcon(qta.icon("fa5s.hand-paper", color="#ef4444"))
        
        self.btn_zoom_in.setIcon(qta.icon("fa5s.search-plus", color="#38bdf8"))
        self.btn_zoom_out.setIcon(qta.icon("fa5s.search-minus", color="#38bdf8"))

        icon_size = QSize(16, 16)
        for btn in (self.btn_pan_up, self.btn_pan_down, self.btn_pan_left, self.btn_pan_right, 
                    self.btn_ptz_stop, self.btn_zoom_in, self.btn_zoom_out):
            btn.setIconSize(icon_size)

    def _init_signals(self):
        """이벤트 연결"""
        self.chk_enable_detection.toggled.connect(self._on_detection_toggled)
        
        # PTZ 버튼 이벤트
        self.btn_pan_up.pressed.connect(lambda: self._send_ptz_command("UP"))
        self.btn_pan_up.released.connect(lambda: self._send_ptz_command("STOP"))
        
        self.btn_pan_down.pressed.connect(lambda: self._send_ptz_command("DOWN"))
        self.btn_pan_down.released.connect(lambda: self._send_ptz_command("STOP"))
        
        self.btn_pan_left.pressed.connect(lambda: self._send_ptz_command("LEFT"))
        self.btn_pan_left.released.connect(lambda: self._send_ptz_command("STOP"))
        
        self.btn_pan_right.pressed.connect(lambda: self._send_ptz_command("RIGHT"))
        self.btn_pan_right.released.connect(lambda: self._send_ptz_command("STOP"))
        
        self.btn_ptz_stop.clicked.connect(lambda: self._send_ptz_command("STOP"))
        
        self.btn_zoom_in.pressed.connect(lambda: self._send_ptz_command("ZOOM_IN"))
        self.btn_zoom_in.released.connect(lambda: self._send_ptz_command("ZOOM_STOP"))
        
        self.btn_zoom_out.pressed.connect(lambda: self._send_ptz_command("ZOOM_OUT"))
        self.btn_zoom_out.released.connect(lambda: self._send_ptz_command("ZOOM_STOP"))

    # =========================================================================
    # 1. 외부/중앙 파이프라인 연동 인터페이스 (서비스 데이터 공유)
    # =========================================================================
    @Slot(object)
    def update_frame(self, frame_data: FrameData):
        """중앙 캡처/추론 파이프라인으로부터 FrameData를 수신하여 화면 업데이트"""
        if frame_data and frame_data.camera_id == self.camera_id:
            self.camera_view.update_frame(frame_data)

    @Slot(str, object)
    def update_status(self, camera_id: str, status: CameraStatus):
        """카메라 상태 업데이트"""
        if camera_id == self.camera_id:
            self.camera_view.update_status(camera_id, status)

    @Slot(str, int, int)
    def update_resolution(self, camera_id: str, width: int, height: int):
        """해상도 정보 업데이트"""
        if camera_id == self.camera_id:
            self.camera_view.update_resolution(camera_id, width, height)

    def _on_detection_toggled(self, checked: bool):
        """객체 탐지 체크박스 토글시 중앙 파이프라인으로 알림"""
        if self.config:
            self.config.detection_enabled = checked
        self.camera_view.set_detection_visible(checked)
        self.detection_toggled.emit(self.camera_id, checked)

    # =========================================================================
    # 2. ONVIF & Pelco-D PTZ 카메라 실시간 제어
    # =========================================================================
    def _send_ptz_command(self, command: str):
        """PTZ 제어 명령 발송 (ONVIF 연결 우선 사용, 실패/미연결 시 Pelco-D HTTP CGI QThread 전송)"""
        pts_speed = self.sb_pt_speed.value() if hasattr(self, 'sb_pt_speed') else 83
        zoom_speed = self.sb_zoom_speed.value() if hasattr(self, 'sb_zoom_speed') else 10
        
        self.lbl_ptz_status.setText(f"PTZ 상태: {command}")
        self.ptz_command_requested.emit(command)
        
        # 2. ONVIF 미연결 또는 실패 시 Pelco-D HTTP CGI (key.cgi) QThread 워커 구동
        source = self.config.source if self.config else ""
        user = self.config.username if self.config else ""
        pwd = self.config.password if self.config else ""

        # 컨트롤러의 멤버 변수 target_ip 및 세션 갱신 (IP 추출 재연산 방지 최적화)
        self.ptz_controller.set_target(source, user, pwd)

        self.ptz_cgi_worker = PelcoDCgiWorker(
            controller_or_target=self.ptz_controller,
            command=command,
            pts_speed=pts_speed,
            zoom_speed=zoom_speed,
            parent=self
        )
        self.ptz_cgi_worker.result_signal.connect(self._on_cgi_ptz_result)
        self.ptz_cgi_worker.finished.connect(self.ptz_cgi_worker.deleteLater)
        self.ptz_cgi_worker.start()

    @Slot(str, bool, str)
    def _on_cgi_ptz_result(self, command: str, success: bool, msg: str):
        """Pelco-D HTTP CGI 워커(QThread) 수신 결과 처리 슬롯"""
        if success:
            self.lbl_ptz_status.setText(f"PTZ 상태: {command}")
        else:
            self.lbl_ptz_status.setText(f"PTZ 오류: {msg}")
