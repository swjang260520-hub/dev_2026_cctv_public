"""
WidgetCameraDialog.py

카메라 추가/수정 다이얼로그.

[수정 이력 — 2026-10-01]
- 그룹명 입력용 콤보박스 추가 (편집 가능 = 신규 그룹 직접 입력 가능).
  '.ui' 파일은 수정하지 않고 formLayout 에 코드로 행을 추가한다.
  (기존 autostart_check 가 optionsLayout 에 코드로 추가되는 패턴과 동일)
- set_available_groups() 로 기존 그룹 목록을 받아 드롭다운을 채운다.
- 비밀번호 복호화 실패 시 입력칸을 비우지 않고 원문(평문)을 그대로 보여준다.
  (기존에는 예외를 삼키고 빈 칸으로 두어, 확인을 누르면 비밀번호가 지워졌다)
- 암호화 실패 시에도 평문으로 저장하도록 보정.
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLineEdit, QComboBox, QCheckBox, QPushButton,
    QGroupBox, QDialogButtonBox, QMessageBox, QFileDialog
)
from PySide6.QtCore import Qt, QThread, Signal
import cv2
from loguru import logger

from LeaCrypto import LeaUtil
from core.models import CameraConfig
from ui.camera_dialog_ui import Ui_CameraDialog


class ConnectionTestWorker(QThread):
    """연결 테스트를 위한 백그라운드 워커"""
    result_signal = Signal(bool, str)  # success, message

    def __init__(self, source):
        super().__init__()
        self.source = source

    def run(self):
        try:
            cap = cv2.VideoCapture(self.source)
            success = cap.isOpened() and cap.read()[0]
            cap.release()
            msg = "카메라 연결 성공!" if success else "연결 실패 (주소 또는 네트워크 확인 필요)"
            self.result_signal.emit(success, msg)
        except Exception as e:
            logger.exception("ConnectionTestWorker 오류")
            self.result_signal.emit(False, f"테스트 오류: {str(e)}")


class CameraDialog(QDialog, Ui_CameraDialog):
    """카메라 추가/수정 다이얼로그"""

    def __init__(self, config: CameraConfig = None, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.config = config if config else CameraConfig()
        self._is_edit_mode = config is not None

        self.setupUi(self)

        # 20260528 swjang 다이얼로그창에 확인, 취소를 한글로 표시하고, 삭제 버튼 추가
        self.buttonBox.button(QDialogButtonBox.Ok).setText('확인')
        self.buttonBox.button(QDialogButtonBox.Cancel).setText('취소')

        # 20260528 swjang 삭제 버튼 클릭시 행 삭제하고 창 닫기
        self.delete_btn = self.buttonBox.addButton('삭제', QDialogButtonBox.ActionRole)
        self.delete_btn.clicked.connect(self._on_delete_clicked)

        self.delete_btn.setEnabled(self._is_edit_mode)

        # 20260520 swjang 카메라 추가시 pwd를 암/복호화 기능 추가, camears_info.json에 암호화해서 저장
        self.lea = LeaUtil()

        self.autostart_check = QCheckBox("프로그램 시작 시 자동 실행")
        self.optionsLayout.addWidget(self.autostart_check)

        # ------------------------------------------------------------------ #
        # [신규] 그룹명 입력 콤보
        # - setEditable(True) 로 신규 그룹명을 직접 타이핑할 수 있게 한다.
        #   → 별도의 "그룹 관리" 화면이 필요 없다.
        # - NoInsert: 목록을 오염시키지 않고, 실제 저장은 accept() 에서 처리.
        # ------------------------------------------------------------------ #
        self.group_combo = QComboBox()
        self.group_combo.setEditable(True)
        self.group_combo.setInsertPolicy(QComboBox.NoInsert)
        self.group_combo.setMinimumWidth(180)
        self.group_combo.setToolTip(
            "그룹명을 선택하거나 새로 입력하세요.\n"
            "비워 두면 '미분류'로 표시됩니다."
        )
        if hasattr(self, "formLayout"):
            self.formLayout.addRow("그룹명", self.group_combo)
        else:
            # formLayout 이 없는 변형 .ui 를 쓰는 경우의 안전 장치
            self.optionsLayout.addWidget(self.group_combo)
            logger.warning("formLayout 을 찾지 못해 그룹 콤보를 optionsLayout 에 배치했습니다.")

        self.test_worker = None

        self._load_config()
        self._signal_and_slot()


    # ------------------------------------------------------------------ #
    # [신규] 외부(MainWindow)에서 기존 그룹 목록을 주입
    # ------------------------------------------------------------------ #
    def set_available_groups(self, groups):
        """
        드롭다운에 표시할 기존 그룹 목록을 설정한다.

        현재 편집 중인 카메라의 그룹명은 목록에 없어도
        setCurrentText() 로 유지되므로 문제되지 않는다.
        """
        current = self.group_combo.currentText()
        self.group_combo.clear()
        self.group_combo.addItem("")  # 미분류 선택용 빈 항목
        for group in sorted(set(groups or [])):
            if group:
                self.group_combo.addItem(group)
        self.group_combo.setCurrentText(current)

    def _signal_and_slot(self):
        self.type_combo.currentIndexChanged.connect(self._on_type_changed)
        self.browse_btn.clicked.connect(self._on_browse)
        self.test_btn.clicked.connect(self._on_test_connection)

    def _load_config(self):
        """설정 로드"""
        self.name_edit.setText(self.config.name)

        type_map = {"rtsp": 0, "http": 1, "usb": 2, "file": 3}
        self.type_combo.setCurrentIndex(type_map.get(self.config.source_type, 0))

        self.address_edit.setText(self.config.source)
        self.username_edit.setText(self.config.username)

        encrypt_pwd = self.config.password
        if encrypt_pwd:
            try:
                # 20260520 swjang 복호화
                decrypt_pwd = self.lea.decrypt(self.config.password)
                self.password_edit.setText(decrypt_pwd)
            except Exception as e:
                # [수정] 복호화 실패 = 평문이거나 키 파일 문제.
                # 입력칸을 비우면 '확인' 시 비밀번호가 지워지므로 원문을 그대로 표시한다.
                logger.warning(f'비밀번호 복호화 실패 → 원문을 표시합니다: {e}')
                self.password_edit.setText(encrypt_pwd)
        else:
            self.password_edit.setText("")

        # [신규] 그룹명 반영
        self.group_combo.setCurrentText(self.config.group_name or "")

        self.display_check.setChecked(self.config.display_enabled)
        self.detection_check.setChecked(self.config.detection_enabled)
        self.autostart_check.setChecked(self.config.autostart)

        self.browse_btn.setVisible(self.type_combo.currentIndex() == 3)  # 파일인 경우만

    def _on_type_changed(self, index: int):
        """연결 유형 변경"""
        self.browse_btn.setVisible(index == 3)  # 파일인 경우만

        placeholders = [
            "rtsp://192.168.1.100:554/stream",
            "http://192.168.1.100:8080/video",
            "0 (카메라 인덱스)",
            "비디오 파일 경로"
        ]
        self.address_edit.setPlaceholderText(placeholders[index])

    def _on_browse(self):
        """파일 찾아보기"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "비디오 파일 선택", "",
            "비디오 파일 (*.mp4 *.avi *.mkv *.mov);;모든 파일 (*.*)"
        )
        if file_path:
            self.address_edit.setText(file_path)

    def _on_test_connection(self):
        """연결 테스트"""
        source = self.address_edit.text().strip()
        if not source:
            QMessageBox.warning(self, "경고", "주소를 입력하세요.")
            return

        self.test_btn.setText("🔄 테스트 중...")
        self.test_btn.setEnabled(False)

        try:
            # USB 카메라인 경우
            if self.type_combo.currentIndex() == 2:
                source = int(source) if source.isdigit() else 0
            
            # RTSP인 경우 인증 정보 결합 (임시 Config 객체 활용)
            elif self.type_combo.currentIndex() == 0: # RTSP
                temp_config = CameraConfig(
                    source=source,
                    source_type="rtsp",
                    username=self.username_edit.text().strip(),
                    password=self.password_edit.text()
                )
                source = temp_config.get_opencv_source()

            # 워커 시작
            self.test_worker = ConnectionTestWorker(source)
            self.test_worker.result_signal.connect(self._on_test_finished)
            self.test_worker.finished.connect(self.test_worker.deleteLater)
            self.test_worker.start()
            
        except Exception as e:
            QMessageBox.critical(self, "오류", f"연결 오류: {str(e)}")
            self.test_btn.setText("🔗 연결 테스트")
            self.test_btn.setEnabled(True)

    def _on_test_finished(self, success, message):
        """테스트 완료 핸들러"""
        self.test_btn.setText("🔗 연결 테스트")
        self.test_btn.setEnabled(True)
        
        if success:
            QMessageBox.information(self, "성공", message)
        else:
            QMessageBox.warning(self, "실패", message)

    def accept(self):
        """확인 버튼"""
        name = self.name_edit.text().strip()
        source = self.address_edit.text().strip()

        if not name:
            QMessageBox.warning(self, "경고", "카메라명을 입력하세요.")
            return

        if not source:
            QMessageBox.warning(self, "경고", "주소를 입력하세요.")
            return

        plain_pwd = self.password_edit.text().strip()

        if plain_pwd:
            try:
                # 20260520 swjang 암호화
                self.config.password = self.lea.encrypt(plain_pwd)
            except Exception as e:
                # [수정] 키 파일이 없거나 손상된 경우에도 값을 잃지 않는다
                logger.error(f'비밀번호 암호화 실패 → 평문으로 저장합니다: {e}')
                self.config.password = plain_pwd
        else:
            self.config.password = ""

        # 설정 업데이트
        type_map = {0: "rtsp", 1: "http", 2: "usb", 3: "file"}

        self.config.name = name
        self.config.source = source
        self.config.source_type = type_map[self.type_combo.currentIndex()]
        self.config.username = self.username_edit.text().strip()
        # [신규] 그룹명 저장 (앞뒤 공백 제거, 빈 값 = 미분류)
        self.config.group_name = self.group_combo.currentText().strip()
        self.config.display_enabled = self.display_check.isChecked()
        self.config.detection_enabled = self.detection_check.isChecked()
        self.config.autostart = self.autostart_check.isChecked()

        super().accept()

    def get_config(self) -> CameraConfig:
        """설정 반환"""
        return self.config

    def _on_delete_clicked(self):
        logger.debug('on_delete_clicked')
        self.parent._on_delete_camera()
        self.close()
