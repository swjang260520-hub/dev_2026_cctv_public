from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QGroupBox,
                               QFormLayout, QLabel, QPushButton, QFrame)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont


class EventlogDialog(QDialog):
    # 마지막 창 위치 (모든 인스턴스가 공유). 미선언 시 첫 생성에서 AttributeError 발생
    last_geometry = None

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("이벤트 로그 상세보기")
        self.setFixedSize(450, 400)  # 메시지 영역 확장을 위해 높이 상향 조정
        self._setup_ui()

        # [핵심] 저장된 위치가 있다면 그 위치로 이동, 없다면 중앙 배치
        if EventlogDialog.last_geometry:
            self.setGeometry(EventlogDialog.last_geometry)

    def _setup_ui(self):
        # 메인 레이아웃
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(15)

        # --- 상세 정보 그룹박스 ---
        self.detail_group = QGroupBox("이벤트 상세 정보")
        # 그룹박스 내부 여백 설정
        self.detail_group.setContentsMargins(15, 20, 15, 15)

        # FormLayout 생성 및 세로 간격(Vertical Spacing) 설정
        detail_layout = QFormLayout(self.detail_group)
        detail_layout.setVerticalSpacing(15)  # 행 사이의 간격을 넓혀 가시성 확보
        detail_layout.setContentsMargins(10, 10, 10, 10)

        # 1. 발생 일시 라벨
        self.lbl_detail_time = QLabel("-")
        # self.lbl_detail_time.setStyleSheet("font-size: 15px; font-weight: bold; color: #333;")

        # 2. 카메라 명 라벨
        self.lbl_detail_cam = QLabel("-")
        # self.lbl_detail_cam.setStyleSheet("font-size: 15px; font-weight: bold; color: #333;")

        # 3. 상세 내용 라벨 (높이 설정 및 스타일 강화)
        self.lbl_detail_msg = QLabel("-")
        self.lbl_detail_msg.setWordWrap(True)
        self.lbl_detail_msg.setAlignment(Qt.AlignTop | Qt.AlignLeft)

        # 메시지 라벨을 강조하기 위한 스타일 (배경색, 테두리, 패딩)
        self.lbl_detail_msg.setStyleSheet("""
            QLabel {
                background-color: #f0f0f0; 
                border: 1px solid #ccc; 
                border-radius: 5px; 
                padding: 10px; 
                font-size: 14px; 
                color: #333;
            }
        """)
        # 메시지 영역의 최소 높이를 설정하여 충분한 공간 확보
        self.lbl_detail_msg.setMinimumHeight(120)

        # 폼 레이아웃에 추가
        detail_layout.addRow("발생 일시 :", self.lbl_detail_time)
        detail_layout.addRow("카메라 명 :", self.lbl_detail_cam)
        detail_layout.addRow("상세 내용 :", self.lbl_detail_msg)

        main_layout.addWidget(self.detail_group)

        # --- 하단 버튼 영역 ---
        button_layout = QHBoxLayout()
        button_layout.setContentsMargins(0, 10, 0, 0)
        button_layout.setAlignment(Qt.AlignRight)

        self.btn_close = QPushButton("닫기")
        self.btn_close.setFixedSize(80, 35)
        self.btn_close.setCursor(Qt.PointingHandCursor)
        # 버튼 스타일 (옵션)
        self.btn_close.setStyleSheet("""
            QPushButton {
                background-color: #6e7681; 
                color: white; 
                font-weight: bold; 
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #555;
            }
        """)
        self.btn_close.clicked.connect(self.close)

        button_layout.addWidget(self.btn_close)
        main_layout.addLayout(button_layout)

    def update_data(self, data):
        """데이터 갱신 메서드"""
        if data:
            self.lbl_detail_time.setText(data[0])
            self.lbl_detail_cam.setText(data[1])
            self.lbl_detail_msg.setText(data[2])

    def moveEvent(self, event):
        """[핵심] 사용자가 창을 이동할 때마다 실시간으로 위치 저장"""
        EventlogDialog.last_geometry = self.geometry()
        super().moveEvent(event)