import os
import sys

import cv2
import numpy as np
from PySide6.QtCore import Signal, QThread, Qt
from PySide6.QtGui import QImage, QPixmap, QPainter, QBrush, QPen, QColor
from PySide6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QPushButton, QListWidget, QLabel, \
    QGroupBox, QGridLayout, QFileDialog, QApplication, QMessageBox, QCheckBox

from ultralytics import YOLO

from loguru import logger

class InferenceEngine:
    def __init__(self, model_path, device='0'):
        # pt 파일 로드
        self.model = YOLO(model_path)
        self.device = device
        self.class_names = self.model.names

    def load_image_kor(self, path):
        """ 한글 경로 및 공백이 포함된 이미지를 안전하게 읽기 """
        try:
            img_array = np.fromfile(path, dtype=np.uint8)
            img = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
            return img
        except Exception as e:
            logger.error(f"Error loading image {path} : {e}")
            return None

    def predict_batch(self, image_list, conf=0.25, batch_size=16):
        results = self.model.predict(source=image_list,
                                     conf=conf,
                                     device=self.device,
                                     batch=batch_size,
                                     save=False,
                                     verbose=False
                                     )
        return results


class StateManager:
    def __init__(self, class_names, fp_threshold=0.45):
        self.class_names = class_names
        self.fp_threshold = fp_threshold
        self.reset()

    def reset(self):
        self.total_image = 0
        self.total_objects = 0
        self.suspicious_objects = 0
        self.class_counts = {name : 0 for name in self.class_names.values()}
        self.inference_times = []
        self.fp_cases = []   # 오탐

    def update(self, results):
        new_fp_cases = []

        for res in results:
            self.total_image += 1
            self.inference_times.append(res.speed['inference'])

            has_suspicion = False
            suspected_boxes = []

            for box in res.boxes:
                self.total_objects += 1  # 박스를 찾을때 마다 객체 수 증가

                cls_id = int(box.cls[0])
                conf = float(box.conf[0])
                cls_name = self.class_names[cls_id]
                self.class_counts[cls_name] += 1

                if conf < self.fp_threshold:
                    self.suspicious_objects += 1 # 오탐 의심 객체 수
                    has_suspicion = True
                    suspected_boxes.append(box)

            if has_suspicion:
                case_data = {'path': res.path, 'orig_img': res.orig_img, 'boxes': suspected_boxes}
                self.fp_cases.append(case_data)
                new_fp_cases.append(case_data)

        return new_fp_cases

    def get_summary(self):
        avg_ms = np.mean(self.inference_times) if self.inference_times else 0
        fps = 1000 / avg_ms if avg_ms > 0 else 0
        return {'total_img' : self.total_image,
                'total_obj' : self.total_objects,
                'suspicious_obj' : self.suspicious_objects,
                'counts': self.class_counts,
                'fp_files_count': len(self.fp_cases),
                'fp_files': [os.path.basename(c['path']) for c in self.fp_cases],
                'fps': fps
                }
    def get_fp_case_by_index(self, index):
        if 0 <= index < len(self.fp_cases):
            return self.fp_cases[index]
        return None

class InspectionWorker(QThread):

    result_ready = Signal(list, dict)
    finished = Signal()

    def __init__(self, model_path, img_paths, export_dir='exported_suspects', batch_size=16, fp_threshold=0.45):
        super().__init__()
        self.engine = InferenceEngine(model_path)
        self.stats = StateManager(self.engine.class_names, fp_threshold)
        self.img_paths = img_paths
        self.batch_size = batch_size
        self.is_running = True

        self.export_dir = export_dir
        os.makedirs(self.export_dir, exist_ok=True)

    def run(self):
        for i in range(0, len(self.img_paths), self.batch_size):
            if not self.is_running: break

            batch = self.img_paths[i:i+self.batch_size]
            results = self.engine.predict_batch(batch, batch_size=self.batch_size)

            new_fp_case = self.stats.update(results)
            for case in new_fp_case:
                self._auto_save_image(case)

            self.result_ready.emit(list(results), self.stats.get_summary())

        self.finished.emit()

    def _auto_save_image(self, case):
        """의심 이미지 저장"""
        orig_filename = os.path.basename(case['path'])
        name, ext = os.path.splitext(orig_filename)
        save_path = os.path.join(os.path.dirname(self.export_dir), self.export_dir, f'{name}_suspect{ext}')

        img = case['orig_img'].copy()
        h, w, c = img.shape

        qimg = QImage(img.data, w, h, w*c, QImage.Format_RGB888).rgbSwapped()
        painter = QPainter(qimg)

        line_thickness = max(3, int(h * 0.005))
        font_size = max(12, int(h * 0.02))

        font = painter.font()
        font.setPointSize(font_size)
        font.setBold(True)
        painter.setFont(font)
        metrics = painter.fontMetrics()

        for box in case['boxes']:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            conf = float(box.conf[0])
            cls_id = int(box.cls[0])
            cls_name = self.stats.class_names[cls_id]   # AI가 추론한 클래스이름

            painter.setPen(QPen(QColor(255, 0, 0), line_thickness))
            painter.drawRect(x1, y1, x2 - x1, y2 - y1)

            text = f"의심: {cls_name}({conf:.2f})"
            text_width = metrics.horizontalAdvance(text)
            text_height = metrics.height()

            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(255, 0, 0, 200))

            bg_y = y1 - text_height - 10 if y1 > text_height + 10 else y1 + 10
            painter.drawRect(x1, bg_y, text_width + 20, text_height + 10)

            painter.setPen(QColor(255, 255, 255))
            painter.drawText(x1 + 10, bg_y + text_height, text)

        painter.end()

        qimg.save(save_path, quality=100)

    def stop(self):
        self.is_running = False


class HighSpeedInspectionSystem(QMainWindow):

    def __init__(self):
        super().__init__()
        self.worker = None
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle('AI 검수 및 오탐지 확인')

        self.resize(1500, 900)

        main_widget = QWidget()
        main_layout = QHBoxLayout(main_widget)

        # 왼쪽
        side_panel = QVBoxLayout()

        self.btn_select_model = QPushButton("모델 파일 선택(.pt)")
        self.lbl_model_status = QLabel("선택된 모델 : 없음")
        self.lbl_model_status.setStyleSheet("color:gray ; font-size:10px;")

        self.chk_label_bbox = QCheckBox("라벨링 바인딩박스 표시")
        self.btn_load_dir = QPushButton("폴더 선택")
        self.btn_start = QPushButton("시작")
        self.btn_start.setStyleSheet("background-color: #0078d7; color: white; font-weight: bold; height: 40px")

        self.file_list = QListWidget()
        self.file_list.currentRowChanged.connect(self.show_dataset_detail)

        side_panel.addWidget(QLabel("<b>설정 및 제어</b>"))
        side_panel.addWidget(self.btn_select_model)
        side_panel.addWidget(self.lbl_model_status)
        side_panel.addSpacing(10)
        side_panel.addWidget(QLabel("<b>데이터셋 목록</b>"))
        side_panel.addWidget(self.file_list)
        side_panel.addWidget(self.chk_label_bbox)
        side_panel.addWidget(self.btn_load_dir)
        side_panel.addWidget(self.btn_start)

        # 중앙
        self.viewer = QLabel("모델과 폴더를 먼저 로드해 주세요")
        self.viewer.setAlignment(Qt.AlignCenter)
        self.viewer.setStyleSheet("background-color: #1a1a1a; border 2px solid #333; border-radius: 5px;")

        # 오늘쪽
        dash_panel = QVBoxLayout()

        stats_group = QGroupBox("실시간 성능 통계")
        stats_layout = QGridLayout()
        self.lbl_fps = QLabel("FPS : -")
        self.lbl_total = QLabel("Total : 0")
        self.lbl_fp_count = QLabel("Suspicious : 0")
        self.lbl_fp_count.setStyleSheet("color: #ff4d4d;")
        stats_layout.addWidget(self.lbl_fps, 0, 0)
        stats_layout.addWidget(self.lbl_total, 0, 1)
        stats_layout.addWidget(self.lbl_fp_count, 1, 0)
        stats_group.setLayout(stats_layout)

        # 오탐 리스트
        fp_group = QGroupBox("오탐 의심 리스트(Review)")
        fp_layout = QVBoxLayout()
        self.fp_list_widget = QListWidget()
        self.fp_list_widget.currentRowChanged.connect(self.show_fp_detail)
        fp_layout.addWidget(self.fp_list_widget)
        fp_group.setLayout(fp_layout)

        dash_panel.addWidget(stats_group, 1)
        dash_panel.addWidget(fp_group, 3)

        main_layout.addLayout(side_panel, 1)
        main_layout.addWidget(self.viewer, 3)
        main_layout.addLayout(dash_panel, 1)

        self.setCentralWidget(main_widget)

        self.btn_select_model.clicked.connect(self.select_model)
        self.btn_load_dir.clicked.connect(self.select_directory)
        self.btn_start.clicked.connect(self.run_inspection)


    def select_model(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "YOLO 모델 선택", "", "YOLO Models( *.pt *.engine);;All Files (*)")
        if file_path:
            self.model_path = file_path
            file_name = os.path.basename(file_path)
            self.lbl_model_status.setText(f"선택된 모델 : {file_name}")
            self.lbl_model_status.setStyleSheet("color:#00ff00 ; font-weight: bold;")


    def select_directory(self):
        path = QFileDialog.getExistingDirectory(self, "이미지 폴더 선택")
        if path:
            self.current_dir = path
            files = [f for f in os.listdir(path) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
            self.file_list.clear()
            self.file_list.addItems(files)
            self.img_paths = [os.path.join(path, f) for f in files]


    def run_inspection(self):
        if not self.model_path:
            QMessageBox.warning(self, "경고", "먼저 모델 파일을 선택하세요")
            return
        if not hasattr(self, 'img_paths') or not self.img_paths:
            QMessageBox.warning(self, "경고", "이미지 폴더를 선택하세요")
            return

        # TODO 수정
        target_export_dir = os.path.abspath('exported_suspects')

        self.worker = InspectionWorker(self.model_path, self.img_paths, export_dir=target_export_dir, batch_size=16)
        self.worker.result_ready.connect(self.update_ui)
        self.worker.finished.connect(self.worker_finish)
        self.worker.start()

        self.btn_start.setEnabled(False)
        self.lbl_model_status.setText(f"실행 중 :{os.path.basename(self.model_path)}")

    def worker_finish(self):
        self.btn_start.setEnabled(True)

    def update_ui(self, results, summary):
        # 통계 갱신
        self.lbl_fps.setText(f"FPS : {summary['fps']:.1f}")
        self.lbl_total.setText(f"검수 이미지 : {summary['total_img']}\n탐지 객체 {summary['total_obj']}")
        self.lbl_fp_count.setText(f"의심 이미지 : {summary['fp_files_count']}\n의심 객체 : {summary['suspicious_obj']}")

        if self.fp_list_widget.count() != summary['fp_files_count']:
            self.fp_list_widget.clear()
            self.fp_list_widget.addItems(summary['fp_files'])

        self.draw_normal(results[-1])

    def draw_normal(self, result):
        img = result.plot()
        self.set_viewer_image(img)

    def show_dataset_detail(self, idx):
        if idx < 0 or not hasattr(self, 'img_paths'):
            return
        filename = self.file_list.item(idx).text()
        img_path = os.path.normpath(os.path.join(self.current_dir, filename))

        img_array = np.fromfile(img_path, np.uint8)
        img = cv2.imdecode(img_array, cv2.IMREAD_COLOR)

        if img is None:
            self.viewer.setText('이미지를 불러올수 없습니다.')
            return

        h, w, c = img.shape
        logger.debug(f"h {h} w {w} c {c}")

        # labels 파일의 정보로 바운딩 박스 표시 기능 추가
        if self.chk_label_bbox.isChecked():

            name, _ = os.path.splitext(filename)
            label_path = os.path.join(self.current_dir.replace('images', 'labels'), name + '.txt')

            logger.debug(f"label_path {label_path}")

            qimg = QImage(img.data, w, h, w * c, QImage.Format_RGB888).rgbSwapped()
            pixmap = QPixmap.fromImage(qimg)
            painter = QPainter(pixmap)

            if os.path.exists(label_path):
                pen = QPen(QColor(0, 255, 255), max(3, int(h * 0.005)))
                painter.setPen(pen)

                font = painter.font()
                font.setBold(True)
                font.setPointSize(max(12, int(h * 0.02)))
                painter.setFont(font)

                logger.debug(label_path)

                with open(label_path, 'r', encoding='utf-8') as f:
                    for line in f.readlines():
                        parts = line.strip().split()
                        logger.debug(parts)
                        if len(parts) >= 5:
                            cls_id = int(parts[0])
                            cx, cy, bw, bh = map(float, parts[1:5])
                            x1 = int((cx - bw / 2) * w)
                            y1 = int((cy - bh / 2) * h)
                            box_w = int(bw * w)
                            box_h = int(bh * h)

                            painter.drawRect(x1, y1, box_w, box_h)

                            cls_name = str(cls_id)

                            painter.drawText(x1, y1 - 10, f"{cls_name}")

                painter.end()
                self.viewer.setPixmap(pixmap.scaled(self.viewer.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))




        else:
            result = self.worker.engine.model.predict(img, conf=0.25, save=False, verbose=False)

            if result:
                res_img = result[0].plot()
                qimg = QImage(res_img.data, w, h, w * c, QImage.Format_RGB888).rgbSwapped()

                self.viewer.setPixmap(QPixmap.fromImage(qimg).scaled(self.viewer.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))


    def show_fp_detail(self, idx):
        if idx < 0 or not self.worker: return
        case = self.worker.stats.get_fp_case_by_index(idx)
        if case:
            self.draw_fp_custom(case)


    def draw_fp_custom(self, case):
        img = case['orig_img'].copy()
        h, w, c = img.shape
        qimg = QImage(img.data, w, h, w*c, QImage.Format_RGB888).rgbSwapped()
        pixmap = QPixmap.fromImage(qimg)

        painter = QPainter(pixmap)

        # 모델의 클래스 이름 정보 가져오기
        class_names = self.worker.stats.class_names

        # 원본 이미지 해상도에 비례하여 선 굵기와 폰트 크기 자동 조절
        line_thickness = max(3, int(h * 0.005))
        font_size = max(12, int(h * 0.02))

        font = painter.font()
        font.setPointSize(font_size)
        font.setBold(True)
        painter.setFont(font)
        metrics = painter.fontMetrics()

        for box in case['boxes']:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            conf = float(box.conf[0])
            cls_id = int(box.cls[0])
            cls_name = class_names[cls_id]   # AI가 추론한 클래스이름

            painter.setPen(QPen(QColor(255, 0, 0), line_thickness))
            painter.drawRect(x1, y1, x2 - x1, y2 - y1)

            text = f"의심: {cls_name}({conf:.2f})"
            text_width = metrics.horizontalAdvance(text)
            text_height = metrics.height()

            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(255, 0, 0, 200))

            bg_y = y1 - text_height - 10 if y1 > text_height + 10 else y1 + 10
            painter.drawRect(x1, bg_y, text_width + 20, text_height + 10)

            painter.setPen(QColor(255, 255, 255))
            painter.drawText(x1 + 10, bg_y + text_height, text)

        painter.end()

        self.viewer.setPixmap(pixmap.scaled(self.viewer.size(), Qt.KeepAspectRatio))

    def set_viewer_image(self, img):
        h, w, c = img.shape
        qimg = QImage(img.data, w, h, w*c, QImage.Format_RGB888).rgbSwapped()
        self.viewer.setPixmap(QPixmap.fromImage(qimg).scaled(self.viewer.size(), Qt.KeepAspectRatio))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = HighSpeedInspectionSystem()
    window.show()

    sys.exit(app.exec())
