import os, sys
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, 
    QLineEdit, QComboBox, QSpinBox, QPushButton, 
    QGroupBox, QProgressBar, QTextEdit, QFileDialog, QMessageBox
)
from PySide6.QtCore import Qt, QThread, Signal
import qtawesome as qta

class TrainingWorker(QThread):
    """
    백그라운드에서 YOLO 모델 학습을 수행하는 워커 스레드.
    (실제 구현 시 ultralytics 패키지를 임포트하여 YOLO 클래스를 사용합니다)
    """
    log_signal = Signal(str)
    progress_signal = Signal(int)
    finished_signal = Signal(bool, str)

    def __init__(self, data_path, model_path, epochs, batch_size, imgsz, device):
        super().__init__()
        self.data_path = data_path
        self.model_path = model_path
        self.epochs = epochs
        self.batch_size = batch_size
        self.imgsz = imgsz
        self.device = device
        self._is_running = True

    def run(self):
        try:
            self.log_signal.emit("학습 준비 중...")
            self.log_signal.emit(f"데이터셋: {self.data_path}")
            self.log_signal.emit(f"모델: {self.model_path}")
            self.log_signal.emit(f"Epochs: {self.epochs}, Batch: {self.batch_size}, Imgsz: {self.imgsz}, Device: {self.device}")
            
            # 실제 YOLO 학습 코드 (ultralytics가 설치되어 있다는 가정 하에)
            # from ultralytics import YOLO
            # model = YOLO(self.model_path)
            # results = model.train(
            #     data=self.data_path,
            #     epochs=self.epochs,
            #     batch=self.batch_size,
            #     imgsz=self.imgsz,
            #     device=self.device,
            #     project="runs/train",
            #     name="exp",
            #     exist_ok=True
            # )
            
            # 시뮬레이션용 코드
            import time
            for i in range(1, self.epochs + 1):
                if not self._is_running:
                    self.log_signal.emit("학습이 중지되었습니다.")
                    self.finished_signal.emit(False, "학습 중단됨")
                    return
                    
                time.sleep(0.5)  # 에포크 당 시간 시뮬레이션
                progress = int((i / self.epochs) * 100)
                self.progress_signal.emit(progress)
                self.log_signal.emit(f"Epoch [{i}/{self.epochs}] 완료 (loss 시뮬레이션: {max(0.01, 2.0 / i):.4f})")
                
            self.log_signal.emit("학습이 성공적으로 완료되었습니다.")
            self.finished_signal.emit(True, "학습 완료 저장 폴더: runs/train/exp")
            
        except ImportError:
            self.log_signal.emit("오류: ultralytics 패키지를 찾을 수 없습니다. pip install ultralytics를 실행하세요.")
            self.finished_signal.emit(False, "패키지 없음")
        except Exception as e:
            self.log_signal.emit(f"학습 중 오류 발생: {str(e)}")
            self.finished_signal.emit(False, str(e))

    def stop(self):
        self._is_running = False


class WidgetTrainingDialog(QDialog):
    """
    YOLO 객체 탐지 모델 학습을 위한 다이얼로그
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.worker = None
        self._setup_ui()
        self.resize(600, 700)

    def _setup_ui(self):
        self.setWindowTitle("객체 탐지 모델 학습 (Training)")
        
        main_layout = QVBoxLayout(self)

        # 1. 설정 그룹박스
        settings_group = QGroupBox("학습 설정 (Training Settings)")
        form_layout = QFormLayout(settings_group)
        
        # 데이터셋 경로
        self.dataset_layout = QHBoxLayout()
        self.dataset_edit = QLineEdit()
        self.dataset_edit.setPlaceholderText("data.yaml 파일이 있는 폴더나 yaml 파일 경로")
        self.dataset_btn = QPushButton("찾아보기...")
        self.dataset_btn.clicked.connect(self._browse_dataset)
        self.dataset_layout.addWidget(self.dataset_edit)
        self.dataset_layout.addWidget(self.dataset_btn)
        form_layout.addRow("데이터셋 (Dataset):", self.dataset_layout)
        
        # 사전 학습 모델 경로
        self.model_layout = QHBoxLayout()
        self.model_combo = QComboBox()

        if getattr(sys, 'frozen', False):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            
        models_dir = os.path.join(base_dir, "models")
        model_files = []
        if os.path.exists(models_dir):
            model_files = [f for f in os.listdir(models_dir) if f.endswith(".pt")]
            model_files.sort()

        self.model_combo.addItems(model_files)

        self.model_combo.currentIndexChanged.connect(self._on_model_combo_changed)
        
        self.model_edit = QLineEdit("yolo11n.pt")
        self.model_edit.setPlaceholderText("기본 모델명 또는 .pt 파일 경로")
        self.model_btn = QPushButton("찾아보기...")
        self.model_btn.clicked.connect(self._browse_model)
        self.model_btn.setVisible(False)
        self.model_edit.setVisible(False)
        
        self.model_layout.addWidget(self.model_combo)
        self.model_layout.addWidget(self.model_edit)
        self.model_layout.addWidget(self.model_btn)
        form_layout.addRow("사전 모델 (Base Model):", self.model_layout)
        
        # Epochs
        self.epochs_spin = QSpinBox()
        self.epochs_spin.setRange(1, 10000)
        self.epochs_spin.setValue(100)
        form_layout.addRow("에포크 (Epochs):", self.epochs_spin)
        
        # Batch Size
        self.batch_combo = QComboBox()
        self.batch_combo.addItems(["2", "4", "8", "16", "32", "64", "128", "-1 (Auto)"])
        self.batch_combo.setCurrentText("16")
        form_layout.addRow("배치 크기 (Batch Size):", self.batch_combo)
        
        # Image Size
        self.imgsz_spin = QSpinBox()
        self.imgsz_spin.setRange(32, 4096)
        self.imgsz_spin.setSingleStep(32)
        self.imgsz_spin.setValue(640)
        form_layout.addRow("이미지 크기 (Image Size):", self.imgsz_spin)
        
        # Device
        self.device_combo = QComboBox()
        self.device_combo.addItems(["auto", "0", "0,1", "cpu", "mps"])
        self.device_combo.setCurrentIndex(0)
        form_layout.addRow("학습 장치 (Device):", self.device_combo)
        
        main_layout.addWidget(settings_group)
        
        # 2. 제어 버튼
        button_layout = QHBoxLayout()
        self.start_btn = QPushButton("학습 시작")
        self.start_btn.setIcon(qta.icon('mdi.play'))
        self.start_btn.setStyleSheet("background-color: #3fb950; color: white; font-weight: bold; padding: 8px;")
        self.start_btn.clicked.connect(self._start_training)
        
        self.stop_btn = QPushButton("학습 중지")
        self.stop_btn.setIcon(qta.icon('mdi.stop'))
        self.stop_btn.setStyleSheet("background-color: #f85149; color: white; font-weight: bold; padding: 8px;")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self._stop_training)
        
        button_layout.addWidget(self.start_btn)
        button_layout.addWidget(self.stop_btn)
        main_layout.addLayout(button_layout)
        
        # 3. 진행 상태
        progress_group = QGroupBox("진행 상태 (Progress)")
        progress_layout = QVBoxLayout(progress_group)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        progress_layout.addWidget(self.progress_bar)
        
        self.log_console = QTextEdit()
        self.log_console.setReadOnly(True)
        self.log_console.setStyleSheet("background-color: #1e1e1e; color: #d4d4d4; font-family: Consolas, monospace;")
        progress_layout.addWidget(self.log_console)
        
        main_layout.addWidget(progress_group)

    def _browse_dataset(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "데이터셋 설정 파일 선택 (data.yaml)", "", "YAML Files (*.yaml *.yml);;All Files (*)"
        )
        if file_path:
            self.dataset_edit.setText(file_path)

    def _on_model_combo_changed(self, index):
        # "직접 선택..."을 고른 경우
        if index == self.model_combo.count() - 1:
            self.model_edit.setVisible(True)
            self.model_btn.setVisible(True)
            self.model_combo.setVisible(False)
        else:
            self.model_edit.setText(self.model_combo.currentText())

    def _browse_model(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "YOLO 모델 파일 선택 (.pt)", "", "PyTorch Models (*.pt);;All Files (*)"
        )
        if file_path:
            self.model_edit.setText(file_path)

    def _append_log(self, text):
        self.log_console.append(text)
        # 스크롤 최하단으로 이동
        scrollbar = self.log_console.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def _get_batch_size(self):
        txt = self.batch_combo.currentText()
        if "Auto" in txt:
            return -1
        return int(txt)

    def _start_training(self):
        req_data = self.dataset_edit.text().strip()
        if not req_data:
            QMessageBox.warning(self, "경고", "데이터셋(data.yaml) 파일 경로를 지정해주세요.")
            return
            
        model_path = self.model_edit.text().strip()

        # UI 상태 변경
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.dataset_btn.setEnabled(False)
        self.model_btn.setEnabled(False)
        self.epochs_spin.setEnabled(False)
        self.batch_combo.setEnabled(False)
        self.imgsz_spin.setEnabled(False)
        self.device_combo.setEnabled(False)
        
        self.progress_bar.setValue(0)
        self.log_console.clear()
        
        # 워커 시작
        self.worker = TrainingWorker(
            data_path=req_data,
            model_path=model_path,
            epochs=self.epochs_spin.value(),
            batch_size=self._get_batch_size(),
            imgsz=self.imgsz_spin.value(),
            device=self.device_combo.currentText()
        )
        self.worker.log_signal.connect(self._append_log)
        self.worker.progress_signal.connect(self.progress_bar.setValue)
        self.worker.finished_signal.connect(self._on_training_finished)
        
        self.worker.start()

    def _stop_training(self):
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.stop_btn.setEnabled(False)
            self._append_log("중지 신호를 보냈습니다. 잠시 기다려주세요...")

    def _on_training_finished(self, success, message):
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.dataset_btn.setEnabled(True)
        self.model_btn.setEnabled(True)
        self.epochs_spin.setEnabled(True)
        self.batch_combo.setEnabled(True)
        self.imgsz_spin.setEnabled(True)
        self.device_combo.setEnabled(True)
        
        if success:
            QMessageBox.information(self, "학습 완료", f"학습이 성공적으로 완료되었습니다.\n{message}")
        else:
            QMessageBox.warning(self, "학습 종료", f"학습이 종료되었습니다.\n이유: {message}")

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            reply = QMessageBox.question(
                self, '경고', '학습이 진행 중입니다. 정말 종료하시겠습니까?',
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No
            )
            if reply == QMessageBox.Yes:
                self.worker.stop()
                self.worker.wait(2000) # 2초 대기
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()
