import sys
import os
import yaml
from pathlib import Path
import cv2
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter

from PySide6.QtWidgets import (QApplication, QDialog, QWidget, QVBoxLayout, 
                               QHBoxLayout, QFormLayout, QPushButton, QLineEdit, QLabel, 
                               QFileDialog, QTextEdit, QTabWidget, QSplitter, QMessageBox, QGroupBox, QSizePolicy)
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QPixmap, QFont
import qtawesome as qta

class ValidationWorker(QThread):
    log_signal = Signal(str)
    finished_signal = Signal(bool, dict)

    def __init__(self, dataset_dir):
        super().__init__()
        self.dataset_dir = dataset_dir

    def log(self, message):
        self.log_signal.emit(message)

    def run(self):
        dataset_path = Path(self.dataset_dir)
        yaml_path = dataset_path / "data.yaml"
        
        self.log("="*60)
        self.log(f"🔍 데이터셋 검증 개시: {self.dataset_dir}")
        self.log("="*60)
        
        if not yaml_path.exists():
            self.log(f"❌ [오류] 설정 파일을 찾을 수 없습니다: {yaml_path}")
            self.finished_signal.emit(False, {})
            return
            
        try:
            with open(yaml_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
        except Exception as e:
            self.log(f"❌ [오류] yaml 파일 로딩 실패: {e}")
            self.finished_signal.emit(False, {})
            return
            
        nc = data.get('nc', -1)
        names = data.get('names', [])
        
        self.log(f"✅ 클래스 개수(nc): {nc}")
        self.log(f"✅ 클래스 이름(names): {names}\n")
        
        if nc != len(names):
            self.log(f"⚠️ [경고] data.yaml 내 'nc'({nc})와 'names' 리스트 개수({len(names)})가 다릅니다.")
            
        splits = ['train', 'valid', 'val', 'test']
        total_issues = 0
        total_images_checked = 0
        total_labels_checked = 0
        
        stat_class_counts = Counter()
        stat_widths = []
        stat_heights = []
        stat_center_x = []
        stat_center_y = []
        stat_empty_images = 0
        
        for split in splits:
            split_path = dataset_path / split
            if split == 'val' and not split_path.exists() and (dataset_path / 'valid').exists():
                continue 
            if not split_path.exists():
                continue
                
            self.log(f"🔎 >> [{split.upper()}] 폴더 무결성/통계 데이터 수집 중...")
            
            images_dir = split_path / 'images' if (split_path / 'images').exists() else split_path
            labels_dir = split_path / 'labels' if (split_path / 'labels').exists() else split_path
            
            image_extensions = ['.jpg', '.jpeg', '.png', '.JPG', '.JPEG', '.PNG']
            image_files = []
            for ext in image_extensions:
                image_files.extend(list(images_dir.glob(f'**/*{ext}')))
                
            if len(image_files) == 0:
                self.log(f"   ⚠️ [경고] {split} 폴더 내 이미지가 없습니다.")
                continue
                
            split_issues = 0
            
            for index, img_path in enumerate(image_files):
                total_images_checked += 1
                
                img = cv2.imread(str(img_path))
                if img is None:
                    self.log(f"   ❌ [오류] 이미지가 손상되었거나 읽을 수 없습니다: {img_path.name}")
                    split_issues += 1
                    continue
                    
                if img_path.parent.name == 'images':
                    label_path = img_path.parent.parent / 'labels' / img_path.with_suffix('.txt').name
                else:
                    label_path = img_path.with_suffix('.txt')
                    
                if not label_path.exists():
                    stat_empty_images += 1
                    continue
                    
                total_labels_checked += 1
                
                with open(label_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    
                if len(lines) == 0:
                    stat_empty_images += 1
                    
                for line_no, line in enumerate(lines, 1):
                    parts = line.strip().split()
                    if len(parts) == 0:
                        continue
                        
                    if len(parts) != 5:
                        self.log(f"   ❌ [오류] 라벨 포맷 불량(5개 값 필요) - 파일: {label_path.name}, 라인: {line_no}")
                        split_issues += 1
                        continue
                        
                    class_id_str, x_str, y_str, w_str, h_str = parts
                    try:
                        class_id = int(class_id_str)
                        x, y, w, h = float(x_str), float(y_str), float(w_str), float(h_str)
                    except ValueError:
                        self.log(f"   ❌ [오류] 라벨 값이 숫자가 아닙니다 - 파일: {label_path.name}, 라인: {line_no}")
                        split_issues += 1
                        continue
                        
                    if nc > 0 and (class_id < 0 or class_id >= nc):
                        self.log(f"   ❌ [오류] 클래스 ID 범위 이탈 (ID: {class_id}, 허용: 0~{nc-1}) - 파일: {label_path.name}")
                        split_issues += 1
                        continue
                        
                    if not (0.0 <= x <= 1.0 and 0.0 <= y <= 1.0 and 0.0 <= w <= 1.0 and 0.0 <= h <= 1.0):
                        self.log(f"   ❌ [오류] BBox 좌표가 정규화 범위(0~1)를 이탈했습니다 - 파일: {label_path.name}")
                        split_issues += 1
                        continue
                        
                    stat_class_counts[class_id] += 1
                    stat_widths.append(w)
                    stat_heights.append(h)
                    stat_center_x.append(x)
                    stat_center_y.append(y)
                        
            total_issues += split_issues
            
        self.log("\n" + "="*60)
        self.log("📊 1. 데이터셋 무결성 검증 결과 요약")
        self.log("="*60)
        self.log(f"총 검사된 이미지 파일수 : {total_images_checked} 개")
        self.log(f"총 유효 라벨 파일수     : {total_labels_checked} 개 (- 배경 이미지 {stat_empty_images} 개 제외)")
        self.log(f"탐지된 총 오류/경고 수  : {total_issues} 건")
        
        self.log("\n" + "="*60)
        self.log("📈 2. 통계적 밸런스 및 분포 (Statistical Distribution)")
        self.log("="*60)
        
        if len(stat_class_counts) == 0:
            self.log("객체가 하나도 검출되지 않았습니다. 시각화를 건너뜁니다.")
            self.finished_signal.emit(total_issues == 0, {})
            return
            
        self.log("\n[클래스 인스턴스 비율]")
        total_objects = sum(stat_class_counts.values())
        class_labels = []
        class_vals = []
        
        for c_id in range(nc):
            count = stat_class_counts.get(c_id, 0)
            c_name = names[c_id] if c_id < len(names) else f"Class_{c_id}"
            ratio = (count / total_objects) * 100 if total_objects > 0 else 0
            self.log(f" - {c_name} (ID {c_id}): {count} 개 ({ratio:.1f}%)")
            class_labels.append(c_name)
            class_vals.append(count)
            
            if ratio < 5.0 and len(names) > 1:
                self.log(f"   👉 [경고] '{c_name}' 클래스 데이터가 전체의 5% 미만입니다. 추가 수집을 권장합니다.")
                
        bg_ratio = (stat_empty_images / total_images_checked) * 100 if total_images_checked > 0 else 0
        self.log(f"\n[배경(Background) 이미지 비율]: {bg_ratio:.1f}% ({stat_empty_images} / {total_images_checked})")
        if bg_ratio < 1.0 or bg_ratio > 10.0:
            self.log("   👉 [팁] Background(빈 공간) 이미지를 1%~10% 수준으로 유지하면 False Positive 억제에 도움이 됩니다.")

        self.log("\n데이터 시각화 그래프를 생성합니다...")
        sns.set_theme(style="whitegrid")
        plt.rc('font', family='Malgun Gothic')
        plt.rcParams['axes.unicode_minus'] = False
        
        plots_dir = dataset_path / "analysis_reports"
        plots_dir.mkdir(exist_ok=True)
        
        reports_paths = {}
        
        # 1) 분포 히스토그램 생성
        try:
            plt.figure(figsize=(8, 5))
            # hue와 legend를 제거하고, color 파라미터 적용 (FutureWarning 방어)
            sns.barplot(x=class_labels, y=class_vals, palette="viridis", hue=class_labels, legend=False)
            plt.title("Class Distribution (클래스별 객체 개수)")
            plt.ylabel("Object Count")
            plt.xlabel("Class")
            for i, v in enumerate(class_vals):
                plt.text(i, v + (max(class_vals)*0.01) if max(class_vals) > 0 else v + 0.1, str(v), color='black', ha='center')
            path1 = plots_dir / "class_distribution.png"
            plt.savefig(path1, dpi=200, bbox_inches='tight')
            plt.close()
            reports_paths['class_distribution'] = str(path1)
        except Exception as e:
             self.log(f"그래프 1 생성 오류: {e}")

        # 2) 바운딩 박스 크기 산점도
        try:
            plt.figure(figsize=(6, 6))
            sns.scatterplot(x=stat_widths, y=stat_heights, alpha=0.3, s=15, color="b")
            plt.title("Bounding Box Size Distribution (크기 산점도)")
            plt.xlabel("Normalized Width (0.0 - 1.0)")
            plt.ylabel("Normalized Height (0.0 - 1.0)")
            plt.xlim(0, 1)
            plt.ylim(0, 1)
            plt.plot([0,1], [0,1], transform=plt.gca().transAxes, ls="--", color="gray")
            path2 = plots_dir / "bbox_size_scatter.png"
            plt.savefig(path2, dpi=200, bbox_inches='tight')
            plt.close()
            reports_paths['bbox_size_scatter'] = str(path2)
        except Exception as e:
             self.log(f"그래프 2 생성 오류: {e}")

        # 3) 바운딩 박스 위치 히트맵
        try:
            plt.figure(figsize=(6, 6))
            plt.hist2d(stat_center_x, stat_center_y, bins=50, cmap='YlOrRd')
            plt.colorbar(label='Object Count Density')
            plt.title("Spatial Object Density (객체 출현 위치 히트맵)")
            plt.xlabel("Normalized X Center (Left to Right)")
            plt.ylabel("Normalized Y Center (Top to Bottom)")
            plt.gca().invert_yaxis()
            plt.xlim(0, 1)
            plt.ylim(1, 0)
            path3 = plots_dir / "bbox_spatial_heatmap.png"
            plt.savefig(path3, dpi=200, bbox_inches='tight')
            plt.close()
            reports_paths['bbox_spatial_heatmap'] = str(path3)
        except Exception as e:
             self.log(f"그래프 3 생성 오류: {e}")

        self.log(f"🥳 시각화 리포트 생성 완료 -> {plots_dir.absolute()}")
        self.finished_signal.emit(total_issues == 0, reports_paths)


class WidgetValidateDataset(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)  # type: ignore
        self.setWindowTitle("객체 탐지 데이터셋 검증 (Dataset Validation)")
        self.resize(1100, 750)
        self.reports_paths = {}
        self.worker = None
        self._setup_ui()

    def _setup_ui(self):
        main_layout = QVBoxLayout(self)

        # 1. 설정 그룹박스
        settings_group = QGroupBox("검증 설정 (Validation Settings)")
        settings_group.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        form_layout = QFormLayout(settings_group)
        
        # 데이터셋 경로
        self.dataset_layout = QHBoxLayout()
        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("검증할 datasets 폴더 경로를 선택하세요 (data.yaml 위치)")
        
        self.btn_browse = QPushButton("찾아보기...")
        self.btn_browse.setIcon(qta.icon('mdi6.folder-open', color='white'))
        self.btn_browse.clicked.connect(self.browse_folder)

        self.btn_validate = QPushButton("검증 시작")
        self.btn_validate.setIcon(qta.icon('mdi.play'))
        self.btn_validate.setStyleSheet("background-color: #3fb950; color: white; font-weight: bold; padding: 6px 12px;")
        self.btn_validate.clicked.connect(self.start_validation)
        
        self.dataset_layout.addWidget(self.path_edit)
        self.dataset_layout.addWidget(self.btn_browse)
        self.dataset_layout.addWidget(self.btn_validate)
        
        form_layout.addRow("데이터셋 (Dataset):", self.dataset_layout)
        
        main_layout.addWidget(settings_group)

        # 2. 메인 스플리터 (좌측 텍스트 로그, 우측 시각화 탭)
        splitter = QSplitter(Qt.Horizontal)
        
        # 좌측 텍스트 로그 창 (그룹박스 내)
        log_group = QGroupBox("진행 로그 (Log)")
        log_layout = QVBoxLayout(log_group)
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("background-color: #1e1e1e; color: #d4d4d4; font-family: Consolas, monospace;")
        log_layout.addWidget(self.log_text)
        
        splitter.addWidget(log_group)
        
        # 우측 시각화 탭 (그룹박스 내)
        viz_group = QGroupBox("시각화 리포트 (Visualization)")
        viz_layout = QVBoxLayout(viz_group)
        
        self.tab_widget = QTabWidget()
        
        # 1. 클래스 분포 탭
        tab1 = QWidget()
        layout1 = QVBoxLayout(tab1)
        self.label_class_dist = QLabel("실행을 완료하면 시각화 결과가 표시됩니다.")
        self.label_class_dist.setAlignment(Qt.AlignCenter)
        desc1 = QLabel("💡 <b>해석 가이드:</b> 클래스별 객체 개수 분포입니다. 특정 클래스 빈도가 너무 낮으면 불균형으로 인해 인식률이 떨어질 수 있습니다.")
        desc1.setWordWrap(True)
        layout1.addWidget(self.label_class_dist, stretch=1)
        layout1.addWidget(desc1)
        self.tab_widget.addTab(tab1, "📊 클래스 분포")
        
        # 2. 크기 산점도 탭
        tab2 = QWidget()
        layout2 = QVBoxLayout(tab2)
        self.label_bbox_size = QLabel("실행을 완료하면 시각화 결과가 표시됩니다.")
        self.label_bbox_size.setAlignment(Qt.AlignCenter)
        desc2 = QLabel("💡 <b>해석 가이드:</b> 객체의 상대적인 너비와 높이입니다. (0,0)에 가까우면 작은 객체, (1,1)에 가까우면 큰 객체입니다. 점들이 한 곳에 몰려있다면 특정 크기만 주로 존재한다는 의미이므로, 다양한 거리/크기의 데이터를 추가 확보하는 것이 좋습니다.")
        desc2.setWordWrap(True)
        layout2.addWidget(self.label_bbox_size, stretch=1)
        layout2.addWidget(desc2)
        self.tab_widget.addTab(tab2, "📈 크기 산점도")
        
        # 3. 위치 히트맵 탭
        tab3 = QWidget()
        layout3 = QVBoxLayout(tab3)
        self.label_heatmap = QLabel("실행을 완료하면 시각화 결과가 표시됩니다.")
        self.label_heatmap.setAlignment(Qt.AlignCenter)
        desc3 = QLabel("💡 <b>해석 가이드:</b> 이미지 내에서 객체의 중심점이 어디에 위치하는지 보여주는 열분포입니다. 붉은색에 객체가 밀집했다는 뜻입니다. 정중앙에만 객체가 몰려 있다면 모델이 위치에 무의식적인 편향(Overfitting)을 가질 수 있으므로, 크롭(Crop)이나 이동(Translation) 등의 데이터 증강이 필요합니다.")
        desc3.setWordWrap(True)
        layout3.addWidget(self.label_heatmap, stretch=1)
        layout3.addWidget(desc3)
        self.tab_widget.addTab(tab3, "🔥 위치 히트맵")
        
        viz_layout.addWidget(self.tab_widget)
        splitter.addWidget(viz_group)
        
        # 스플리터 비율 (로그창 : 이미지창)
        splitter.setSizes([450, 650])
        main_layout.addWidget(splitter, stretch=1)

    def browse_folder(self):
        # 기본 위치를 현재 디렉토리로 설정
        folder_path = QFileDialog.getExistingDirectory(self, "데이터셋 폴더 선택", ".")
        if folder_path:
            self.path_edit.setText(folder_path)

    def start_validation(self):
        dataset_dir = self.path_edit.text().strip()
        if not os.path.isdir(dataset_dir):
            QMessageBox.warning(self, "오류", "유효한 폴더 경로를 입력하거나 [폴더 선택] 버튼을 눌러주세요.")
            return
            
        self.log_text.clear()
        self.btn_validate.setEnabled(False)
        self.btn_validate.setText("검증 스캔 중...")
        self.btn_validate.setStyleSheet("background-color: #6e7681; color: white; font-weight: bold; padding: 8px;")
        
        # 시각화 초기화
        self.reports_paths = {}
        self.label_class_dist.clear()
        self.label_class_dist.setText("데이터 집계 및 시각화 생성 중...")
        self.label_bbox_size.clear()
        self.label_bbox_size.setText("데이터 집계 및 시각화 생성 중...")
        self.label_heatmap.clear()
        self.label_heatmap.setText("데이터 집계 및 시각화 생성 중...")
        
        # QThread를 이용해 백그라운드 검증 시작 (UI 프리징 방지)
        self.worker = ValidationWorker(dataset_dir)
        self.worker.log_signal.connect(self.append_log)
        self.worker.finished_signal.connect(self.on_validation_finished)
        self.worker.start()

    def append_log(self, message):
        self.log_text.append(message)
        # 로그가 추가될 때마다 스크롤을 맨 아래로 내림
        scrollbar = self.log_text.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def on_validation_finished(self, success, reports_paths):
        self.btn_validate.setEnabled(True)
        self.btn_validate.setText("검증 시작")
        self.btn_validate.setStyleSheet("background-color: #3fb950; color: white; font-weight: bold; padding: 8px;")
        
        self.reports_paths = reports_paths # 리사이즈 이벤트를 위해 저장
        
        if reports_paths:
            self.update_images()
                
        if success:
            QMessageBox.information(self, "검증 완료", "🎉 데이터셋 검증이 성공적으로 완료되었습니다.\n우측 탭에서 시각화 리포트를 확인하세요.")
        else:
            QMessageBox.warning(self, "검증 완료(경고)", "❗️ 데이터셋 검증이 종료되었으나 구조적 오류 또는 경고가 발견되었습니다.\n좌측 로그를 참조하세요.")

    def update_images(self):
        """현재 라벨 사이즈에 맞춰 이미지를 다시 사이즈 조정하여 화면에 그림"""
        if 'class_distribution' in self.reports_paths:
            pixmap = QPixmap(self.reports_paths['class_distribution'])
            self.label_class_dist.setPixmap(pixmap.scaled(self.label_class_dist.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
            
        if 'bbox_size_scatter' in self.reports_paths:
            pixmap = QPixmap(self.reports_paths['bbox_size_scatter'])
            self.label_bbox_size.setPixmap(pixmap.scaled(self.label_bbox_size.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
            
        if 'bbox_spatial_heatmap' in self.reports_paths:
            pixmap = QPixmap(self.reports_paths['bbox_spatial_heatmap'])
            self.label_heatmap.setPixmap(pixmap.scaled(self.label_heatmap.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def resizeEvent(self, event):
        """윈도우 창 크기가 변경될 때 이미지 크기도 다시 그려줍니다."""
        super().resizeEvent(event)
        if self.reports_paths:
            self.update_images()

if __name__ == "__main__":
    # 폰트 선명도 등 High DPI 설정 방어 (QApplication 생성 전 호출 필수)
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    
    app = QApplication(sys.argv)
    
    # OS 기본 퓨전 스타일 사용
    app.setStyle("Fusion")
    
    # standalone 실행 시 현재 테마(dark_style.qss) 적용
    style_path = Path(__file__).parent / "styles" / "dark_style.qss"
    if style_path.exists():
        with open(style_path, "r", encoding="utf-8") as f:
            app.setStyleSheet(f.read())
    
    window = WidgetValidateDataset()
    window.show()
    sys.exit(app.exec())
