@echo off
call "C:\anaconda3\condabin\activate.bat"
call conda activate py311_yolo11


start cd ../../Downloads