import importlib.util
import os
import shutil
import sys
import PyInstaller.__main__

# --- 빌드 설정 ---
APP_NAME = "CCTV_System"
MAIN_SCRIPT = "main.py"

# 실행 파일(_internal)에 포함할 데이터 파일 및 폴더 목록
# 형식: ('원본 경로', '실행 파일 내의 목적지 경로')
DATA_TO_INCLUDE = [
    ('styles', 'styles'),
]

# 모델 폴더에서 배포 폴더(dist/CCTV_System/models)로 복사할 확장자
#   - .pt   : WidgetSettingsDialog 및 core/detector.py 지원 모델 (ONNX/TensorRT 지원은 제거됨)
#   - .yaml : 모델 설정 파일
MODEL_EXTENSIONS = (".pt", ".yaml")

# PyInstaller 기본 명령줄 옵션
PYINSTALLER_OPTIONS = [
    '--noconfirm',
    '--noconsole',  # GUI 앱을 위한 콘솔 창 숨김
    '--clean',      # 빌드 전 캐시 및 임시 파일 정리
    # '--onefile',  # 단일 실행 파일로 묶음 (시작이 느리고 용량이 커서 기본 비활성화)

    # 1) 기본 필수 hidden-import
    '--hidden-import=numpy',
    '--hidden-import=PySide6.QtSvg',         # QSS 내 url(styles/*.svg) 체크박스·화살표 아이콘 렌더링 필수
    '--hidden-import=PySide6.QtSvgWidgets',

    # 2) 암호키(cctv_key.bin) 및 카메라 비밀번호 암복호화 모듈
    '--hidden-import=LeaCrypto',
    '--hidden-import=LEA',
    '--hidden-import=cryptography.fernet',
    '--hidden-import=cryptography.hazmat.primitives.hashes',
    '--hidden-import=cryptography.hazmat.primitives.kdf.pbkdf2',

    # 3) 불필요한 테스트·학습 모듈 제외
    '--exclude-module=pytest',
]
# ------------------


def _has_package(name: str) -> bool:
    """현재 빌드 환경에 패키지가 설치되어 있는지 확인합니다."""
    try:
        return importlib.util.find_spec(name) is not None
    except Exception:
        return False


def _collect_installed_package_options() -> list:
    """
    지연 import(함수 내부 import)되거나 내부 데이터 파일이 필요한 패키지 옵션을
    현재 환경 설치 여부에 맞춰 자동으로 구성합니다.
    """
    extra = []

    # qtawesome: 버튼 아이콘 폰트(.ttf, charmap .json) 데이터 포함
    if _has_package("qtawesome"):
        extra.append("--collect-data=qtawesome")

    # cv2 (OpenCV): RTSP 영상 수신에 필수인 opencv_videoio_ffmpeg*.dll 바이너리 포함
    if _has_package("cv2"):
        extra.append("--collect-binaries=cv2")

    # ultralytics (YOLO): core/detector.py 에서 지연 import 됨
    # 특히 ultralytics/cfg/default.yaml 등 설정 데이터가 빠지면 exe 에서 모델 로드가 실패함
    if _has_package("ultralytics"):
        extra.extend([
            "--hidden-import=ultralytics",
            "--collect-data=ultralytics",
            "--copy-metadata=ultralytics",
        ])

    # torch / torchvision: WidgetMain._get_torch() 에서 지연 import 됨
    if _has_package("torch"):
        extra.extend([
            "--hidden-import=torch",
            "--copy-metadata=torch",
        ])
    if _has_package("torchvision"):
        extra.extend([
            "--hidden-import=torchvision",
            "--copy-metadata=torchvision",
        ])

    # onvif-zeep (선택): 설치된 경우 WSDL 파일 포함
    if _has_package("onvif"):
        extra.extend([
            "--hidden-import=onvif",
            "--collect-data=onvif",
        ])
    if _has_package("zeep"):
        extra.append("--hidden-import=zeep")

    return extra


def build():
    """PyInstaller 빌드 프로세스를 실행합니다."""
    command = [
        '--name', APP_NAME,
        *PYINSTALLER_OPTIONS,
        *_collect_installed_package_options(),
    ]

    # 데이터 파일 추가
    for source, dest in DATA_TO_INCLUDE:
        if os.path.exists(source):
            command.extend(['--add-data', f'{source}{os.pathsep}{dest}'])
        else:
            print(f"[주의] 데이터 경로를 찾을 수 없어 건너뜁니다: {source}")

    # 메인 스크립트 추가
    command.append(MAIN_SCRIPT)

    print("=" * 60)
    print("PyInstaller 빌드를 시작합니다...")
    print(f"Python 실행 환경: {sys.executable} ({sys.version.split()[0]})")
    print(f"명령어: pyinstaller {' '.join(command)}")
    print("=" * 60)

    try:
        PyInstaller.__main__.run(command)
    except SystemExit as e:
        if e.code not in (0, None):
            print(f"\n❌ PyInstaller 빌드가 실패했습니다 (종료 코드: {e.code}).")
            return
    except Exception as e:
        print(f"\n❌ 빌드 중 오류가 발생했습니다: {e}")
        return

    dist_app_dir = os.path.join("dist", APP_NAME)
    if not os.path.exists(dist_app_dir):
        print(f"\n❌ 빌드 결과 폴더가 생성되지 않았습니다: {dist_app_dir}")
        return

    print("\n" + "=" * 60)
    print("✅ 빌드 성공!")
    print(f"실행 파일은 '{dist_app_dir}' 폴더에서 찾을 수 있습니다.")

    copy_models()
    copy_styles()
    # copy_cv2()   # 주의: Python 3.10 전용 수동 복사이므로 Python 3.11 환경에서는 사용하지 않음
    copy_json()
    ensure_runtime_dirs()
    verify_dist()
    # create_zip()

    print("=" * 60)


def copy_models():
    """
    빌드된 배포 폴더에 models 폴더를 생성하고
    모델 파일(.pt)과 설정 파일(.yaml)을 복사합니다.
    """
    src_dir = "models"
    dest_dir = os.path.join("dist", APP_NAME, "models")

    # 목적지 폴더는 항상 생성해 둔다 (빌드 후 사용자가 모델을 넣기 쉽도록)
    if not os.path.exists(dest_dir):
        os.makedirs(dest_dir, exist_ok=True)
        print(f"\n[설정] 배포 폴더 내에 '{dest_dir}' 폴더를 생성했습니다.")

    if not os.path.exists(src_dir):
        print(f"\n[주의] 프로젝트 루트에 '{src_dir}' 폴더가 없습니다. 빈 models 폴더만 생성했습니다.")
        return

    print(f"[복사] 모델 및 클래스 파일({', '.join(MODEL_EXTENSIONS)})을 복사합니다...")

    count = 0
    for file in sorted(os.listdir(src_dir)):
        src_path = os.path.join(src_dir, file)
        if os.path.isfile(src_path) and file.lower().endswith(MODEL_EXTENSIONS):
            dest_path = os.path.join(dest_dir, file)
            shutil.copy2(src_path, dest_path)
            print(f"  └─ {file}")
            count += 1

    if count == 0:
        print(f"  └─ 복사할 모델 파일({', '.join(MODEL_EXTENSIONS)})이 없습니다.")
    else:
        print(f"  └─ 총 {count}개의 모델 관련 파일 복사 완료.")


def copy_cv2():
    """
    [레거시] cv2_cv310_env 폴더의 내용을 빌드된 _internal/cv2 폴더로 복사합니다.
    주의: Python 3.10 전용 바이너리이므로 Python 3.11 이상 환경에서 실행하면 cv2 로드 오류가 발생합니다.
    """
    if sys.version_info[:2] != (3, 10):
        print(
            f"\n[경고] 현재 Python 버전은 {sys.version_info.major}.{sys.version_info.minor} 입니다. "
            f"'cv2_cv310_env'는 Python 3.10 전용이므로 복사를 건너뜁니다."
        )
        return

    src_dir = "cv2_cv310_env"
    dest_dir = os.path.join("dist", APP_NAME, "_internal", "cv2")

    if not os.path.exists(src_dir):
        print(f"\n[에러] 소스 폴더 '{src_dir}'가 없습니다. 복사를 중단합니다.")
        return

    if os.path.exists(dest_dir):
        try:
            shutil.rmtree(dest_dir)
            print(f"\n[정보] 기존 '{dest_dir}' 폴더를 삭제했습니다.")
        except Exception as e:
            print(f"\n[에러] 폴더 삭제 중 오류 발생: {e}")
            return

    try:
        shutil.copytree(src_dir, dest_dir)
        print(f"[성공] '{src_dir}'의 모든 파일과 폴더를 '{dest_dir}'로 복사 완료했습니다.")
    except Exception as e:
        print(f"\n[에러] 복사 중 오류 발생: {e}")


def create_zip():
    """빌드된 폴더를 압축하여 배포 파일을 생성합니다."""
    print(f"\n[압축] 배포용 압축 파일 생성 중...")

    base_name = os.path.join("dist", APP_NAME)
    root_dir = "dist"
    base_dir = APP_NAME

    try:
        if not os.path.exists(os.path.join(root_dir, base_dir)):
            print(f"❌ 압축 대상 폴더를 찾을 수 없습니다: {os.path.join(root_dir, base_dir)}")
            return

        archive_path = shutil.make_archive(base_name, 'zip', root_dir, base_dir)
        print(f"✅ 압축 완료: {archive_path}")
    except Exception as e:
        print(f"❌ 압축 실패: {e}")


def copy_styles():
    """
    빌드된 폴더(dist/CCTV_System/styles)에 스타일시트(.qss), SVG 아이콘, 폰트를 복사합니다.
    (QSS 내부의 `image: url(styles/*.svg)` 상대 경로가 실행 파일 위치 기준으로 해석되기 때문에 필요합니다)
    """
    src_dir = "styles"
    dest_dir = os.path.join("dist", APP_NAME, "styles")

    if not os.path.exists(src_dir):
        print(f"\n[주의] 프로젝트 루트에 '{src_dir}' 폴더가 없습니다.")
        return

    if not os.path.exists(dest_dir):
        os.makedirs(dest_dir, exist_ok=True)
        print(f"\n[설정] 배포 폴더 내에 '{dest_dir}' 폴더를 생성했습니다.")

    print(f"[복사] 스타일 (styles) 을 복사합니다...")

    count = 0
    for file in sorted(os.listdir(src_dir)):
        src_path = os.path.join(src_dir, file)
        dest_path = os.path.join(dest_dir, file)

        if os.path.isdir(src_path):
            if os.path.exists(dest_path):
                shutil.rmtree(dest_path)
            shutil.copytree(src_path, dest_path)
        else:
            shutil.copy2(src_path, dest_path)

        print(f"  └─ {file}")
        count += 1

    print(f"  └─ 총 {count}개의 스타일 항목 복사 완료.")


def copy_json():
    """설정 파일 및 보안 키 파일을 빌드된 폴더로 복사합니다."""
    files_to_copy = [
        ('app_settings.json', '앱 설정 파일'),
        ('cameras_info.json', '카메라 설정 파일'),
        ('cctv_key.bin', '보안 키 파일'),
    ]

    dest_dir = os.path.join("dist", APP_NAME)

    if not os.path.exists(dest_dir):
        print(f"\n[에러] 목적지 폴더를 찾을 수 없습니다: {dest_dir}")
        return

    print(f"\n[복사] 설정 및 보안 파일을 복사합니다...")

    success_count = 0
    for file_name, description in files_to_copy:
        if os.path.exists(file_name):
            try:
                shutil.copy2(file_name, os.path.join(dest_dir, file_name))
                print(f"  └─ {file_name} ({description}) 복사 완료")
                success_count += 1
            except Exception as e:
                print(f"  └─ ❌ {file_name} 복사 중 오류 발생: {e}")
        else:
            print(f"  └─ ⚠️ {file_name} 파일을 찾을 수 없어 건너뜁니다.")

    print(f"  └─ 총 {success_count}개의 파일 복사 완료.")


def ensure_runtime_dirs():
    """런타임에 필요한 빈 폴더(logs 등)를 배포 폴더 내에 미리 생성합니다."""
    logs_dir = os.path.join("dist", APP_NAME, "logs")
    os.makedirs(logs_dir, exist_ok=True)


def verify_dist():
    """빌드 산출물 폴더의 핵심 파일 존재 여부를 점검합니다."""
    dist_dir = os.path.join("dist", APP_NAME)
    exe_name = f"{APP_NAME}.exe" if os.name == "nt" else APP_NAME

    checks = [
        (os.path.join(dist_dir, exe_name), "실행 파일"),
        (os.path.join(dist_dir, "app_settings.json"), "앱 설정"),
        (os.path.join(dist_dir, "cameras_info.json"), "카메라 목록"),
        (os.path.join(dist_dir, "cctv_key.bin"), "암호키 파일"),
        (os.path.join(dist_dir, "styles", "dark_style.qss"), "다크 테마 QSS"),
        (os.path.join(dist_dir, "styles", "checkbox_checked.svg"), "체크박스 SVG 아이콘"),
        (os.path.join(dist_dir, "models"), "모델 폴더"),
    ]

    print("\n[점검] 배포 폴더 필수 항목 확인:")
    for path, label in checks:
        status = "OK" if os.path.exists(path) else "누락"
        mark = "✅" if status == "OK" else "⚠️"
        print(f"  └─ {mark} {label}: {path} ({status})")


if __name__ == "__main__":
    build()
