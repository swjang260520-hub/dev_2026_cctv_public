"""
core/cgi_ptz.py
Pelco-D over HTTP CGI (key.cgi) 카메라 PTZ 제어 모듈 및 QThread 워커
- 웹 HTTP CGI GET 요청 방식으로 카메라의 Pan/Tilt/Zoom/Stop 명령 처리
- 인스턴스 멤버 변수 기반 IP 캐싱 및 HTTP Session (Keep-Alive 커넥션 풀) 최적화
- PySide6 QThread 기반 워커(PelcoDCgiWorker)로 UI와 Signal/Slot 결합 해제 통신
"""

from typing import Tuple, Optional, Union
from urllib.parse import urlparse
import requests
from loguru import logger
from PySide6.QtCore import QThread, Signal


class PelcoDPTZController:
    """
    Pelco-D HTTP CGI (key.cgi) 카메라 PTZ 컨트롤러
    - 인스턴스 멤버 변수(_target_ip)에 파싱된 IP 저장으로 재연산 최소화
    - requests.Session()을 통한 HTTP Keep-Alive 커넥션 재사용으로 응답 속도 극대화
    """

    # keyvalue, cmdvalue 매핑
    COMMAND_MAP = {
        "UP": (1, 0),
        "LEFT": (3, 0),
        "RIGHT": (5, 0),
        "DOWN": (7, 0),
        "STOP": (13, 0),
        "ZOOM_IN": (8, 10),
        "ZOOM_OUT": (9, 10),
        "ZOOM_STOP": (17, 0),
    }

    def __init__(
        self,
        target: str = "",
        username: str = "",
        password: str = "",
        timeout: float = 2.5
    ):
        self.raw_target = ""
        self._target_ip = ""
        self.username = username
        self.password = password
        self.timeout = timeout

        # HTTP 커넥션 풀 및 Keep-Alive 재사용 세션 생성 (네트워크 라턴시 극소화 최적화)
        self.session = requests.Session()
        if username:
            self.session.auth = (username, password)

        if target:
            self.set_target(target, username, password)

    @property
    def target_ip(self) -> str:
        """멤버 변수 속성: 파싱 및 저장된 카메라 IP"""
        return self._target_ip

    def set_target(self, target: str, username: str = "", password: str = ""):
        """
        카메라 대상 IP/URL 및 인증 정보 업데이트 (IP 추출 결과를 멤버 변수에 저장을 통해 재연산 최적화)
        """
        self.raw_target = target
        self._target_ip = self.extract_ip(target)

        if username:
            self.username = username
            self.password = password
            self.session.auth = (username, password)
        elif self.username and not username:
            self.session.auth = (self.username, self.password)

    def extract_ip(self, target: str) -> str:
        """
        RTSP URL, HTTP 주소 또는 IP 입력값에서 순수 IP / Host만 추출하여 멤버 변수로 활용
        예: 'rtsp://admin:1234@192.168.20.116:554/live' -> '192.168.20.116'
        """
        if not target:
            return ""

        text = target.strip()
        if "://" in text:
            try:
                parsed = urlparse(text)
                if parsed.hostname:
                    return parsed.hostname
            except Exception:
                pass

        if "@" in text:
            text = text.split("@")[-1]

        if ":" in text and not text.startswith("http"):
            text = text.split(":")[0]

        if "/" in text:
            text = text.split("/")[0]

        return text.strip()

    def send_command(
        self,
        command: str,
        pts_speed: int = 83,
        zoom_speed: int = 10,
        target: Optional[str] = None
    ) -> Tuple[bool, str]:
        """
        Pelco-D HTTP CGI PTZ 명령 발송 (멤버 변수 target_ip 및 세션 재사용)

        :param command: 실행할 명령 ('UP', 'DOWN', 'LEFT', 'RIGHT', 'ZOOM_IN', 'ZOOM_OUT', 'STOP', 'ZOOM_STOP' 등)
        :param pts_speed: Pan/Tilt 이동 속도 (1 ~ 100, 기본값: 83)
        :param zoom_speed: Zoom 이동 속도 (1 ~ 100, 기본값: 10)
        :param target: 대상을 동적으로 변경할 시 지정 (미지정 시 멤버 변수 target_ip 사용)
        :return: (성공 여부 bool, 메시지 str)
        """
        cmd_upper = command.upper()
        if cmd_upper not in self.COMMAND_MAP:
            err_msg = f"지원하지 않는 Pelco-D PTZ 명령: {command}"
            logger.error(err_msg)
            return False, err_msg

        # 대상이 새로 지정되었으면 갱신 사용, 아니면 캐싱된 멤버 변수 target_ip 사용
        if target:
            ip = self.extract_ip(target)
        else:
            ip = self._target_ip

        if not ip:
            err_msg = f"유효하지 않은 카메라 IP/주소: '{target or self.raw_target}'"
            logger.error(err_msg)
            return False, err_msg

        keyvalue, cmdvalue = self.COMMAND_MAP[cmd_upper]

        url = f"http://{ip}/key.cgi"
        params = {
            "keyvalue": keyvalue,
            "cmdvalue": cmdvalue,
            "PTSpeed": int(pts_speed),
            "ZoomSpeed": int(zoom_speed),
            "preset_num": 1,
            "group_num": 1,
            "group_preset": 1,
            "group_speed": 60,
            "group_time": 10
        }

        try:
            logger.info(f"Pelco-D CGI HTTP 전송: {url} -> keyvalue={keyvalue}, cmdvalue={cmdvalue}, PTSpeed={pts_speed}, ZoomSpeed={zoom_speed}")
            response = self.session.get(url, params=params, timeout=self.timeout)
            
            if response.status_code == 200:
                msg = f"Pelco-D CGI [{cmd_upper}] 성공 (IP: {ip}, keyvalue={keyvalue})"
                logger.success(msg)
                return True, msg
            else:
                msg = f"HTTP 응답 오류 (Status Code: {response.status_code})"
                logger.warning(msg)
                return False, msg
        except requests.exceptions.Timeout:
            msg = f"카메라 HTTP 응답 타임아웃 ({ip})"
            logger.warning(msg)
            return False, msg
        except Exception as e:
            msg = f"Pelco-D CGI 통신 오류: {e}"
            logger.error(msg)
            return False, msg


class PelcoDCgiWorker(QThread):
    """
    Pelco-D HTTP CGI (key.cgi) 비동기 전송 QThread 워커
    - 컨트롤러 인스턴스 공유 지원으로 IP 파싱 및 커넥션 재사용 극대화
    """
    
    # (command_name, success, message)
    result_signal = Signal(str, bool, str)

    def __init__(
        self,
        controller_or_target: Union[PelcoDPTZController, str],
        command: str,
        pts_speed: int = 83,
        zoom_speed: int = 10,
        username: str = "",
        password: str = "",
        timeout: float = 2.5,
        parent=None
    ):
        super().__init__(parent)
        self.command = command
        self.pts_speed = pts_speed
        self.zoom_speed = zoom_speed
        self.timeout = timeout

        if isinstance(controller_or_target, PelcoDPTZController):
            self.controller = controller_or_target
        else:
            self.controller = PelcoDPTZController(
                target=controller_or_target,
                username=username,
                password=password,
                timeout=timeout
            )

    def run(self):
        """백그라운드 스레드 수행 메서드"""
        try:
            success, msg = self.controller.send_command(
                command=self.command,
                pts_speed=self.pts_speed,
                zoom_speed=self.zoom_speed
            )
            self.result_signal.emit(self.command, success, msg)
        except Exception as e:
            err_msg = f"PelcoDCgiWorker 실행 예외: {e}"
            logger.exception(err_msg)
            self.result_signal.emit(self.command, False, err_msg)
