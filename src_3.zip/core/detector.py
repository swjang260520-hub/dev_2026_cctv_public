"""
core/detector.py
YOLO 객체 탐지 비즈니스 로직 - UI 의존성 없음
"""

import time
import os
import sys
import random
from typing import Optional, List, Dict, Tuple
from abc import ABC, abstractmethod
from loguru import logger

os.environ["NO_ALBUMENTATIONS_UPDATE"] = "1"
os.environ["ALBUMENTATIONS_OFFLINE"] = "1"
os.environ["ALBUMENTATIONS_DISABLE_VERSION_CHECK"] = "1"

from .models import Detection, FrameData


class DetectorBase(ABC):
    """모든 탐지기 클래스를 위한 추상 기본 클래스"""

    def __init__(self, model_path: str, device: str):
        self.model_path = model_path
        self.device = device
        self._is_loaded = False
        self._class_names: Dict[int, str] = {}

    @abstractmethod
    def load_model(self) -> bool:
        """모델 로드"""
        raise NotImplementedError

    def detect(self, frame_data: FrameData, conf_threshold: float, iou_threshold: float, classes: Optional[List[int]]) -> FrameData:
        """단일 프레임에 대한 객체 탐지 수행 (기본 구현)"""
        if not self.is_loaded or frame_data.frame is None:
            return frame_data
        
        # 단일 프레임을 리스트에 담아 배치 처리 메서드 호출
        results = self.detect_batch([frame_data], conf_threshold, iou_threshold, classes)
        return results[0]

    @abstractmethod
    def detect_batch(self, frame_data_list: List[FrameData], conf_threshold: float, iou_threshold: float, classes: Optional[List[int]]) -> List[FrameData]:
        """배치 객체 탐지 수행"""
        raise NotImplementedError

    def _get_model_path(self) -> str:
        """PyInstaller 환경을 고려하여 모델 파일의 절대 경로를 반환합니다."""
        if getattr(sys, 'frozen', False):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

        models_dir = os.path.join(base_dir, "models")
        
        if not os.path.isabs(self.model_path):
             return os.path.join(models_dir, self.model_path)
        return self.model_path


    @property
    def is_loaded(self) -> bool: return self._is_loaded
    @property
    def class_names(self) -> Dict[int, str]: return self._class_names


class YOLODetector(DetectorBase):
    """YOLO 객체 탐지기 (ultralytics, .pt 파일용)"""
    def __init__(self, model_path: str, device: str = "auto"):
        super().__init__(model_path, device)
        self._model = None
        
    def load_model(self) -> bool:
        try:
            from ultralytics import YOLO
            model_file = self._get_model_path()
            self._model = YOLO(model_file)
            logger.info(f"YOLO 모델 로드 완료: {model_file} ({self.device})")
            if self.device != "auto": self._model.to(self.device)
            self._class_names = self._model.names
            self._is_loaded = True
            return True
        except Exception as e:
            logger.exception(f"YOLO 모델 로드 중 오류 발생: {e}")
            self._is_loaded = False
            return False
    
    def detect_batch(self, frame_data_list: List[FrameData], conf_threshold: float, iou_threshold: float, classes: Optional[List[int]]) -> List[FrameData]:
        if not self.is_loaded or self._model is None or not frame_data_list: return frame_data_list
        start_time = time.time()
        try:
            frames = [fd.frame for fd in frame_data_list]
            use_half = (self.device == 'cuda' or (self.device == 'auto' and hasattr(self._model.device, 'type') and self._model.device.type == 'cuda'))
            results_batch = self._model(frames, conf=conf_threshold, iou=iou_threshold, classes=classes, verbose=False, half=use_half)
            
            avg_inference_time_ms = ((time.time() - start_time) * 1000) / len(frame_data_list)
            for i, results in enumerate(results_batch):
                detections = self._parse_ultralytics_results([results], frame_data_list[i].frame.shape[:2])
                frame_data_list[i].detections = detections
                frame_data_list[i].inference_time_ms = avg_inference_time_ms
        except Exception as e:
            logger.exception(f"배치 탐지 오류: {e}")
        return frame_data_list

    def _parse_ultralytics_results(self, results: list, orig_shape: Tuple[int, int]) -> List[Detection]:
        detections = []
        if not results: return detections
        result = results[0]
        if result.boxes is None: return detections

        orig_h, orig_w = orig_shape
        for box in result.boxes:
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            # 좌표가 원본 이미지 경계를 벗어나지 않도록 클리핑
            x1, y1 = max(0, int(x1)), max(0, int(y1))
            x2, y2 = min(orig_w, int(x2)), min(orig_h, int(y2))

            class_id = int(box.cls)
            detections.append(Detection(
                class_id=class_id, class_name=self.class_names.get(class_id, "unknown"),
                confidence=float(box.conf), x=x1, y=y1, width=x2 - x1, height=y2 - y1
            ))
        return detections

class DummyDetector(DetectorBase):
    """테스트용 더미 탐지기"""
    def __init__(self, model_path: str = "dummy", device: str = "cpu"):
        super().__init__(model_path, device)
        self._class_names = {0: "person", 1: "car", 2: "dog"}
    
    def load_model(self) -> bool:
        self._is_loaded = True
        return True
    
    def detect_batch(self, frame_data_list: List[FrameData], **kwargs) -> List[FrameData]:
        for fd in frame_data_list: self.detect(fd, **kwargs)
        return frame_data_list

    def detect(self, frame_data: FrameData, **kwargs) -> FrameData:
        if frame_data.frame is None: return frame_data
        h, w = frame_data.frame.shape[:2]
        num_detections = random.randint(0, 3)
        detections = []
        for _ in range(num_detections):
            det_w, det_h = random.randint(50, 200), random.randint(50, 200)
            det_x, det_y = random.randint(0, max(0, w - det_w)), random.randint(0, max(0, h - det_h))
            class_id = random.choice(list(self.class_names.keys()))
            detections.append(Detection(
                class_id=class_id, class_name=self.class_names[class_id],
                confidence=random.uniform(0.5, 0.99),
                x=det_x, y=det_y, width=det_w, height=det_h
            ))
        frame_data.detections = detections
        frame_data.inference_time_ms = random.uniform(5, 25)
        return frame_data


def create_detector(model_path: str, device: str = "auto") -> DetectorBase:
    """
    모델 경로와 장치에 따라 적절한 탐지기 인스턴스를 생성하는 팩토리 함수.

    [정리] ONNX(.onnx) / TensorRT(.engine) 탐지기는 사용하지 않아 제거했다.
    현재는 ultralytics 기반 .pt 모델만 지원한다.

    :param model_path: 모델 파일 경로(.pt) 또는 "dummy"(테스트 전용)
    :param device: "auto", "cpu", "cuda" 등
    :return: DetectorBase를 상속받은 탐지기 객체
    """
    if model_path == "dummy":
        logger.info("더미 탐지기를 생성합니다. (테스트 전용)")
        return DummyDetector(model_path, device)

    file_extension = os.path.splitext(model_path)[1].lower()

    if file_extension == ".pt":
        logger.info(f"YOLO(.pt) 탐지기를 생성합니다: {model_path}")
        return YOLODetector(model_path, device)

    raise ValueError(f"지원하지 않는 모델 파일 형식입니다: {file_extension or '(확장자 없음)'}. (.pt 만 지원)")
