"""
core/models.py
순수 Python 데이터 모델 - UI 의존성 없음

[수정 이력 — 2026-10-01]
1) CameraConfig.to_dict()
   - 필드를 손으로 나열하던 것을 dataclasses.asdict() 로 교체.
     기존에는 reconnect_interval / buffer_size / disable_resize 3개 필드가
     저장되지 않아 앱을 재시작할 때마다 기본값으로 조용히 초기화되었다.
2) CameraConfig.group_name 신규 필드 (기본값 "" = 미분류)
   - 기존 cameras_info.json 과 완전 호환 (키가 없으면 "" 로 채워진다)
3) CameraConfig.get_full_url()
   - 비밀번호를 무조건 LEA 복호화하던 것을 조건부로 변경.
     빈 비밀번호 / 평문 비밀번호 / 키 파일 없음 상태에서 예외가 발생해
     RTSP 카메라가 아예 연결되지 않던 문제를 수정.
   - 비밀번호(암호문·평문)를 표준출력으로 인쇄하던 디버그 print 제거.
4) LeaUtil 인스턴스 지연 생성 (_LazyLea)
   - 기존 `lea = LeaUtil()` 은 클래스 정의 시점(임포트 시점)에 키 파일을
     읽어, 키가 없으면 key=None 상태로 고정되고 복호화 시 TypeError 가 났다.
"""

from dataclasses import dataclass, field, asdict
from typing import Optional, List, Tuple, Dict
from enum import Enum, auto
from urllib.parse import quote
import numpy as np
import time
import uuid

from loguru import logger


def mask_url(url) -> str:
    """로그용: URL 에 포함된 계정 정보(user:pass@)를 가린다. 예) rtsp://***@1.2.3.4/stream"""
    s = str(url)
    if "://" not in s:
        return s
    proto, rest = s.split("://", 1)
    authority, sep, path = rest.partition("/")
    if "@" in authority:
        # 비밀번호에 '@' 가 들어 있어도 마지막 '@' 기준으로 호스트를 분리한다
        authority = "***@" + authority.rsplit("@", 1)[1]
    return f"{proto}://{authority}{sep}{path}"

from LeaCrypto import LeaUtil


#: 그룹이 지정되지 않은 카메라를 나타내는 값 (빈 문자열)
UNGROUPED = ""


class _LazyLea:
    """
    LeaUtil 지연 생성 래퍼.

    임포트 시점에 키 파일을 읽지 않고, 처음 암/복호화를 요청할 때 생성한다.
    (키 파일이 없거나 cryptography 미설치여도 앱 자체는 실행되도록)
    """

    def __init__(self):
        self._util = None

    def _get(self) -> LeaUtil:
        if self._util is None:
            self._util = LeaUtil()
            if getattr(self._util, "key", None) is None:
                logger.warning(
                    "cctv_key.bin 을 읽지 못했습니다. "
                    "비밀번호 암/복호화가 동작하지 않습니다 (평문으로 취급)."
                )
        return self._util

    def encrypt(self, plain_text):
        return self._get().encrypt(plain_text)

    def decrypt(self, ciper_text):
        return self._get().decrypt(ciper_text)

    @property
    def key(self):
        return self._get().key


class CameraStatus(Enum):
    """카메라 상태"""
    DISCONNECTED = auto()
    CONNECTING = auto()
    ACTIVE = auto()
    ERROR = auto()
    PAUSED = auto()


@dataclass
class Detection:
    """단일 탐지 결과"""
    class_id: int
    class_name: str
    confidence: float
    x: int
    y: int
    width: int
    height: int

    @property
    def bbox_xyxy(self) -> Tuple[int, int, int, int]:
        """(x1, y1, x2, y2) 형식"""
        return (self.x, self.y, self.x + self.width, self.y + self.height)

    @property
    def bbox_xywh(self) -> Tuple[int, int, int, int]:
        """(x, y, width, height) 형식"""
        return (self.x, self.y, self.width, self.height)

    @property
    def center(self) -> Tuple[int, int]:
        """중심점"""
        return (self.x + self.width // 2, self.y + self.height // 2)


@dataclass
class FrameData:
    """프레임 + 탐지결과 묶음 (하이브리드 핵심)"""
    camera_id: str
    frame: np.ndarray
    timestamp: float = field(default_factory=time.time)
    frame_number: int = 0
    detections: List[Detection] = field(default_factory=list)
    inference_time_ms: float = 0.0
    fps: float = 0.0

    @property
    def has_detections(self) -> bool:
        return len(self.detections) > 0

    @property
    def detection_count(self) -> int:
        return len(self.detections)

    @property
    def frame_size(self) -> Tuple[int, int]:
        """(width, height)"""
        if self.frame is not None:
            return (self.frame.shape[1], self.frame.shape[0])
        return (0, 0)


@dataclass
class CameraConfig:
    """카메라 설정"""
    camera_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    name: str = "새 카메라"
    source: str = ""
    source_type: str = "rtsp"
    username: str = ""
    password: str = ""
    enabled: bool = False
    autostart: bool = False
    display_enabled: bool = True
    detection_enabled: bool = False
    recording_enabled: bool = False
    reconnect_interval: float = 5.0
    buffer_size: int = 1
    target_fps: int = 30
    disable_resize: bool = False  # False: 기본 분할 화면 모드 (640px 제한), True: 단독/최대화 화면 모드 (FHD 1920px 제한)
    # --- [신규] 그룹명. 빈 문자열("")은 "미분류"를 의미한다. ---
    group_name: str = UNGROUPED

    # [수정] LeaUtil() 직접 생성 → 지연 생성 래퍼 (임포트 시점 키 파일 의존 제거)
    lea = _LazyLea()

    # ------------------------------------------------------------------ #
    # 그룹 관련 편의 속성
    # ------------------------------------------------------------------ #
    @property
    def group_display(self) -> str:
        """UI 표시용 그룹명 (미지정이면 '미분류')"""
        return self.group_name or "미분류"

    @property
    def is_grouped(self) -> bool:
        """그룹이 지정되어 있는가"""
        return bool(self.group_name)

    # ------------------------------------------------------------------ #
    # URL / OpenCV 소스
    # ------------------------------------------------------------------ #
    def _resolve_plain_password(self) -> str:
        """
        password 필드를 RTSP URL 에 넣을 평문으로 변환한다.

        password 필드에는 두 가지 형식이 섞여 있을 수 있다.
          1) LEA(ECB, hex) 로 암호화된 문자열 — WidgetCameraDialog 가 저장한 형식
          2) 평문 — 예전 버전이 저장했거나 사람이 cameras_info.json 을 직접 편집한 경우

        [수정] 기존 코드는 username 이 있으면 무조건 decrypt() 를 호출했다.
          - 비밀번호가 빈 문자열 → ValueError: Improper data length
          - 평문 비밀번호        → binascii.Error: Odd-length string
          - cctv_key.bin 없음    → TypeError: object of type 'NoneType' has no len()
        → get_opencv_source() → CameraWorker → cv2.VideoCapture 까지 전파되어
          카메라가 영구히 '연결 실패'로 남았다. (username 이 빈 값이라 잠복해 있었음)

        복호화에 실패하면 원문을 그대로 사용한다(fail-safe).
        """
        raw = self.password
        if raw is None:
            return ""
        raw = str(raw)
        if not raw:
            return ""
        try:
            return CameraConfig.lea.decrypt(raw)
        except Exception as e:
            logger.warning(f"비밀번호 복호화 실패 → 평문으로 사용합니다: {e}")
            return raw

    def get_full_url(self) -> str:
        """인증 정보가 포함된 전체 URL 반환"""
        if self.source_type == "rtsp" and self.username:
            if "://" in self.source:
                safe_user = quote(str(self.username), safe='')
                # [수정] 복호화는 조건부/예외 안전하게, 비밀번호 출력은 제거
                password = self._resolve_plain_password()
                safe_pass = quote(str(password) if password is not None else '', safe='')

                protocol, rest = self.source.split("://", 1)
                return f"{protocol}://{safe_user}:{safe_pass}@{rest}"
        return self.source

    def get_opencv_source(self):
        """OpenCV VideoCapture에 전달할 소스 반환 (USB 카메라는 int, 나머지는 str)"""
        if self.source_type == "usb":
            if isinstance(self.source, int):
                return self.source
            source_str = str(self.source)
            return int(source_str) if source_str.isdigit() else 0
        return self.get_full_url()

    def to_dict(self) -> Dict:
        """
        딕셔너리로 변환.

        [수정] 기존에는 필드를 손으로 나열하여, 새 필드를 추가할 때마다
        to_dict() 를 함께 고치지 않으면 조용히 값이 누락되었다.
        asdict() 를 사용하면 dataclass 필드가 자동으로 전부 포함된다.

        주의: 중첩 dataclass / numpy 배열 등 JSON 직렬화가 불가능한 값을
        필드로 추가하게 되면 별도의 변환이 필요하다.
        """
        return asdict(self)

    def to_safe_dict(self) -> Dict:
        """
        비밀번호를 제거한 딕셔너리 (로그·내보내기용).

        카메라 설정을 외부로 노출해야 할 때 사용한다.
        """
        data = self.to_dict()
        if data.get("password"):
            data["password"] = "***"
        return data

    @classmethod
    def from_dict(cls, data: Dict) -> 'CameraConfig':
        """
        딕셔너리에서 생성.

        dataclass 에 정의되지 않은 키는 무시하므로,
        구버전/신버전 JSON 이 서로 호환된다.
        """
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class CameraState:
    """카메라 런타임 상태"""
    camera_id: str
    status: CameraStatus = CameraStatus.DISCONNECTED
    current_fps: float = 0.0
    frame_width: int = 0
    frame_height: int = 0
    total_frames: int = 0
    detection_count: int = 0
    last_error: str = ""
    last_frame_time: float = 0.0