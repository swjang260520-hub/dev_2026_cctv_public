import json
import os
from typing import List, Dict, Any, Optional
from loguru import logger

from core.models import CameraConfig

class SettingsManager:
    def __init__(self, app_settings_path: str = 'app_settings.json', cameras_info_path: str = 'cameras_info.json'):
        self.app_settings_path = app_settings_path
        self.cameras_info_path = cameras_info_path
        
        self.system_settings = {
            'theme': 'Light',
            'model_path': 'yolo11n.pt',
            'device': 'auto',
            'conf_threshold': 0.4,
            'iou_threshold': 0.7,
            'batch_size': 8,
            'log_highlight_duration': 1,
            'target_classes': None,
            'custom_class_names': {},
            'custom_class_colors': {},
            'subtitle': ''
        }
        
    def load_cameras_info(self) -> List[CameraConfig]:
        """cameras_info.json에서 카메라 정보를 로드합니다."""
        cameras = []
        if os.path.exists(self.cameras_info_path):
            try:
                with open(self.cameras_info_path, 'r', encoding='utf-8') as f:
                    camera_dicts = json.load(f)
                    for cam_dict in camera_dicts:
                        cameras.append(CameraConfig.from_dict(cam_dict))
            except json.JSONDecodeError:
                logger.warning(f"{self.cameras_info_path} 파일이 손상되었거나 비어 있습니다.")
            except Exception as e:
                logger.error(f"카메라 정보 로드 중 오류 발생: {e}")
        return cameras

    def save_cameras_info(self, configs: List[CameraConfig]):
        """카메라 정보를 JSON 파일로 저장합니다."""
        try:
            camera_list = [cam.to_dict() for cam in configs]
            with open(self.cameras_info_path, 'w', encoding='utf-8') as f:
                json.dump(camera_list, f, indent=4, ensure_ascii=False)
        except Exception as e:
            logger.error(f"카메라 정보 저장 실패: {e}")

    def load_app_settings(self) -> Dict[str, Any]:
        """
        앱 설정(창 크기, 레이아웃 등)을 로드합니다.

        [수정] 설정 파일이 없는 첫 실행에서도 'system_settings' 키를
        반드시 포함한 딕셔너리를 돌려줍니다.
        기존에는 {} 를 반환하여 호출부의 settings['system_settings']
        접근에서 KeyError 로 앱이 종료되었습니다.
        """
        if not os.path.exists(self.app_settings_path):
            return {'system_settings': dict(self.system_settings)}

        try:
            with open(self.app_settings_path, 'r', encoding='utf-8') as f:
                settings = json.load(f)

            if not isinstance(settings, dict):
                # 손상된 파일(리스트/문자열 등)로 인한 연쇄 오류 방지
                logger.warning(f"{self.app_settings_path} 형식이 올바르지 않습니다. 기본값을 사용합니다.")
                return {'system_settings': dict(self.system_settings)}

            # 로드한 설정으로 기본 시스템 설정 업데이트
            if 'system_settings' in settings:
                self.system_settings.update(settings['system_settings'])
            # 전체 설정을 반환하기 전에 system_settings를 최신 상태로 반영
            settings['system_settings'] = self.system_settings
            
            return settings
        except Exception as e:
            logger.error(f"앱 설정 로드 실패: {e}")
            return {'system_settings': dict(self.system_settings)}

    def save_app_settings(self, settings: Dict[str, Any]):
        """앱 설정(창 크기, 레이아웃 등)을 저장합니다."""
        try:
            # 저장하기 전에 현재 system_settings를 반영
            settings['system_settings'] = self.system_settings
            with open(self.app_settings_path, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=4)
        except Exception as e:
            logger.error(f"앱 설정 저장 실패: {e}")

    def get_setting(self, key: str, default: Any = None) -> Any:
        """특정 시스템 설정 값을 가져옵니다."""
        return self.system_settings.get(key, default)

    def update_setting(self, key: str, value: Any):
        """특정 시스템 설정 값을 업데이트합니다."""
        self.system_settings[key] = value
        
    def update_settings(self, new_settings: Dict[str, Any]):
        """여러 시스템 설정을 한 번에 업데이트합니다."""
        self.system_settings.update(new_settings)
