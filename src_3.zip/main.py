"""
멀티-CCTV 실시간 감시 시스템
"""

import sys
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt

from WidgetMain import MainWindow


def main():
    # High DPI 설정
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    
    app = QApplication(sys.argv)
    
    # 메인 윈도우 생성 및 표시
    window = MainWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()