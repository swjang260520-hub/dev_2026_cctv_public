@echo off
chcp 65001 > nul
echo ===================================================
echo PySide6 UI 및 리소스 자동 빌드 스크립트
echo ===================================================

REM 1. Conda 가상환경 활성화 (자신의 가상환경 이름으로 변경하세요)
set CONDA_ENV_NAME=py311_yolo11
echo [1/3] Conda 가상환경 '%CONDA_ENV_NAME%' 활성화 중...
call conda activate %CONDA_ENV_NAME%

REM 2. UI 파일 자동 변환 (.ui -> .py)
echo [2/3] UI 파일 변환 시작...
REM 변환된 파이썬 파일이 저장될 폴더가 없으면 생성
if not exist "src\views" mkdir "src\views"

REM ui 폴더 안의 모든 .ui 파일을 순회하며 변환
for %%f in (ui\*.ui) do (
    echo   - %%~nxf 변환 중...
    pyside6-uic "%%f" -o "src\views\ui_%%~nf.py"
)

REM 3. 리소스 파일 자동 변환 (.qrc -> .py)
echo [3/3] 리소스 파일 변환 시작...
if not exist "src\resources" mkdir "src\resources"

REM resources 폴더 안의 모든 .qrc 파일을 순회하며 변환
for %%f in (resources\*.qrc) do (
    echo   - %%~nxf 변환 중...
    pyside6-rcc "%%f" -o "src\resources\%%~nf_rc.py"
)

echo ===================================================
echo 빌드가 완료되었습니다!
echo ===================================================
pause