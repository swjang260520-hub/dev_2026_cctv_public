# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'camera_control.ui'
##
## Created by: Qt User Interface Compiler version 6.9.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QFrame, QGroupBox,
    QHBoxLayout, QLabel, QPushButton, QSizePolicy,
    QSpacerItem, QSpinBox, QVBoxLayout, QWidget)

class Ui_CameraControl(object):
    def setupUi(self, CameraControl):
        if not CameraControl.objectName():
            CameraControl.setObjectName(u"CameraControl")
        CameraControl.resize(802, 763)
        self.layout_main = QVBoxLayout(CameraControl)
        self.layout_main.setSpacing(10)
        self.layout_main.setObjectName(u"layout_main")
        self.layout_main.setContentsMargins(12, 12, 12, 12)
        self.frame_video = QFrame(CameraControl)
        self.frame_video.setObjectName(u"frame_video")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        sizePolicy.setHeightForWidth(self.frame_video.sizePolicy().hasHeightForWidth())
        self.frame_video.setSizePolicy(sizePolicy)
        self.frame_video.setFrameShape(QFrame.NoFrame)
        self.layout_video = QVBoxLayout(self.frame_video)
        self.layout_video.setObjectName(u"layout_video")
        self.layout_video.setContentsMargins(0, 0, 0, 0)
        self.lbl_video_display = QLabel(self.frame_video)
        self.lbl_video_display.setObjectName(u"lbl_video_display")
        self.lbl_video_display.setStyleSheet(u"background-color: #121212; color: #888888; font-size: 14px;")

        self.layout_video.addWidget(self.lbl_video_display)


        self.layout_main.addWidget(self.frame_video)

        self.gb_ptz_control = QGroupBox(CameraControl)
        self.gb_ptz_control.setObjectName(u"gb_ptz_control")
        self.layout_ptz_container = QHBoxLayout(self.gb_ptz_control)
        self.layout_ptz_container.setSpacing(9)
        self.layout_ptz_container.setObjectName(u"layout_ptz_container")
        self.layout_ptz_container.setContentsMargins(9, -1, -1, -1)
        self.chk_enable_detection = QCheckBox(self.gb_ptz_control)
        self.chk_enable_detection.setObjectName(u"chk_enable_detection")

        self.layout_ptz_container.addWidget(self.chk_enable_detection)

        self.layout_ptz_buttons = QHBoxLayout()
        self.layout_ptz_buttons.setSpacing(3)
        self.layout_ptz_buttons.setObjectName(u"layout_ptz_buttons")
        self.layout_ptz_buttons.setContentsMargins(-1, -1, -1, 0)
        self.btn_pan_up = QPushButton(self.gb_ptz_control)
        self.btn_pan_up.setObjectName(u"btn_pan_up")
        self.btn_pan_up.setMinimumSize(QSize(26, 0))
        self.btn_pan_up.setMaximumSize(QSize(40, 16777215))

        self.layout_ptz_buttons.addWidget(self.btn_pan_up)

        self.btn_pan_down = QPushButton(self.gb_ptz_control)
        self.btn_pan_down.setObjectName(u"btn_pan_down")
        self.btn_pan_down.setMinimumSize(QSize(26, 0))
        self.btn_pan_down.setMaximumSize(QSize(40, 16777215))

        self.layout_ptz_buttons.addWidget(self.btn_pan_down)

        self.btn_pan_left = QPushButton(self.gb_ptz_control)
        self.btn_pan_left.setObjectName(u"btn_pan_left")
        self.btn_pan_left.setMinimumSize(QSize(26, 0))
        self.btn_pan_left.setMaximumSize(QSize(40, 16777215))

        self.layout_ptz_buttons.addWidget(self.btn_pan_left)

        self.btn_pan_right = QPushButton(self.gb_ptz_control)
        self.btn_pan_right.setObjectName(u"btn_pan_right")
        self.btn_pan_right.setMinimumSize(QSize(26, 0))
        self.btn_pan_right.setMaximumSize(QSize(40, 16777215))

        self.layout_ptz_buttons.addWidget(self.btn_pan_right)

        self.btn_ptz_stop = QPushButton(self.gb_ptz_control)
        self.btn_ptz_stop.setObjectName(u"btn_ptz_stop")
        self.btn_ptz_stop.setMinimumSize(QSize(26, 0))
        self.btn_ptz_stop.setMaximumSize(QSize(60, 16777215))

        self.layout_ptz_buttons.addWidget(self.btn_ptz_stop)

        self.lbl_pt_speed = QLabel(self.gb_ptz_control)
        self.lbl_pt_speed.setObjectName(u"lbl_pt_speed")

        self.layout_ptz_buttons.addWidget(self.lbl_pt_speed)

        self.sb_pt_speed = QSpinBox(self.gb_ptz_control)
        self.sb_pt_speed.setObjectName(u"sb_pt_speed")
        self.sb_pt_speed.setMinimum(1)
        self.sb_pt_speed.setMaximum(100)
        self.sb_pt_speed.setValue(83)

        self.layout_ptz_buttons.addWidget(self.sb_pt_speed)

        self.line_ptz_sep = QFrame(self.gb_ptz_control)
        self.line_ptz_sep.setObjectName(u"line_ptz_sep")
        self.line_ptz_sep.setMaximumSize(QSize(16777215, 20))
        self.line_ptz_sep.setFrameShape(QFrame.Shape.VLine)
        self.line_ptz_sep.setFrameShadow(QFrame.Shadow.Sunken)

        self.layout_ptz_buttons.addWidget(self.line_ptz_sep)

        self.btn_zoom_in = QPushButton(self.gb_ptz_control)
        self.btn_zoom_in.setObjectName(u"btn_zoom_in")
        self.btn_zoom_in.setMaximumSize(QSize(50, 16777215))

        self.layout_ptz_buttons.addWidget(self.btn_zoom_in)

        self.btn_zoom_out = QPushButton(self.gb_ptz_control)
        self.btn_zoom_out.setObjectName(u"btn_zoom_out")
        self.btn_zoom_out.setMaximumSize(QSize(50, 16777215))

        self.layout_ptz_buttons.addWidget(self.btn_zoom_out)

        self.line_ptz_sep2 = QFrame(self.gb_ptz_control)
        self.line_ptz_sep2.setObjectName(u"line_ptz_sep2")
        self.line_ptz_sep2.setMaximumSize(QSize(16777215, 20))
        self.line_ptz_sep2.setFrameShape(QFrame.Shape.VLine)
        self.line_ptz_sep2.setFrameShadow(QFrame.Shadow.Sunken)

        self.layout_ptz_buttons.addWidget(self.line_ptz_sep2)

        self.lbl_zoom_speed = QLabel(self.gb_ptz_control)
        self.lbl_zoom_speed.setObjectName(u"lbl_zoom_speed")

        self.layout_ptz_buttons.addWidget(self.lbl_zoom_speed)

        self.sb_zoom_speed = QSpinBox(self.gb_ptz_control)
        self.sb_zoom_speed.setObjectName(u"sb_zoom_speed")
        self.sb_zoom_speed.setMinimum(1)
        self.sb_zoom_speed.setMaximum(100)
        self.sb_zoom_speed.setValue(10)

        self.layout_ptz_buttons.addWidget(self.sb_zoom_speed)


        self.layout_ptz_container.addLayout(self.layout_ptz_buttons)

        self.spacer_ptz = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.layout_ptz_container.addItem(self.spacer_ptz)

        self.layout_status_info = QVBoxLayout()
        self.layout_status_info.setObjectName(u"layout_status_info")
        self.lbl_ptz_status = QLabel(self.gb_ptz_control)
        self.lbl_ptz_status.setObjectName(u"lbl_ptz_status")

        self.layout_status_info.addWidget(self.lbl_ptz_status)


        self.layout_ptz_container.addLayout(self.layout_status_info)


        self.layout_main.addWidget(self.gb_ptz_control)


        self.retranslateUi(CameraControl)

        QMetaObject.connectSlotsByName(CameraControl)
    # setupUi

    def retranslateUi(self, CameraControl):
        CameraControl.setWindowTitle(QCoreApplication.translate("CameraControl", u"RTSP & ONVIF PTZ \uce74\uba54\ub77c \uc81c\uc5b4\uae30 (\ub3c5\ub9bd\ud615)", None))
        self.lbl_video_display.setText(QCoreApplication.translate("CameraControl", u"RTSP \uc2a4\ud2b8\ub9bc \ubbf8\uc5f0\uacb0 (\uc5f0\uacb0 \ubc84\ud2bc\uc744 \ub20c\ub7ec\uc8fc\uc138\uc694)", None))
        self.gb_ptz_control.setTitle(QCoreApplication.translate("CameraControl", u"\uce74\uba54\ub77c \uc81c\uc5b4", None))
        self.chk_enable_detection.setText(QCoreApplication.translate("CameraControl", u"\uac1d\uccb4\ud0d0\uc9c0", None))
#if QT_CONFIG(tooltip)
        self.btn_pan_up.setToolTip(QCoreApplication.translate("CameraControl", u"\uc0c1 (Tilt Up)", None))
#endif // QT_CONFIG(tooltip)
        self.btn_pan_up.setText("")
#if QT_CONFIG(tooltip)
        self.btn_pan_down.setToolTip(QCoreApplication.translate("CameraControl", u"\ud558 (Tilt Down)", None))
#endif // QT_CONFIG(tooltip)
        self.btn_pan_down.setText("")
#if QT_CONFIG(tooltip)
        self.btn_pan_left.setToolTip(QCoreApplication.translate("CameraControl", u"\uc88c (Pan Left)", None))
#endif // QT_CONFIG(tooltip)
        self.btn_pan_left.setText("")
#if QT_CONFIG(tooltip)
        self.btn_pan_right.setToolTip(QCoreApplication.translate("CameraControl", u"\uc6b0 (Pan Right)", None))
#endif // QT_CONFIG(tooltip)
        self.btn_pan_right.setText("")
#if QT_CONFIG(tooltip)
        self.btn_ptz_stop.setToolTip(QCoreApplication.translate("CameraControl", u"\uc815\uc9c0 (Stop)", None))
#endif // QT_CONFIG(tooltip)
        self.btn_ptz_stop.setText("")
        self.lbl_pt_speed.setText(QCoreApplication.translate("CameraControl", u"PTSpeed:", None))
#if QT_CONFIG(tooltip)
        self.sb_pt_speed.setToolTip(QCoreApplication.translate("CameraControl", u"Pan/Tilt \uc774\ub3d9 \uc18d\ub3c4 (PTSpeed: 1 ~ 100)", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        self.btn_zoom_in.setToolTip(QCoreApplication.translate("CameraControl", u"\uc90c \uc778 (Zoom In)", None))
#endif // QT_CONFIG(tooltip)
        self.btn_zoom_in.setText("")
#if QT_CONFIG(tooltip)
        self.btn_zoom_out.setToolTip(QCoreApplication.translate("CameraControl", u"\uc90c \uc544\uc6c3 (Zoom Out)", None))
#endif // QT_CONFIG(tooltip)
        self.btn_zoom_out.setText("")
        self.lbl_zoom_speed.setText(QCoreApplication.translate("CameraControl", u"ZoomSpeed:", None))
#if QT_CONFIG(tooltip)
        self.sb_zoom_speed.setToolTip(QCoreApplication.translate("CameraControl", u"Zoom \uc774\ub3d9 \uc18d\ub3c4 (ZoomSpeed: 1 ~ 100)", None))
#endif // QT_CONFIG(tooltip)
        self.lbl_ptz_status.setText(QCoreApplication.translate("CameraControl", u"PTZ \uc0c1\ud0dc: \ub300\uae30 \uc911", None))
    # retranslateUi

