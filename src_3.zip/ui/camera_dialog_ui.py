# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'camera_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.9.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QCheckBox, QComboBox,
    QDialog, QDialogButtonBox, QFormLayout, QGroupBox,
    QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QSizePolicy, QSpacerItem, QVBoxLayout, QWidget)

class Ui_CameraDialog(object):
    def setupUi(self, CameraDialog):
        if not CameraDialog.objectName():
            CameraDialog.setObjectName(u"CameraDialog")
        CameraDialog.resize(450, 397)
        CameraDialog.setMinimumSize(QSize(450, 0))
        CameraDialog.setModal(True)
        self.mainLayout = QVBoxLayout(CameraDialog)
        self.mainLayout.setSpacing(15)
        self.mainLayout.setObjectName(u"mainLayout")
        self.mainLayout.setContentsMargins(20, 20, 20, 20)
        self.groupCameraInfo = QGroupBox(CameraDialog)
        self.groupCameraInfo.setObjectName(u"groupCameraInfo")
        self.formLayout = QFormLayout(self.groupCameraInfo)
        self.formLayout.setObjectName(u"formLayout")
        self.formLayout.setLabelAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.formLayout.setHorizontalSpacing(12)
        self.formLayout.setVerticalSpacing(12)
        self.formLayout.setContentsMargins(12, 16, 12, 12)
        self.labelName = QLabel(self.groupCameraInfo)
        self.labelName.setObjectName(u"labelName")

        self.formLayout.setWidget(0, QFormLayout.ItemRole.LabelRole, self.labelName)

        self.name_edit = QLineEdit(self.groupCameraInfo)
        self.name_edit.setObjectName(u"name_edit")

        self.formLayout.setWidget(0, QFormLayout.ItemRole.FieldRole, self.name_edit)

        self.labelType = QLabel(self.groupCameraInfo)
        self.labelType.setObjectName(u"labelType")

        self.formLayout.setWidget(1, QFormLayout.ItemRole.LabelRole, self.labelType)

        self.type_combo = QComboBox(self.groupCameraInfo)
        self.type_combo.addItem("")
        self.type_combo.addItem("")
        self.type_combo.addItem("")
        self.type_combo.addItem("")
        self.type_combo.setObjectName(u"type_combo")

        self.formLayout.setWidget(1, QFormLayout.ItemRole.FieldRole, self.type_combo)

        self.labelAddress = QLabel(self.groupCameraInfo)
        self.labelAddress.setObjectName(u"labelAddress")

        self.formLayout.setWidget(2, QFormLayout.ItemRole.LabelRole, self.labelAddress)

        self.addressLayout = QHBoxLayout()
        self.addressLayout.setSpacing(6)
        self.addressLayout.setObjectName(u"addressLayout")
        self.address_edit = QLineEdit(self.groupCameraInfo)
        self.address_edit.setObjectName(u"address_edit")

        self.addressLayout.addWidget(self.address_edit)

        self.browse_btn = QPushButton(self.groupCameraInfo)
        self.browse_btn.setObjectName(u"browse_btn")
        self.browse_btn.setMinimumSize(QSize(40, 0))
        self.browse_btn.setMaximumSize(QSize(40, 16777215))

        self.addressLayout.addWidget(self.browse_btn)


        self.formLayout.setLayout(2, QFormLayout.ItemRole.FieldRole, self.addressLayout)

        self.labelUsername = QLabel(self.groupCameraInfo)
        self.labelUsername.setObjectName(u"labelUsername")

        self.formLayout.setWidget(3, QFormLayout.ItemRole.LabelRole, self.labelUsername)

        self.username_edit = QLineEdit(self.groupCameraInfo)
        self.username_edit.setObjectName(u"username_edit")

        self.formLayout.setWidget(3, QFormLayout.ItemRole.FieldRole, self.username_edit)

        self.labelPassword = QLabel(self.groupCameraInfo)
        self.labelPassword.setObjectName(u"labelPassword")

        self.formLayout.setWidget(4, QFormLayout.ItemRole.LabelRole, self.labelPassword)

        self.password_edit = QLineEdit(self.groupCameraInfo)
        self.password_edit.setObjectName(u"password_edit")
        self.password_edit.setEchoMode(QLineEdit.Password)

        self.formLayout.setWidget(4, QFormLayout.ItemRole.FieldRole, self.password_edit)


        self.mainLayout.addWidget(self.groupCameraInfo)

        self.groupOptions = QGroupBox(CameraDialog)
        self.groupOptions.setObjectName(u"groupOptions")
        self.optionsLayout = QHBoxLayout(self.groupOptions)
        self.optionsLayout.setObjectName(u"optionsLayout")
        self.optionsLayout.setContentsMargins(12, 16, 12, 12)
        self.display_check = QCheckBox(self.groupOptions)
        self.display_check.setObjectName(u"display_check")
        self.display_check.setChecked(True)

        self.optionsLayout.addWidget(self.display_check)

        self.detection_check = QCheckBox(self.groupOptions)
        self.detection_check.setObjectName(u"detection_check")

        self.optionsLayout.addWidget(self.detection_check)


        self.mainLayout.addWidget(self.groupOptions)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.test_btn = QPushButton(CameraDialog)
        self.test_btn.setObjectName(u"test_btn")
        self.test_btn.setMinimumSize(QSize(0, 0))

        self.horizontalLayout.addWidget(self.test_btn)

        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer_2)


        self.mainLayout.addLayout(self.horizontalLayout)

        self.buttonBox = QDialogButtonBox(CameraDialog)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setOrientation(Qt.Horizontal)
        self.buttonBox.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.mainLayout.addWidget(self.buttonBox)


        self.retranslateUi(CameraDialog)
        self.buttonBox.accepted.connect(CameraDialog.accept)
        self.buttonBox.rejected.connect(CameraDialog.reject)

        QMetaObject.connectSlotsByName(CameraDialog)
    # setupUi

    def retranslateUi(self, CameraDialog):
        CameraDialog.setWindowTitle(QCoreApplication.translate("CameraDialog", u"\uce74\uba54\ub77c \ucd94\uac00", None))
        self.groupCameraInfo.setTitle(QCoreApplication.translate("CameraDialog", u"\uce74\uba54\ub77c \uc815\ubcf4", None))
        self.labelName.setText(QCoreApplication.translate("CameraDialog", u"\uce74\uba54\ub77c\uba85:", None))
        self.name_edit.setPlaceholderText(QCoreApplication.translate("CameraDialog", u"\uc608: \ud604\uad00 \uce74\uba54\ub77c", None))
        self.labelType.setText(QCoreApplication.translate("CameraDialog", u"\uc5f0\uacb0 \uc720\ud615:", None))
        self.type_combo.setItemText(0, QCoreApplication.translate("CameraDialog", u"RTSP", None))
        self.type_combo.setItemText(1, QCoreApplication.translate("CameraDialog", u"HTTP", None))
        self.type_combo.setItemText(2, QCoreApplication.translate("CameraDialog", u"USB \uce74\uba54\ub77c", None))
        self.type_combo.setItemText(3, QCoreApplication.translate("CameraDialog", u"\ud30c\uc77c", None))

        self.labelAddress.setText(QCoreApplication.translate("CameraDialog", u"\uc8fc\uc18c/\uacbd\ub85c:", None))
        self.address_edit.setPlaceholderText(QCoreApplication.translate("CameraDialog", u"rtsp://192.168.1.100:554/stream", None))
        self.browse_btn.setText(QCoreApplication.translate("CameraDialog", u"...", None))
        self.labelUsername.setText(QCoreApplication.translate("CameraDialog", u"\uc0ac\uc6a9\uc790\uba85:", None))
        self.username_edit.setPlaceholderText(QCoreApplication.translate("CameraDialog", u"\uc120\ud0dd\uc0ac\ud56d", None))
        self.labelPassword.setText(QCoreApplication.translate("CameraDialog", u"\ube44\ubc00\ubc88\ud638:", None))
        self.password_edit.setPlaceholderText(QCoreApplication.translate("CameraDialog", u"\uc120\ud0dd\uc0ac\ud56d", None))
        self.groupOptions.setTitle(QCoreApplication.translate("CameraDialog", u"\uc635\uc158", None))
        self.display_check.setText(QCoreApplication.translate("CameraDialog", u"\uc601\uc0c1 \ud45c\uc2dc", None))
        self.detection_check.setText(QCoreApplication.translate("CameraDialog", u"\uac1d\uccb4 \ud0d0\uc9c0", None))
        self.test_btn.setText(QCoreApplication.translate("CameraDialog", u"\uc5f0\uacb0 \ud14c\uc2a4\ud2b8", None))
    # retranslateUi

