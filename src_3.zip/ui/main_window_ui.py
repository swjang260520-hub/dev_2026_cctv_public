# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_window.ui'
##
## Created by: Qt User Interface Compiler version 6.9.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QComboBox, QFrame,
    QGridLayout, QGroupBox, QHBoxLayout, QHeaderView,
    QLabel, QMainWindow, QPushButton, QScrollArea,
    QSizePolicy, QSpacerItem, QSplitter, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1194, 866)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.horizontalLayout_3 = QHBoxLayout(self.centralwidget)
        self.horizontalLayout_3.setSpacing(9)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(6, 6, 6, 6)
        self.splitter = QSplitter(self.centralwidget)
        self.splitter.setObjectName(u"splitter")
        self.splitter.setFrameShape(QFrame.NoFrame)
        self.splitter.setOrientation(Qt.Horizontal)
        self.widget_left = QWidget(self.splitter)
        self.widget_left.setObjectName(u"widget_left")
        self.widget_left.setMaximumSize(QSize(420, 16777215))
        self.verticalLayout = QVBoxLayout(self.widget_left)
        self.verticalLayout.setSpacing(9)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(2, 2, 3, 3)
        self.groupBox_control = QGroupBox(self.widget_left)
        self.groupBox_control.setObjectName(u"groupBox_control")
        self.gridLayout_control = QGridLayout(self.groupBox_control)
        self.gridLayout_control.setObjectName(u"gridLayout_control")
        self.label_3 = QLabel(self.groupBox_control)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.gridLayout_control.addWidget(self.label_3, 0, 0, 1, 1)

        self.start_btn = QPushButton(self.groupBox_control)
        self.start_btn.setObjectName(u"start_btn")

        self.gridLayout_control.addWidget(self.start_btn, 0, 1, 1, 1)

        self.stop_btn = QPushButton(self.groupBox_control)
        self.stop_btn.setObjectName(u"stop_btn")

        self.gridLayout_control.addWidget(self.stop_btn, 0, 2, 1, 1)

        self.label_2 = QLabel(self.groupBox_control)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.gridLayout_control.addWidget(self.label_2, 1, 0, 1, 1)

        self.horizontalLayout_9 = QHBoxLayout()
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.grid_combo = QComboBox(self.groupBox_control)
        self.grid_combo.addItem("")
        self.grid_combo.addItem("")
        self.grid_combo.addItem("")
        self.grid_combo.addItem("")
        self.grid_combo.addItem("")
        self.grid_combo.addItem("")
        self.grid_combo.setObjectName(u"grid_combo")

        self.horizontalLayout_9.addWidget(self.grid_combo)


        self.gridLayout_control.addLayout(self.horizontalLayout_9, 1, 1, 1, 2)


        self.verticalLayout.addWidget(self.groupBox_control)

        self.groupBox_status = QGroupBox(self.widget_left)
        self.groupBox_status.setObjectName(u"groupBox_status")
        self.gridLayout_status = QGridLayout(self.groupBox_status)
        self.gridLayout_status.setObjectName(u"gridLayout_status")
        self.gridLayout_status.setHorizontalSpacing(3)
        self.gridLayout_status.setVerticalSpacing(12)
        self.gridLayout_status.setContentsMargins(30, -1, 30, -1)
        self.total_count_label = QLabel(self.groupBox_status)
        self.total_count_label.setObjectName(u"total_count_label")
        font = QFont()
        font.setPointSize(12)
        self.total_count_label.setFont(font)
        self.total_count_label.setAlignment(Qt.AlignCenter)

        self.gridLayout_status.addWidget(self.total_count_label, 0, 0, 1, 1)

        self.label = QLabel(self.groupBox_status)
        self.label.setObjectName(u"label")
        self.label.setAlignment(Qt.AlignCenter)

        self.gridLayout_status.addWidget(self.label, 1, 0, 1, 1)

        self.active_count_label = QLabel(self.groupBox_status)
        self.active_count_label.setObjectName(u"active_count_label")
        self.active_count_label.setFont(font)
        self.active_count_label.setAlignment(Qt.AlignCenter)

        self.gridLayout_status.addWidget(self.active_count_label, 0, 1, 1, 1)

        self.label_4 = QLabel(self.groupBox_status)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setAlignment(Qt.AlignCenter)

        self.gridLayout_status.addWidget(self.label_4, 1, 1, 1, 1)

        self.disable_count_label = QLabel(self.groupBox_status)
        self.disable_count_label.setObjectName(u"disable_count_label")
        self.disable_count_label.setFont(font)
        self.disable_count_label.setAlignment(Qt.AlignCenter)

        self.gridLayout_status.addWidget(self.disable_count_label, 0, 2, 1, 1)

        self.label_5 = QLabel(self.groupBox_status)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setAlignment(Qt.AlignCenter)

        self.gridLayout_status.addWidget(self.label_5, 1, 2, 1, 1)


        self.verticalLayout.addWidget(self.groupBox_status)

        self.splitter_2 = QSplitter(self.widget_left)
        self.splitter_2.setObjectName(u"splitter_2")
        self.splitter_2.setOrientation(Qt.Vertical)
        self.splitter_2.setChildrenCollapsible(False)
        self.groupBox_list = QGroupBox(self.splitter_2)
        self.groupBox_list.setObjectName(u"groupBox_list")
        self.verticalLayout_4 = QVBoxLayout(self.groupBox_list)
        self.verticalLayout_4.setSpacing(6)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(-1, -1, -1, 9)
        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalSpacer_4 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_4)

        self.add_btn = QPushButton(self.groupBox_list)
        self.add_btn.setObjectName(u"add_btn")

        self.horizontalLayout_4.addWidget(self.add_btn)

        self.edit_btn = QPushButton(self.groupBox_list)
        self.edit_btn.setObjectName(u"edit_btn")

        self.horizontalLayout_4.addWidget(self.edit_btn)

        self.delete_btn = QPushButton(self.groupBox_list)
        self.delete_btn.setObjectName(u"delete_btn")

        self.horizontalLayout_4.addWidget(self.delete_btn)


        self.verticalLayout_4.addLayout(self.horizontalLayout_4)

        self.camera_table = QTableWidget(self.groupBox_list)
        if (self.camera_table.columnCount() < 5):
            self.camera_table.setColumnCount(5)
        __qtablewidgetitem = QTableWidgetItem()
        self.camera_table.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.camera_table.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.camera_table.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.camera_table.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.camera_table.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        self.camera_table.setObjectName(u"camera_table")
        self.camera_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.camera_table.setSelectionMode(QAbstractItemView.NoSelection)
        self.camera_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.camera_table.horizontalHeader().setMinimumSectionSize(30)
        self.camera_table.verticalHeader().setDefaultSectionSize(28)

        self.verticalLayout_4.addWidget(self.camera_table)

        self.splitter_2.addWidget(self.groupBox_list)
        self.groupBox_event = QGroupBox(self.splitter_2)
        self.groupBox_event.setObjectName(u"groupBox_event")
        self.verticalLayout_6 = QVBoxLayout(self.groupBox_event)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(-1, 9, -1, 9)
        self.tableWidget_event = QTableWidget(self.groupBox_event)
        if (self.tableWidget_event.columnCount() < 2):
            self.tableWidget_event.setColumnCount(2)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.tableWidget_event.setHorizontalHeaderItem(0, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.tableWidget_event.setHorizontalHeaderItem(1, __qtablewidgetitem6)
        self.tableWidget_event.setObjectName(u"tableWidget_event")
        self.tableWidget_event.setSelectionMode(QAbstractItemView.NoSelection)
        self.tableWidget_event.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableWidget_event.horizontalHeader().setMinimumSectionSize(30)
        self.tableWidget_event.verticalHeader().setDefaultSectionSize(26)

        self.verticalLayout_6.addWidget(self.tableWidget_event)

        self.splitter_2.addWidget(self.groupBox_event)

        self.verticalLayout.addWidget(self.splitter_2)

        self.splitter.addWidget(self.widget_left)
        self.right_widget = QWidget(self.splitter)
        self.right_widget.setObjectName(u"right_widget")
        self.rightLayout = QVBoxLayout(self.right_widget)
        self.rightLayout.setSpacing(6)
        self.rightLayout.setObjectName(u"rightLayout")
        self.rightLayout.setContentsMargins(3, 3, 3, 0)
        self.frame_top = QFrame(self.right_widget)
        self.frame_top.setObjectName(u"frame_top")
        self.verticalLayout_5 = QVBoxLayout(self.frame_top)
        self.verticalLayout_5.setSpacing(0)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(3, 0, 0, 0)
        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setSpacing(6)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.pushButton_toggle = QPushButton(self.frame_top)
        self.pushButton_toggle.setObjectName(u"pushButton_toggle")
        self.pushButton_toggle.setMinimumSize(QSize(0, 0))
        self.pushButton_toggle.setMaximumSize(QSize(28, 16777215))
        self.pushButton_toggle.setCheckable(True)

        self.horizontalLayout_5.addWidget(self.pushButton_toggle)

        self.label_title = QLabel(self.frame_top)
        self.label_title.setObjectName(u"label_title")

        self.horizontalLayout_5.addWidget(self.label_title)

        self.label_subtitle = QLabel(self.frame_top)
        self.label_subtitle.setObjectName(u"label_subtitle")

        self.horizontalLayout_5.addWidget(self.label_subtitle)

        self.horizontalSpacer_5 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_5.addItem(self.horizontalSpacer_5)

        self.labelDateTime = QLabel(self.frame_top)
        self.labelDateTime.setObjectName(u"labelDateTime")

        self.horizontalLayout_5.addWidget(self.labelDateTime)

        self.settings_btn = QPushButton(self.frame_top)
        self.settings_btn.setObjectName(u"settings_btn")
        self.settings_btn.setMaximumSize(QSize(28, 16777215))
        self.settings_btn.setStyleSheet(u"border : 0px;")

        self.horizontalLayout_5.addWidget(self.settings_btn)


        self.verticalLayout_5.addLayout(self.horizontalLayout_5)


        self.rightLayout.addWidget(self.frame_top)

        self.scrollArea = QScrollArea(self.right_widget)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setStyleSheet(u"border : 0px;")
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 821, 819))
        self.verticalLayout_3 = QVBoxLayout(self.scrollAreaWidgetContents)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.grid_layout = QGridLayout()
        self.grid_layout.setSpacing(6)
        self.grid_layout.setObjectName(u"grid_layout")
        self.grid_layout.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout_3.addLayout(self.grid_layout)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)

        self.rightLayout.addWidget(self.scrollArea)

        self.splitter.addWidget(self.right_widget)

        self.horizontalLayout_3.addWidget(self.splitter)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"\uc9c0\ub2a5\ud615 CCTV \uac1d\uccb4 \ud0d0\uc9c0 \uccb4\uacc4", None))
        self.groupBox_control.setTitle(QCoreApplication.translate("MainWindow", u"\uc124\uc815", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"\uc601\uc0c1 \uc7ac\uc0dd :", None))
        self.start_btn.setText(QCoreApplication.translate("MainWindow", u"\uc804\uccb4 \uc2dc\uc791", None))
        self.stop_btn.setText(QCoreApplication.translate("MainWindow", u"\uc804\uccb4 \uc815\uc9c0", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"\ubdf0 \ub808\uc774\uc544\uc6c3 :", None))
        self.grid_combo.setItemText(0, QCoreApplication.translate("MainWindow", u"\uc790\ub3d9", None))
        self.grid_combo.setItemText(1, QCoreApplication.translate("MainWindow", u"1x1", None))
        self.grid_combo.setItemText(2, QCoreApplication.translate("MainWindow", u"2x2", None))
        self.grid_combo.setItemText(3, QCoreApplication.translate("MainWindow", u"3x3", None))
        self.grid_combo.setItemText(4, QCoreApplication.translate("MainWindow", u"4x4", None))
        self.grid_combo.setItemText(5, QCoreApplication.translate("MainWindow", u"5x5", None))

        self.groupBox_status.setTitle(QCoreApplication.translate("MainWindow", u"\uc2dc\uc2a4\ud15c \ud604\ud669", None))
        self.total_count_label.setText(QCoreApplication.translate("MainWindow", u"10", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Total", None))
        self.active_count_label.setText(QCoreApplication.translate("MainWindow", u"8", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"Active", None))
        self.disable_count_label.setText(QCoreApplication.translate("MainWindow", u"2", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"Disable", None))
        self.groupBox_list.setTitle(QCoreApplication.translate("MainWindow", u"\uce74\uba54\ub77c \ubaa9\ub85d", None))
        self.add_btn.setText(QCoreApplication.translate("MainWindow", u"\ucd94\uac00", None))
        self.edit_btn.setText(QCoreApplication.translate("MainWindow", u"\uc218\uc815", None))
        self.delete_btn.setText(QCoreApplication.translate("MainWindow", u"\uc0ad\uc81c", None))
        ___qtablewidgetitem = self.camera_table.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"\uc0c1\ud0dc", None));
        ___qtablewidgetitem1 = self.camera_table.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"\uce74\uba54\ub77c\uba85", None));
        ___qtablewidgetitem2 = self.camera_table.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", u"\uc601\uc0c1\ud45c\uc2dc", None));
        ___qtablewidgetitem3 = self.camera_table.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("MainWindow", u"\uac1d\uccb4\ud0d0\uc9c0", None));
        ___qtablewidgetitem4 = self.camera_table.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("MainWindow", u"\uc8fc\uc18c", None));
        self.groupBox_event.setTitle(QCoreApplication.translate("MainWindow", u"\uc774\ubca4\ud2b8 \ub85c\uadf8", None))
        ___qtablewidgetitem5 = self.tableWidget_event.horizontalHeaderItem(0)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("MainWindow", u"\uc77c\uc2dc", None));
        ___qtablewidgetitem6 = self.tableWidget_event.horizontalHeaderItem(1)
        ___qtablewidgetitem6.setText(QCoreApplication.translate("MainWindow", u"\ub0b4\uc6a9", None));
        self.pushButton_toggle.setText("")
        self.label_title.setText(QCoreApplication.translate("MainWindow", u"\uc9c0\ub2a5\ud615 CCTV \uac1d\uccb4 \ud0d0\uc9c0\uccb4\uacc4", None))
        self.label_subtitle.setText(QCoreApplication.translate("MainWindow", u"\ub2f9\uc9c1\uc2e4", None))
        self.labelDateTime.setText(QCoreApplication.translate("MainWindow", u"2026-01-19 11:10:23", None))
        self.settings_btn.setText("")
    # retranslateUi

