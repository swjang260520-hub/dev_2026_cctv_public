# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'setting_db.ui'
##
## Created by: Qt User Interface Compiler version 6.9.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QGroupBox, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QSizePolicy,
    QTabWidget, QTextEdit, QVBoxLayout, QWidget)

class Ui_Form_Db(object):
    def setupUi(self, Form_Db):
        if not Form_Db.objectName():
            Form_Db.setObjectName(u"Form_Db")
        Form_Db.resize(500, 400)
        self.verticalLayout_5 = QVBoxLayout(Form_Db)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.label_5 = QLabel(Form_Db)
        self.label_5.setObjectName(u"label_5")
        font = QFont()
        font.setPointSize(12)
        font.setBold(True)
        self.label_5.setFont(font)

        self.verticalLayout_5.addWidget(self.label_5)

        self.tabWidget = QTabWidget(Form_Db)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.verticalLayout_4 = QVBoxLayout(self.tab)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.groupBox = QGroupBox(self.tab)
        self.groupBox.setObjectName(u"groupBox")
        self.verticalLayout_2 = QVBoxLayout(self.groupBox)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.label = QLabel(self.groupBox)
        self.label.setObjectName(u"label")

        self.horizontalLayout.addWidget(self.label)

        self.pushButton_createkey = QPushButton(self.groupBox)
        self.pushButton_createkey.setObjectName(u"pushButton_createkey")
        self.pushButton_createkey.setMaximumSize(QSize(130, 16777215))

        self.horizontalLayout.addWidget(self.pushButton_createkey)


        self.verticalLayout_2.addLayout(self.horizontalLayout)

        self.lineEdit_result = QLineEdit(self.groupBox)
        self.lineEdit_result.setObjectName(u"lineEdit_result")

        self.verticalLayout_2.addWidget(self.lineEdit_result)

        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.label_createkeymsg = QLabel(self.groupBox)
        self.label_createkeymsg.setObjectName(u"label_createkeymsg")

        self.horizontalLayout_5.addWidget(self.label_createkeymsg)

        self.pushButton_keysave = QPushButton(self.groupBox)
        self.pushButton_keysave.setObjectName(u"pushButton_keysave")
        self.pushButton_keysave.setMaximumSize(QSize(130, 16777215))

        self.horizontalLayout_5.addWidget(self.pushButton_keysave)


        self.verticalLayout_2.addLayout(self.horizontalLayout_5)

        self.horizontalLayout_8 = QHBoxLayout()
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.label_createkeymsg_2 = QLabel(self.groupBox)
        self.label_createkeymsg_2.setObjectName(u"label_createkeymsg_2")

        self.horizontalLayout_8.addWidget(self.label_createkeymsg_2)

        self.pushButton_keysave_2 = QPushButton(self.groupBox)
        self.pushButton_keysave_2.setObjectName(u"pushButton_keysave_2")
        self.pushButton_keysave_2.setMaximumSize(QSize(130, 16777215))

        self.horizontalLayout_8.addWidget(self.pushButton_keysave_2)


        self.verticalLayout_2.addLayout(self.horizontalLayout_8)


        self.verticalLayout_4.addWidget(self.groupBox)

        self.groupBox_2 = QGroupBox(self.tab)
        self.groupBox_2.setObjectName(u"groupBox_2")
        self.verticalLayout_3 = QVBoxLayout(self.groupBox_2)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.label_4 = QLabel(self.groupBox_2)
        self.label_4.setObjectName(u"label_4")

        self.horizontalLayout_4.addWidget(self.label_4)

        self.checkBox_pwlook = QCheckBox(self.groupBox_2)
        self.checkBox_pwlook.setObjectName(u"checkBox_pwlook")
        font1 = QFont()
        font1.setPointSize(7)
        self.checkBox_pwlook.setFont(font1)
        self.checkBox_pwlook.setChecked(True)

        self.horizontalLayout_4.addWidget(self.checkBox_pwlook)

        self.lineEdit_passwd = QLineEdit(self.groupBox_2)
        self.lineEdit_passwd.setObjectName(u"lineEdit_passwd")
        self.lineEdit_passwd.setMaximumSize(QSize(130, 16777215))
        self.lineEdit_passwd.setEchoMode(QLineEdit.Normal)

        self.horizontalLayout_4.addWidget(self.lineEdit_passwd)


        self.verticalLayout_3.addLayout(self.horizontalLayout_4)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.label_2 = QLabel(self.groupBox_2)
        self.label_2.setObjectName(u"label_2")

        self.horizontalLayout_2.addWidget(self.label_2)

        self.pushButton_cryptosave = QPushButton(self.groupBox_2)
        self.pushButton_cryptosave.setObjectName(u"pushButton_cryptosave")
        self.pushButton_cryptosave.setMaximumSize(QSize(130, 16777215))

        self.horizontalLayout_2.addWidget(self.pushButton_cryptosave)


        self.verticalLayout_3.addLayout(self.horizontalLayout_2)


        self.verticalLayout_4.addWidget(self.groupBox_2)

        self.groupBox_3 = QGroupBox(self.tab)
        self.groupBox_3.setObjectName(u"groupBox_3")
        self.verticalLayout = QVBoxLayout(self.groupBox_3)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.label_3 = QLabel(self.groupBox_3)
        self.label_3.setObjectName(u"label_3")

        self.horizontalLayout_3.addWidget(self.label_3)

        self.pushButton_validpass = QPushButton(self.groupBox_3)
        self.pushButton_validpass.setObjectName(u"pushButton_validpass")
        self.pushButton_validpass.setMaximumSize(QSize(130, 16777215))

        self.horizontalLayout_3.addWidget(self.pushButton_validpass)


        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.label_validpass = QLabel(self.groupBox_3)
        self.label_validpass.setObjectName(u"label_validpass")

        self.verticalLayout.addWidget(self.label_validpass)


        self.verticalLayout_4.addWidget(self.groupBox_3)

        self.tabWidget.addTab(self.tab, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.verticalLayout_6 = QVBoxLayout(self.tab_2)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.horizontalLayout_7 = QHBoxLayout()
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.label_7 = QLabel(self.tab_2)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setMinimumSize(QSize(55, 0))

        self.horizontalLayout_7.addWidget(self.label_7)

        self.lineEdit_db_name = QLineEdit(self.tab_2)
        self.lineEdit_db_name.setObjectName(u"lineEdit_db_name")

        self.horizontalLayout_7.addWidget(self.lineEdit_db_name)

        self.label_8 = QLabel(self.tab_2)
        self.label_8.setObjectName(u"label_8")

        self.horizontalLayout_7.addWidget(self.label_8)

        self.lineEdit_db_user = QLineEdit(self.tab_2)
        self.lineEdit_db_user.setObjectName(u"lineEdit_db_user")

        self.horizontalLayout_7.addWidget(self.lineEdit_db_user)

        self.pushButton_db_connect = QPushButton(self.tab_2)
        self.pushButton_db_connect.setObjectName(u"pushButton_db_connect")
        self.pushButton_db_connect.setMinimumSize(QSize(90, 0))
        self.pushButton_db_connect.setMaximumSize(QSize(90, 16777215))

        self.horizontalLayout_7.addWidget(self.pushButton_db_connect)


        self.verticalLayout_6.addLayout(self.horizontalLayout_7)

        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.label_6 = QLabel(self.tab_2)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setMinimumSize(QSize(55, 0))

        self.horizontalLayout_6.addWidget(self.label_6)

        self.lineEdit_sqlfilename = QLineEdit(self.tab_2)
        self.lineEdit_sqlfilename.setObjectName(u"lineEdit_sqlfilename")

        self.horizontalLayout_6.addWidget(self.lineEdit_sqlfilename)

        self.pushButton_load_sql = QPushButton(self.tab_2)
        self.pushButton_load_sql.setObjectName(u"pushButton_load_sql")
        self.pushButton_load_sql.setMinimumSize(QSize(100, 0))
        self.pushButton_load_sql.setMaximumSize(QSize(100, 16777215))

        self.horizontalLayout_6.addWidget(self.pushButton_load_sql)

        self.pushButton_init_db = QPushButton(self.tab_2)
        self.pushButton_init_db.setObjectName(u"pushButton_init_db")
        self.pushButton_init_db.setMinimumSize(QSize(90, 0))
        self.pushButton_init_db.setMaximumSize(QSize(90, 16777215))

        self.horizontalLayout_6.addWidget(self.pushButton_init_db)


        self.verticalLayout_6.addLayout(self.horizontalLayout_6)

        self.textEdit_log = QTextEdit(self.tab_2)
        self.textEdit_log.setObjectName(u"textEdit_log")

        self.verticalLayout_6.addWidget(self.textEdit_log)

        self.tabWidget.addTab(self.tab_2, "")

        self.verticalLayout_5.addWidget(self.tabWidget)


        self.retranslateUi(Form_Db)

        self.tabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(Form_Db)
    # setupUi

    def retranslateUi(self, Form_Db):
        Form_Db.setWindowTitle(QCoreApplication.translate("Form_Db", u"Form", None))
        self.label_5.setText(QCoreApplication.translate("Form_Db", u"DataBase \uad00\ub9ac \uc124\uc815", None))
        self.groupBox.setTitle(QCoreApplication.translate("Form_Db", u"Key \uc0dd\uc131", None))
        self.label.setText(QCoreApplication.translate("Form_Db", u"DB \uc0ac\uc6a9\uc790 \ube44\ubc00\ubc88\ud638\uc5d0 \ub300\ud55c \uc554\ud638 \ud0a4 \uc0dd\uc131", None))
        self.pushButton_createkey.setText(QCoreApplication.translate("Form_Db", u"1. \ud0a4 \uc0dd\uc131", None))
        self.label_createkeymsg.setText(QCoreApplication.translate("Form_Db", u"key: ", None))
        self.pushButton_keysave.setText(QCoreApplication.translate("Form_Db", u"2. \ud30c\uc77c\uc5d0 \ud0a4 \uc800\uc7a5", None))
        self.label_createkeymsg_2.setText("")
        self.pushButton_keysave_2.setText(QCoreApplication.translate("Form_Db", u"3. \ud658\uacbd\ubcc0\uc218\uc5d0 \ud0a4 \uc800\uc7a5", None))
        self.groupBox_2.setTitle(QCoreApplication.translate("Form_Db", u"\ube44\ubc00\ubc88\ud638 \uc554\ud638\ud654 \uc800\uc7a5", None))
        self.label_4.setText(QCoreApplication.translate("Form_Db", u"DB \uc0ac\uc6a9\uc790 \ube44\ubc00\ubc88\ud638", None))
        self.checkBox_pwlook.setText(QCoreApplication.translate("Form_Db", u"\ube44\ubc00\ubc88\ud638 \ubcf4\uae30", None))
        self.label_2.setText(QCoreApplication.translate("Form_Db", u"DB \uc0ac\uc6a9\uc790 \ube44\ubc00\ubc88\ud638 \uc554\ud638\ud654 \uc800\uc7a5", None))
        self.pushButton_cryptosave.setText(QCoreApplication.translate("Form_Db", u"\uc554\ud638\ud654 \uc800\uc7a5", None))
        self.groupBox_3.setTitle(QCoreApplication.translate("Form_Db", u"DB \uc0ac\uc6a9\uc790 \ube44\ubc00\ubc88\ud638 \ud655\uc778", None))
        self.label_3.setText(QCoreApplication.translate("Form_Db", u"DB \uc0ac\uc6a9\uc790 \ube44\ubc00\ubc88\ud638 \ud655\uc778", None))
        self.pushButton_validpass.setText(QCoreApplication.translate("Form_Db", u"\ube44\ubc00\ubc88\ud638 \ud655\uc778", None))
        self.label_validpass.setText(QCoreApplication.translate("Form_Db", u"-", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), QCoreApplication.translate("Form_Db", u"DB\uc811\uc18d \uad00\ub828 Key \uc0dd\uc131", None))
        self.label_7.setText(QCoreApplication.translate("Form_Db", u"DB \uc774\ub984:", None))
        self.label_8.setText(QCoreApplication.translate("Form_Db", u"DB User:", None))
        self.pushButton_db_connect.setText(QCoreApplication.translate("Form_Db", u"\u2460 DB \uc811\uc18d", None))
        self.label_6.setText(QCoreApplication.translate("Form_Db", u"SQL \ud30c\uc77c:", None))
        self.pushButton_load_sql.setText(QCoreApplication.translate("Form_Db", u"\u2461 SQL \ubd88\ub7ec\uc624\uae30", None))
        self.pushButton_init_db.setText(QCoreApplication.translate("Form_Db", u"\u2462 DB \ucd08\uae30\ud654", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("Form_Db", u"DB \uc0dd\uc131 \ubc0f \ucd08\uae30\ud654", None))
    # retranslateUi

