import cv2
import requests
import time


class VideoCapture:
    def __init__(self, cam_address, cam_force_address=None, blocking=False):
        """
        cam_address: 카메라 피드의 IP 주소
        cam_force_address: 다른 클라이언트를 연결 해제하는 IP 주소 (강제 점유)
        blocking: true인 경우 read() 및 connect_camera() 메서드가 IP 카메라 재연결까지 차단됨
        """
        self.cam_address = cam_address
        self.cam_force_address = cam_force_address
        self.blocking = blocking
        self.capture = None

        # 주기적으로 재연결 시도 시간 설정 (초 단위)
        self.RECONNECTION_PERIOD = 0.5
        # 카메라 연결 메서드 호출
        self.connect_camera()

    def connect_camera(self):
        print("Connecting...")
        while True:
            try:
                if self.cam_force_address is not None:
                    requests.get(self.cam_force_address)

                self.capture = cv2.VideoCapture(self.cam_address)

                if not self.capture.isOpened():
                    time.sleep(self.RECONNECTION_PERIOD)
                    raise Exception("Could not connect to a camera: {0}".format(self.cam_address))

                print("Connected to a camera: {}".format(self.cam_address))

                break
            except Exception as e:
                print(e)

                if self.blocking is False:
                    break

                time.sleep(self.RECONNECTION_PERIOD)

    def getStream(self):
        """
        프레임을 읽고 프레임을 받지 못하면 카메라 재연결 시도

        :return: ret - 프레임이 성공적으로 읽혔는지 여부를 나타내는 부울 값
                 frame - 카메라에서 받은 OpenCV 이미지
        """

        ret, frame = self.capture.read()

        # 피드가 다운되면 재연결 시도
        if ret is False:
            self.connect_camera()

        return ret, frame


# RTSP 스트림 URL을 사용하여 VideoCapture 객체 생성
cap = VideoCapture("rtsp://210.99.70.120:1935/live/cctv007.stream")

while (1):
    ret, frame = cap.getStream()

    # 피드가 정상적으로 작동하지 않을 경우 예외 처리
    try:
        cv2.imshow('RTSP Stream', frame)
    except:
        print("Feed has gone down...")

    # Enter 키를 눌러 종료
    if cv2.waitKey(1) == 13:  # 13은 Enter 키입니다.
        print("Exited...")
        break

# 카메라 자원 해제 및 창 닫기
cv2.destroyAllWindows()