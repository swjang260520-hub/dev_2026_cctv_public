"""
WidgetMain.py

멀티-CCTV 메인 윈도우.

[구조]
  카메라 관리 영역(테이블/그리드/워커/그룹)은 ui/camera_page_mixin.py 의
  CameraPageMixin 으로 분리되어 있고, MainWindow 가 이를 함께 상속한다.
  테이블 컬럼 인덱스 Col 도 mixin 에 있으며 여기서 재수출한다
  (하위 호환: from WidgetMain import Col).

[수정 이력] 자세한 내용은 변경요약서.md 참고
  - torch 를 모듈 최상단에서 import 하던 것을 '지연 import' 로 변경.
    GPU 메모리 표시는 선택 기능인데, torch 가 없거나 설치가 깨진 PC 에서
    앱이 창조차 뜨지 못하고 죽던 문제를 수정.
  - 더 이상 쓰지 않는 import 정리.
"""

import os
import sys
import time
from datetime import datetime
from typing import Optional, Dict
import psutil

from PySide6.QtCore import Qt, Slot, QTimer, QSize, Property
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QMainWindow, QStatusBar, QLabel, QTableWidgetItem, QMessageBox,
    QWidget, QHeaderView, QAbstractItemView, QPushButton, QLineEdit, QVBoxLayout,
    QGraphicsDropShadowEffect, QApplication,
)
from collections import namedtuple
from loguru import logger
import qtawesome as qta

from WidgetEventlogDialog import EventlogDialog
from WidgetSettingsDialog import SettingsDialog
from core.camera_manager import CameraManager
from core.models import FrameData, CameraStatus
from core.settings_manager import SettingsManager
from core.workers import CameraWorker, InferenceWorker
from core.health_monitor import CameraHealthMonitor
from ui.camera_widget import CameraWidget
from ui.main_window_ui import Ui_MainWindow
from ui.camera_page_mixin import CameraPageMixin, Col      # Col 재수출(하위 호환)


# --------------------------------------------------------------------- #
# [수정] PyTorch 지연 import
# --------------------------------------------------------------------- #
# torch 는 'GPU 메모리 사용량 표시' 에만 쓰이는 선택 의존성이다.
# 그런데 모듈 최상단에서 import torch 를 하고 있어서,
#   * torch 가 설치되지 않은 PC (또는 CUDA DLL 이 깨진 PC) 에서는
#     앱이 실행되자마자 ImportError/OSError 로 죽고,
#   * torch 가 있어도 시작 시 수 초가 걸렸다.
# 필요한 시점(리소스 위젯 갱신)에 한 번만 불러오고, 실패하면 조용히 건너뛴다.
# --------------------------------------------------------------------- #
_torch_module = None
_torch_checked = False


def _get_torch():
    """torch 를 지연 import 한다. 사용할 수 없으면 None."""
    global _torch_module, _torch_checked
    if not _torch_checked:
        _torch_checked = True
        try:
            import torch as _torch
            _torch_module = _torch
        except Exception as e:      # ImportError / OSError(DLL) 모두 대비
            logger.warning(f"PyTorch 를 불러올 수 없어 GPU 정보 표시를 건너뜁니다: {e}")
    return _torch_module


class MainWindow(QMainWindow, Ui_MainWindow, CameraPageMixin):
    """메인 윈도우"""

    ButtonState = namedtuple('ButtonState', ['start_enabled', 'stop_enabled', 'reconnect_enabled'])

    def get_icon_color(self):
        return self._icon_color

    def set_icon_color(self, color):
        self._icon_color = color

    iconColor = Property(QColor, get_icon_color, set_icon_color)

    def __init__(self):
        super().__init__()
        self._icon_color = QColor("#0084FF")

        # 로거 설정 (이벤트 로그 파일 저장)
        self._setup_logger()

        # 설정 관리
        self.settings_manager = SettingsManager()

        # 비즈니스 로직
        self.camera_manager = CameraManager()

        # 워커 관리
        self.camera_workers: Dict[str, CameraWorker] = {}
        self.camera_statuses: Dict[str, CameraStatus] = {}
        # [신규] 정지 중인 카메라의 RTSP 응답 확인 결과 {camera_id: (응답 여부, 확인 시각)}
        self.camera_health: Dict[str, tuple] = {}
        self.health_monitor: Optional[CameraHealthMonitor] = None
        self.inference_worker: Optional[InferenceWorker] = None
        self.custom_class_names: Dict[str, str] = {}
        self.custom_class_colors: Dict[str, str] = {}

        # [수정] GPU 이름/CUDA 조회는 여기서 하지 않는다.
        # (_update_resource_usage 에서 필요할 때 지연 조회 → 시작 시간 단축)
        self.gpu_name = "GPU"
        # 위젯 관리
        self.camera_widgets: Dict[str, CameraWidget] = {}
        self.detached_windows: Dict[str, list] = {} # 새 창으로 열린 카메라 위젯 관리
        # 테이블 행 위젯 직접 참조 (findChild 대체)
        self.table_row_widgets: Dict[str, Dict[str, QWidget]] = {}
        self.camera_order: list[str] = [] # 카메라 ID의 표시 순서를 저장

        # 이벤트 로그 쓰로틀링
        self.last_event_log_time: Dict[str, float] = {}
        self.EVENT_LOG_THROTTLE_SECS = 1  # 초 단위

        # 상태별 UI 설정 (아이콘, 색상, 툴팁, 버튼 상태)
        self.STATUS_CONFIG = {
            CameraStatus.ACTIVE:       ("mdi6.video", "#3fb950", "활성", self.ButtonState(False, True,  False)),
            CameraStatus.CONNECTING:   ("mdi6.dots-horizontal", "#d29922", "연결 중", self.ButtonState(False, True,  False)),
            CameraStatus.DISCONNECTED: ("mdi6.video-off", "#6e7681", "연결 끊김", self.ButtonState(True,  False, False)),
            CameraStatus.ERROR:        ("mdi6.alert-circle", "#f85149", "오류", self.ButtonState(False, True,  True)),
            CameraStatus.PAUSED:       ("mdi6.pause-circle", "#d29922", "일시정지", self.ButtonState(False, True,  True)),
        }

        self.is_system_running = False

        self.event_detail_dialog = None

        self.setupUi(self)
        self._signal_and_slot()
        self._setup_camera_table()
        self._setup_group_filter()      # [신규] 그룹 필터 UI (CameraPageMixin)
        self._setup_event_table()
        self.ensurePolished()
        self._setup_icons()
        self._apply_shadow_effects()
        self._create_status_bar()

        self._load_settings_and_cameras()

        self._setup_workers()
        self._start_timers()
        self._initial_autostart()

        self.setWindowTitle('CCTV 영상 지능형 분석 체계')
        self.label_title.setText('CCTV 영상 지능형 분석 체계')

        self.class_names = None

    def _setup_logger(self):
        """Loguru 로거 설정: 이벤트 로그를 별도 파일로 저장"""
        if not os.path.exists("logs"):
            os.makedirs("logs")
            
        # 이벤트 로그 전용 핸들러 (매일 00:00 로테이션, 30일 보관)
        # filter: bind(type="event")로 태깅된 로그만 이 파일에 기록
        logger.add(
            "logs/events_{time:YYYY-MM-DD}.log",
            rotation="00:00",
            retention="30 days",
            filter=lambda record: record["extra"].get("type") == "event",
            format="{time:YYYY-MM-DD HH:mm:ss} | {message}",
            encoding="utf-8",
            enqueue=True
        )
        logger.add(
            "logs/system{time:YYYY-MM-DD}.log",
            rotation="10 MB",
            encoding="utf-8",
            enqueue=True
        )

        # 데이터 로드
    def _signal_and_slot(self):
        self.pushButton_toggle.toggled.connect(self.toggle_slot)

        self.add_btn.clicked.connect(self._on_add_camera)
        self.edit_btn.clicked.connect(self._on_edit_camera)
        self.delete_btn.clicked.connect(self._on_delete_camera)
        self.start_btn.clicked.connect(self._on_start_all)
        self.stop_btn.clicked.connect(self._on_stop_all)
        self.grid_combo.currentIndexChanged.connect(self._update_grid_layout)
        self.camera_table.itemDoubleClicked.connect(self._on_table_item_double_clicked)
        self.camera_table.cellClicked.connect(self._on_table_cell_clicked)
        self.settings_btn.clicked.connect(self._on_settings_clicked)
        self.camera_table.horizontalHeader().sectionClicked.connect(self._camera_table_header_clicked)
        self.camera_table.verticalHeader().setVisible(False)

        self.tableWidget_event.itemClicked.connect(self._on_eventlog_item_clicked)

    def _camera_table_header_clicked(self, idx: int):
        # 20260527 swjang 헤더가 클릭되었을 때 호출되는 함수, 첫 번째 헤더(index 0)를 클릭했을 때만 동작
        if idx == 0:
            # 현재 첫 번째 행의 체크 상태를 기준으로 반전 결정, (전체 선택되어 있다면 해제, 아니면 전체 선택)
            first_item = self.camera_table.item(0, 0)
            if first_item and first_item.checkState() == Qt.Checked:
                new_state = Qt.Unchecked
            else:
                new_state = Qt.Checked

            # 모든 행의 첫 번째 열 체크박스 상태 변경
            for row in range(self.camera_table.rowCount()):
                item = self.camera_table.item(row, 0)
                if item:
                    item.setCheckState(new_state)


    def _create_status_bar(self):
        """상태바"""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

        self.status_label = QLabel("체계화면 준비됨")
        self.status_bar.addWidget(self.status_label, 1)


        # 리소스 모니터링 위젯 (아이콘 + 텍스트) - QPushButton 사용 (Flat)
        # 2025.02.25 작업관리자와 값이 차이가 있어 주석 처리함
        # self.cpu_widget = QPushButton("CPU: 0%")
        # self.cpu_widget.setFlat(True)
        # self.cpu_widget.setStyleSheet("border: none; padding: 0 5px; text-align: left;")
        # self.cpu_widget.setCursor(Qt.ArrowCursor)
        #
        # self.ram_widget = QPushButton("RAM: 0%")
        # self.ram_widget.setFlat(True)
        # self.ram_widget.setStyleSheet("border: none; padding: 0 5px; text-align: left;")
        # self.ram_widget.setCursor(Qt.ArrowCursor)
        #
        # self.gpu_widget = QPushButton("GPU: -")
        # self.gpu_widget.setFlat(True)
        # self.gpu_widget.setStyleSheet("border: none; padding: 0 5px; text-align: left;")
        # self.gpu_widget.setCursor(Qt.ArrowCursor)
        #
        # self.status_bar.addPermanentWidget(self.cpu_widget)
        # self.status_bar.addPermanentWidget(self.ram_widget)
        # self.status_bar.addPermanentWidget(self.gpu_widget)

        self.active_label = QPushButton("활성: 0/0")
        self.active_label.setFlat(True)
        self.active_label.setStyleSheet("border: none; padding: 0 5px; text-align: center;")
        self.active_label.setCursor(Qt.ArrowCursor)
        self.status_bar.addPermanentWidget(self.active_label)

    def _setup_icons(self):
        """qt_material 아이콘을 설정합니다."""
        icon_color = self._icon_color
        self.pushButton_toggle.setIcon(qta.icon('mdi6.swap-horizontal', color=icon_color))
        self.pushButton_toggle.setIconSize(QSize(18, 18))

        self.start_btn.setIcon(qta.icon('mdi6.play', color=icon_color))
        self.start_btn.setIconSize(QSize(24, 24))
        self.stop_btn.setIcon(qta.icon('mdi6.stop', color=icon_color))
        self.stop_btn.setIconSize(QSize(24, 24))
        self.add_btn.setIcon(qta.icon('mdi6.plus', color=icon_color))
        self.add_btn.setIconSize(QSize(18, 18))
        self.edit_btn.setIcon(qta.icon('mdi6.pencil', color=icon_color))
        self.edit_btn.setIconSize(QSize(18, 18))
        self.delete_btn.setIcon(qta.icon('mdi6.delete', color=icon_color))
        self.delete_btn.setIconSize(QSize(18, 18))
        
        # 설정 버튼 추가 (프로그래밍 방식으로 레이아웃에 삽입)
        self.settings_btn.setIcon(qta.icon('mdi6.cog', color=icon_color))
        self.settings_btn.setIconSize(QSize(18, 18))

    def _update_ui_icons(self):
        """테마 변경 시 아이콘 색상을 업데이트합니다."""
        self._setup_icons()
        
        # 테이블 내의 관리 버튼 아이콘 업데이트
        icon_color = self._icon_color

        for row_widgets in self.table_row_widgets.values():
            if start_btn := row_widgets.get("start_btn"):
                start_btn.setIcon(qta.icon('mdi6.play', color=icon_color))
            if stop_btn := row_widgets.get("stop_btn"):
                stop_btn.setIcon(qta.icon('mdi6.stop', color=icon_color))
            if reconnect_btn := row_widgets.get("reconnect_btn"):
                reconnect_btn.setIcon(qta.icon('mdi6.refresh', color=icon_color))

        # 그룹 일괄 제어 버튼도 아이콘 전용이므로 함께 갱신한다
        # (CameraPageMixin 제공 — 그룹 UI 가 없는 구성에서는 조용히 건너뜀)
        if refresh := getattr(self, "refresh_group_button_icons", None):
            refresh()

    def _apply_shadow_effects(self):
        """UI 요소에 그림자 효과 적용 (QSS box-shadow 미지원 대응)"""
        self.splitter_2.setContentsMargins(2, 2, 3, 3)

        # 시스템 현황 그룹박스
        self._add_shadow(self.groupBox_status)
        self._add_shadow(self.groupBox_control)
        self._add_shadow(self.groupBox_event)
        self._add_shadow(self.groupBox_list)
        
        # 상단 타이틀 프레임
        self._add_shadow(self.frame_top)

    def _add_shadow(self, widget):
        """위젯에 그림자 효과 추가"""
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(15)
        shadow.setXOffset(0)
        shadow.setYOffset(0)
        shadow.setColor(QColor(0, 0, 0, 30))
        widget.setGraphicsEffect(shadow)

    def _setup_workers(self):
        """워커 설정"""
        # 추론 워커 (전역 1개) - 테스트용 더미 모드, # YOLO 없으면 더미 모드
        self._start_inference_worker()

        # [신규] 정지 카메라 상태 감시 (30초마다 RTSP OPTIONS, 영상은 받지 않음)
        self.health_monitor = CameraHealthMonitor(interval_s=30, timeout_s=2.0)
        self.health_monitor.health_checked.connect(self._on_health_checked)
        self._refresh_health_targets()
        self.health_monitor.start()

        # 시작/정지/추가/삭제를 놓치지 않도록 5초마다 감시 대상 재계산 (가벼운 작업)
        self.health_target_timer = QTimer(self)
        self.health_target_timer.timeout.connect(self._refresh_health_targets)
        self.health_target_timer.start(5000)

    def _start_inference_worker(self):
        """추론 워커 시작 (재시작 포함)"""
        # 기존 워커가 있다면 정지
        if self.inference_worker is not None:
            self.inference_worker.stop()
            self.inference_worker.wait()

        model_path = self.settings_manager.get_setting('model_path', 'yolo11n.pt')
        device = self.settings_manager.get_setting('device', 'auto')
        conf = self.settings_manager.get_setting('conf_threshold', 0.4)
        iou = self.settings_manager.get_setting('iou_threshold', 0.7)
        batch_size = self.settings_manager.get_setting('batch_size', 8)
        targets = self.settings_manager.get_setting('target_classes', None)

        self.inference_worker = InferenceWorker(model_path=model_path, device=device, use_dummy=False, batch_size=batch_size)
        self.inference_worker.set_confidence(conf)
        self.inference_worker.set_iou(iou)
        self.inference_worker.set_target_classes(targets)
        self.inference_worker.inference_complete.connect(self._on_inference_complete)
        self.inference_worker.model_loaded.connect(self._on_model_loaded)
        # [수정] 람다 대신 bound method 로 연결한다.
        # 람다는 수신 QObject 가 특정되지 않아 PySide6 가 DirectConnection 으로
        # 처리할 수 있고, 그러면 워커 스레드에서 _add_event_log() 가 실행되어
        # GUI 스레드가 아닌 곳에서 QTableWidget 을 조작하게 된다(비정상 종료 위험).
        self.inference_worker.error_occurred.connect(self._on_inference_error)
        self.inference_worker.start()

        # 로딩 시작 시각적 피드백
        self.status_label.setText('AI 모델 로드 및 엔진 초기화 중...')

    def toggle_slot(self, toggled):
        logger.debug(f"{toggled}")

        if toggled:
            self.widget_left.setHidden(True)

        else:
            self.widget_left.setHidden(False)

    def _start_timers(self):
        """타이머 시작"""
        # 통합 타이머 (1초 간격)
        self.main_timer = QTimer(self)
        self.main_timer.timeout.connect(self._on_timer_tick)
        self.main_timer.start(1000)
        
        self._tick_count = 0
        self._update_datetime()

    def _on_timer_tick(self):
        """통합 타이머 틱 핸들러"""
        self._tick_count += 1
        
        # 1. 날짜/시간 업데이트 (매 1초)
        self._update_datetime()
        
        # 2. 리소스 모니터링 업데이트 (매 2초)
        # if self._tick_count % 2 == 0:
        #     self._update_resource_usage()

    def _initial_autostart(self):
        """프로그램 시작 시 자동 시작 설정된 카메라들을 시작합니다."""
        autostart_count = 0
        for camera_id, worker in self.camera_workers.items():
            config = self.camera_manager.get_camera(camera_id)
            if config and config.autostart and not worker.isRunning():
                worker.start()
                autostart_count += 1
        
        if autostart_count > 0:
            self.is_system_running = True
            self.status_label.setText(f"{autostart_count}개의 카메라 자동 시작됨")
            self._add_event_log('자동시작',f"{autostart_count}개의 카메라 자동 시작됨")

    def _update_datetime(self):
        """날짜/시간 업데이트"""
        now = datetime.now()
        weekdays = ["월", "화", "수", "목", "금", "토", "일"]
        day_str = weekdays[now.weekday()]
        self.labelDateTime.setText(f"{now.strftime('%Y-%m-%d')} ({day_str}) {now.strftime('%H:%M:%S')}")

        self._update_event_log_colors()

    def _update_resource_usage(self):
        """시스템 리소스 사용량 업데이트 (CPU, RAM, GPU)"""
        # [수정] _create_status_bar 에서 cpu/ram/gpu 위젯 생성부가 주석 처리되어
        # 있어, 현재 상태로 이 함수를 호출하면 AttributeError 가 발생한다.
        # (호출부도 주석 상태이지만 재활성화 시를 대비한 방어)
        if not hasattr(self, "cpu_widget"):
            return

        # CPU & RAM
        cpu_per = psutil.cpu_percent()
        ram_per = psutil.virtual_memory().percent
        
        # 경고 임계값 설정 (예: 80%)
        warning_threshold = 80
        warning_color = "#f85149"
        normal_color = self._icon_color # 테마 색상 사용
        
        # CPU 업데이트
        # 2025.02.25. 작업관리자의 사용량과 차이가 있어 주석처리함
        # 2025.03.13. 함수 호출 부분을 주석함.
        self.cpu_widget.setText(f"CPU: {cpu_per}%")
        if cpu_per > warning_threshold:
            self.cpu_widget.setIcon(qta.icon('mdi6.cpu-64-bit', color=warning_color))
            self.cpu_widget.setStyleSheet(f"color: {warning_color}; font-weight: bold; border: none; padding: 0 5px;")
        else:
            self.cpu_widget.setIcon(qta.icon('mdi6.cpu-64-bit', color=normal_color))
            self.cpu_widget.setStyleSheet("border: none; padding: 0 5px;")

        # RAM 업데이트
        self.ram_widget.setText(f"RAM: {ram_per}%")
        if ram_per > warning_threshold:
            self.ram_widget.setIcon(qta.icon('mdi6.memory', color=warning_color))
            self.ram_widget.setStyleSheet(f"color: {warning_color}; font-weight: bold; border: none; padding: 0 5px;")
        else:
            self.ram_widget.setIcon(qta.icon('mdi6.memory', color=normal_color))
            self.ram_widget.setStyleSheet("border: none; padding: 0 5px;")

        # GPU (PyTorch 사용 시 — 지연 import, 실패해도 앱은 계속 동작)
        gpu_text = "GPU: N/A"
        gpu_color = "#6e7681"
        torch = _get_torch()
        if torch is not None:
            try:
                if torch.cuda.is_available():
                    if self.gpu_name == "GPU":
                        # 장치 이름은 처음 한 번만 조회
                        self.gpu_name = (torch.cuda.get_device_name(0)
                                         .replace("NVIDIA", "").replace("GeForce ", "").strip())
                    # 현재 할당된 메모리 / 전체 메모리
                    free_mem, total_mem = torch.cuda.mem_get_info(0)
                    used_mem = total_mem - free_mem
                    used_gb = used_mem / 1024 ** 3
                    total_gb = total_mem / 1024 ** 3
                    usage_percent = (used_mem / total_mem) * 100

                    gpu_text = f"{self.gpu_name} Mem: {used_gb:.1f}/{total_gb:.1f}GB ({usage_percent:.0f}%)"
                    gpu_color = normal_color
            except Exception as e:
                logger.debug(f"GPU 정보를 읽지 못했습니다: {e}")

        self.gpu_widget.setText(gpu_text)
        self.gpu_widget.setIcon(qta.icon('mdi6.expansion-card', color=gpu_color))

    @Slot(object)
    def _on_inference_complete(self, frame_data: FrameData):
        """추론 완료 (하이브리드 2단계: 프레임 + 탐지결과)"""
        camera_id = frame_data.camera_id

        # 커스텀 클래스 이름 적용
        if frame_data.has_detections and self.custom_class_names:
            for det in frame_data.detections:
                custom_name = self.custom_class_names.get(str(det.class_id))
                if custom_name:
                    # logger.debug(f"Mapping class {det.class_id} to {custom_name}")
                    det.class_name = custom_name

        # Update camera widget
        if camera_id in self.camera_widgets:
            self.camera_widgets[camera_id].update_frame(frame_data)
        
        # Update any detached windows
        if camera_id in self.detached_windows:
            for window in self.detached_windows[camera_id]:
                window.update_frame(frame_data)

        # Log detection events (throttled)
        if frame_data.has_detections:
            now = time.time()
            last_log_time = self.last_event_log_time.get(camera_id, 0)

            if (now - last_log_time) > self.EVENT_LOG_THROTTLE_SECS:
                self.last_event_log_time[camera_id] = now

                camera_config = self.camera_manager.get_camera(camera_id)
                camera_name = camera_config.name if camera_config else camera_id

                # Create a summary of detections
                detection_summary = []
                for det in frame_data.detections:
                    summary = f"{det.class_name} ({det.confidence:.0%})"
                    detection_summary.append(summary)

                message = "객체 탐지: " + ", ".join(detection_summary)
                self._add_event_log(camera_name, message)

    def _setup_event_table(self):
        """이벤트 로그 테이블 초기 설정"""
        self.tableWidget_event.setColumnCount(3)
        self.tableWidget_event.setHorizontalHeaderLabels(["일시", "카메라명", "내용"])

        header = self.tableWidget_event.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        # header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        # header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
       # 헤더 폰트 굵게 설정
        font = header.font()
        font.setBold(True)
        header.setFont(font)
        
        self.tableWidget_event.setEditTriggers(QAbstractItemView.NoEditTriggers)
        
        # 필터 입력창 생성 및 배치 (테이블 상단에 추가)
        self.event_filter_edit = QLineEdit()
        self.event_filter_edit.setObjectName("SearchBar")
        self.event_filter_edit.setPlaceholderText("이벤트 로그 필터링 (예: 오류, 탐지, bus)...")
        self.event_filter_edit.setClearButtonEnabled(True)
        self.event_filter_edit.textChanged.connect(self._filter_event_log)
        
        # 기존 테이블을 레이아웃에서 찾아 필터와 함께 배치
        parent = self.tableWidget_event.parentWidget()
        if parent and parent.layout():
            layout = parent.layout()
            if layout.indexOf(self.tableWidget_event) != -1:
                container = QWidget()
                container_layout = QVBoxLayout(container)
                container_layout.setContentsMargins(0, 0, 0, 0)
                layout.replaceWidget(self.tableWidget_event, container)
                container_layout.addWidget(self.event_filter_edit)
                container_layout.addWidget(self.tableWidget_event)

    def _filter_event_log(self, text: str):
        """이벤트 로그 필터링"""
        search_text = text.lower()
        for row in range(self.tableWidget_event.rowCount()):
            match = False
            # 모든 컬럼(시간, 카메라명, 내용) 검색
            for col in range(self.tableWidget_event.columnCount()):
                item = self.tableWidget_event.item(row, col)
                if item and search_text in item.text().lower():
                    match = True
                    break
            self.tableWidget_event.setRowHidden(row, not match)

    def _add_event_log(self, camera_name: str, message: str):
        """이벤트 로그 테이블에 새 항목 추가"""
        # 파일 로그 저장 (type='event' 태그를 사용하여 위에서 설정한 필터에 걸리게 함)
        logger.bind(type="event").info(f"[{camera_name}] {message}")

        row = 0
        self.tableWidget_event.insertRow(row)

        now_dt = datetime.now()
        timestamp = now_dt.strftime("%H:%M:%S")

        time_item = QTableWidgetItem(timestamp)
        time_item.setTextAlignment(Qt.AlignCenter)
        time_item.setData(Qt.UserRole, now_dt)  # 시간 계산을 위해 datetime 객체 저장
        
        name_item = QTableWidgetItem(camera_name)
        name_item.setTextAlignment(Qt.AlignCenter)
        message_item = QTableWidgetItem(message)
        message_item.setToolTip(message)

        # 초기 색상 설정 (강조색)
        red_color = QColor("#f85149")
        for item in [time_item, name_item, message_item]:
            item.setForeground(red_color)

        self.tableWidget_event.setItem(row, 0, time_item)
        self.tableWidget_event.setItem(row, 1, name_item)
        self.tableWidget_event.setItem(row, 2, message_item)

        # 행 500개로 제한
        if self.tableWidget_event.rowCount() > 500:
            self.tableWidget_event.removeRow(500)

        # 현재 필터 적용 (새로 추가된 행 숨김 처리)
        if hasattr(self, 'event_filter_edit'):
            filter_text = self.event_filter_edit.text().lower()
            if filter_text:
                match = (filter_text in timestamp.lower() or
                         filter_text in camera_name.lower() or
                         filter_text in message.lower())
                self.tableWidget_event.setRowHidden(row, not match)

    @Slot(str)
    def _on_inference_error(self, message: str):
        """
        추론 워커 오류 → 이벤트 로그.
        (람다 대신 bound slot 으로 연결해야 GUI 스레드에서 실행된다)
        """
        self._add_event_log("System", message)

    def _update_event_log_colors(self):
        """설정된 시간이 지난 로그의 강조 색상을 해제"""
        duration_min = self.settings_manager.get_setting('log_highlight_duration', 1)
        limit_seconds = duration_min * 60
        now = datetime.now()

        # 강조색 (Red)
        highlight_color = QColor("#f85149")

        for row in range(self.tableWidget_event.rowCount()):
            time_item = self.tableWidget_event.item(row, 0)
            if not time_item: continue

            log_time = time_item.data(Qt.UserRole)
            if not isinstance(log_time, datetime): continue

            elapsed = (now - log_time).total_seconds()

            # 시간이 지났으면 색상 초기화 (기본색으로)
            if elapsed > limit_seconds:
                if time_item.foreground().color().name() == highlight_color.name():
                    for col in range(3):
                        self.tableWidget_event.item(row, col).setData(Qt.ForegroundRole, None)

    def _on_model_loaded(self, success: bool, class_name):
        """모델 로드 완료"""
        logger.debug(f'_on_model_loaded - {success} - {class_name}')

        self.class_names = class_name

        model_name = self.settings_manager.get_setting('model_path', 'Unknown')
        
        if success:
            msg = f"객체탐지 모델({model_name}) 로드 완료"
            self.status_label.setText(msg)
            self.status_label.setStyleSheet("color: #3fb950; font-weight: bold;")
            self._add_event_log("System", msg)
        else:
            msg = f"객체탐지 모델({model_name}) 로드 실패 - 탐지 비활성화"
            self.status_label.setText(msg)
            self.status_label.setStyleSheet("color: #f85149; font-weight: bold;")
            self._add_event_log("System", msg)
            
            QMessageBox.warning(self, "모델 로드 실패", 
                                f"'{model_name}' 모델을 로드할 수 없습니다.\n영상은 표시되지만 객체 탐지는 동작하지 않습니다.")

    def _load_settings_and_cameras(self):
        """시작 시 설정과 카메라 정보를 로드하고 UI에 적용합니다."""
        
        # 1. 앱 설정 로드
        settings = self.settings_manager.load_app_settings()

        # [수정] settings['system_settings'] 직접 접근 → .get() 으로 방어
        system_settings = settings.get('system_settings', {})
        self.custom_class_names = system_settings.get('custom_class_names', {})
        self.custom_class_colors = system_settings.get('custom_class_colors', {})

        # 2. 카메라 정보 로드
        camera_configs = self.settings_manager.load_cameras_info()
        loaded_camera_ids_from_file = []
        for config in camera_configs:
            self.camera_manager.add_camera(config) # Add all cameras to manager first
            loaded_camera_ids_from_file.append(config.camera_id)

        # 설정에서 카메라 순서 로드. 없으면 현재 로드된 순서 사용
        if 'camera_order' in settings:
            # 설정에 있는 순서대로 카메라를 추가 (존재하는 카메라만)
            self.camera_order = [cid for cid in settings['camera_order'] if cid in loaded_camera_ids_from_file]
            # 설정에 없지만 새로 로드된 카메라가 있다면 뒤에 추가
            for cid in loaded_camera_ids_from_file:
                if cid not in self.camera_order:
                    self.camera_order.append(cid)
        else:
            self.camera_order = loaded_camera_ids_from_file # Use order from file if no saved order

        # camera_order에 따라 카메라 위젯 및 워커 설정
        # _add_camera_internal을 호출하되, 테이블 행 추가는 건너뛰도록 합니다.
        # 실제 테이블 행 추가는 _rebuild_camera_table에서 camera_order에 따라 수행합니다.
        for camera_id in self.camera_order:
            config = self.camera_manager.get_camera(camera_id)
            if config:
                self._add_camera_internal(config, skip_table_add=True)
        
        # 카메라 테이블 다시 그리기
        self._rebuild_camera_table()

        # [신규] 로드된 카메라 기준으로 그룹 필터 구성
        self._refresh_group_filter()

        # 3. 로드된 설정 UI에 적용
        if 'window' in settings:
            win = settings['window']
            if win.get('maximized', False):
                self.showMaximized()
            else:
                self.resize(win.get('width', 1280), win.get('height', 720))
                self.move(win.get('x', 100), win.get('y', 100))

        if 'splitter_sizes' in settings:
            self.splitter.setSizes(settings['splitter_sizes'])

        if 'grid_index' in settings:
            self.grid_combo.setCurrentIndex(settings['grid_index'])

        if 'left_panel_hidden' in settings:
            self.pushButton_toggle.setChecked(settings['left_panel_hidden'])

        # 테마 및 부제목 적용
        theme = self.settings_manager.get_setting('theme', 'Light')
        subtitle = self.settings_manager.get_setting('subtitle', '')
        self.apply_theme(theme)
        if hasattr(self, 'label_subtitle'):
            self.label_subtitle.setText(subtitle)

    def _save_app_settings(self):
        """현재 앱 상태를 설정에 저장합니다."""
        settings = {
            'window': {
                'x': self.x(), 'y': self.y(),
                'width': self.width(), 'height': self.height(),
                'maximized': self.isMaximized()
            },
            'splitter_sizes': self.splitter.sizes(),
            'grid_index': self.grid_combo.currentIndex(),
            'left_panel_hidden': self.pushButton_toggle.isChecked(),
            'camera_order': self.camera_order,
        }
        self.settings_manager.save_app_settings(settings)

    def apply_theme(self, theme_name):
        """테마 적용"""
        # PyInstaller 빌드 환경 대응 (스타일 파일은 내장 리소스)
        if getattr(sys, 'frozen', False):
            base_dir = sys._MEIPASS
        else:
            base_dir = os.path.dirname(os.path.abspath(__file__))

        if theme_name == 'Dark':
            style_path = os.path.join(base_dir, "styles", "dark_style.qss")
        else:
            style_path = os.path.join(base_dir, "styles", "light_style.qss")
            
        if os.path.exists(style_path):
            with open(style_path, "r", encoding="utf-8") as f:
                QApplication.instance().setStyleSheet(f.read())
        
        # 테마에 맞춰 그림자 색상 업데이트
        self._update_shadows(theme_name)
        
        # 스타일 적용 후 속성 업데이트 및 아이콘 갱신
        self.ensurePolished()
        # 속성 업데이트가 완료된 후 아이콘을 갱신하기 위해 타이머 사용
        QTimer.singleShot(0, self._update_ui_icons)

    def _update_shadows(self, theme_name):
        """테마에 따라 그림자 강도를 조절합니다."""
        if theme_name == 'Dark':
            # 다크 모드: 배경이 어두우므로 그림자를 아주 진하게 설정 (Alpha 200)
            shadow_color = QColor(0, 0, 0, 200)
        else:
            # 라이트 모드: 은은한 그림자 (Alpha 50)
            shadow_color = QColor(0, 0, 0, 50)
            
        # 그림자 효과가 적용된 위젯들 업데이트
        widgets = [self.groupBox_status, self.groupBox_control, 
                   self.groupBox_event, self.groupBox_list, self.frame_top]
                   
        for widget in widgets:
            if widget and widget.graphicsEffect():
                effect = widget.graphicsEffect()
                if isinstance(effect, QGraphicsDropShadowEffect):
                    effect.setColor(shadow_color)


    def _on_eventlog_item_clicked(self, item):
        """메인 테이블 행 클릭 시 상세창 데이터 갱신"""

        logger.debug(f'_on_eventlog_item_clicked - {item}')

        row = item.row()

        # 1. 선택한 행의 데이터 추출
        selected_data = [
            self.tableWidget_event.item(row, 0).text() if self.tableWidget_event.item(row, 0) else "-",
            self.tableWidget_event.item(row, 1).text() if self.tableWidget_event.item(row, 1) else "-",
            self.tableWidget_event.item(row, 2).text() if self.tableWidget_event.item(row, 2) else "-"
        ]

        # 2. 상세창이 없거나 닫혀있다면 새로 생성
        if self.event_detail_dialog is None:
            self.event_detail_dialog = EventlogDialog(self)

        # 3. 데이터 업데이트
        self.event_detail_dialog.update_data(selected_data)

        # 4. 창 표시 (이미 떠 있다면 위치만 유지되고 내용만 바뀜)
        # exec()는 모달(창을 닫기 전까지 메인 못씀)이므로,
        # 메인과 동시에 쓰고 싶다면 show()를 사용해야 합니다.
        self.event_detail_dialog.show()
        self.event_detail_dialog.raise_()  # 창을 맨 위로 올림
        self.event_detail_dialog.activateWindow()  # 포커스 부여

    @Slot()
    def _on_settings_clicked(self):
        """설정 버튼 클릭 시"""
        dialog = SettingsDialog(self.settings_manager.system_settings, self)

        # 20260522 swjang 설정화면에 모델의 클래스 이름 전달
        if self.class_names:
            dialog.set_class_names(self.class_names)

        if dialog.exec():
            new_settings = dialog.get_settings()
            
            # 변경사항 확인
            theme_changed = new_settings['theme'] != self.settings_manager.get_setting('theme')
            model_changed = (new_settings['model_path'] != self.settings_manager.get_setting('model_path') or
                             new_settings['device'] != self.settings_manager.get_setting('device'))

            # 모델 변경 시 커스텀 클래스 이름 초기화 로직
            if model_changed and new_settings.get('custom_class_names'):
                reply = QMessageBox.question(
                    self,
                    "모델 변경 확인",
                    "모델이 변경되었습니다. 기존의 사용자 정의 라벨 설정이 새 모델과 호환되지 않을 수 있습니다.\n\n"
                    "사용자 정의 라벨 설정을 초기화하시겠습니까?",
                    QMessageBox.Yes | QMessageBox.No
                )
                if reply == QMessageBox.Yes:
                    new_settings['custom_class_names'] = {}
                    logger.info("Custom class names reset due to model change.")

            conf_changed = new_settings['conf_threshold'] != self.settings_manager.get_setting('conf_threshold')
            iou_changed = new_settings['iou_threshold'] != self.settings_manager.get_setting('iou_threshold')
            batch_changed = new_settings.get('batch_size') != self.settings_manager.get_setting('batch_size')
            targets_changed = new_settings.get('target_classes') != self.settings_manager.get_setting('target_classes')
            custom_names_changed = new_settings.get('custom_class_names') != self.settings_manager.get_setting('custom_class_names')
            custom_colors_changed = new_settings.get('custom_class_colors') != self.settings_manager.get_setting('custom_class_colors')
            
            # 새 설정으로 업데이트
            self.settings_manager.update_settings(new_settings)
            self._save_app_settings()
            
            # 커스텀 클래스 이름 설정 업데이트 (항상 최신 값 반영)
            self.custom_class_names = new_settings.get('custom_class_names', {})
            self.custom_class_colors = new_settings.get('custom_class_colors', {})

            if theme_changed:
                self.apply_theme(new_settings['theme'])
                logger.info(f"Theme changed to {new_settings['theme']}")
            
            # 부제목 업데이트
            if hasattr(self, 'label_subtitle'):
                self.label_subtitle.setText(new_settings.get('subtitle', ''))
            
            if custom_names_changed:
                logger.info(f"Custom class names updated: {self.custom_class_names}")

            if custom_colors_changed:
                logger.info(f"Custom class colors updated: {self.custom_class_colors}")
                # 모든 카메라 위젯에 새 색상 적용
                for widget in self.camera_widgets.values():
                    widget.set_custom_colors(self.custom_class_colors)
                # 분리된 창에도 적용
                for windows in self.detached_windows.values():
                    for window in windows:
                        if hasattr(window, 'camera_widget'):
                            window.camera_widget.set_custom_colors(self.custom_class_colors)
            
            if self.inference_worker:
                if conf_changed:
                    self.inference_worker.set_confidence(new_settings['conf_threshold'])
                    logger.info(f"Confidence threshold updated to {new_settings['conf_threshold']}")
                
                if iou_changed:
                    self.inference_worker.set_iou(new_settings['iou_threshold'])
                    logger.info(f"IOU threshold updated to {new_settings['iou_threshold']}")
                
                if batch_changed:
                    self.inference_worker.set_batch_size(new_settings['batch_size'])
                    logger.info(f"Batch size updated to {new_settings['batch_size']}")

                if targets_changed:
                    self.inference_worker.set_target_classes(new_settings['target_classes'])
                    logger.info(f"Target classes updated: {new_settings['target_classes']}")

                if model_changed:
                    self._start_inference_worker()
                    logger.info(f"Inference worker restarted with model: {new_settings['model_path']}")

    # ==================== 프레임/추론 처리 ====================

    def closeEvent(self, event):
        """종료 이벤트"""
        self._save_app_settings()

        # [신규] 상태 감시 스레드 정지 요청 (진행 중 확인은 최대 2초 내 종료)
        if self.health_monitor:
            self.health_target_timer.stop()
            self.health_monitor.request_stop()

        # 모든 워커 정지
        for worker in self.camera_workers.values():
            worker.stop()

        if self.health_monitor:
            self.health_monitor.stop()

        if self.inference_worker:
            self.inference_worker.stop()

        event.accept()