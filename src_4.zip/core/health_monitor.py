"""
core/health_monitor.py
정지 중인 카메라의 생존 여부를 가볍게 확인하는 백그라운드 감시 스레드.

- 영상을 받지 않고 RTSP OPTIONS 요청 한 번으로 카메라 영상 서비스가 응답하는지만 확인한다.
- 스트리밍 중인 카메라는 감시 대상에서 제외한다 (워커 상태가 더 정확하므로).
- 확인할 때마다 health_checked 시그널을 보낸다 (변경 여부 판단은 UI 쪽에서 한다).
"""

import socket
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, Optional, Tuple
from urllib.parse import urlsplit

from PySide6.QtCore import QThread, Signal, QMutex, QMutexLocker, QWaitCondition
from loguru import logger


def parse_rtsp_target(source: str) -> Optional[Tuple[str, int, str]]:
    """
    RTSP 주소에서 (host, port, 요청 URL) 을 뽑는다. RTSP 가 아니면 None.
    요청 URL 에서는 계정 정보(user:pass@)를 제거한다.
    """
    s = str(source or "").strip()
    if not s.lower().startswith(("rtsp://", "rtsps://")):
        return None
    try:
        parts = urlsplit(s)
        host = parts.hostname
        if not host:
            return None
        port = parts.port or 554
        netloc = f"[{host}]" if ":" in host else host
        if parts.port:
            netloc += f":{parts.port}"
        path = parts.path or "/"
        if parts.query:
            path += "?" + parts.query
        return host, port, f"{parts.scheme}://{netloc}{path}"
    except ValueError:
        return None


def probe_rtsp(host: str, port: int, url: str, timeout: float = 2.0) -> bool:
    """
    RTSP OPTIONS 요청을 보내 응답이 오면 True.
    401(인증 필요) 같은 응답도 '영상 서비스가 살아 있음' 으로 본다.
    """
    request = (
        f"OPTIONS {url} RTSP/1.0\r\n"
        f"CSeq: 1\r\n"
        f"User-Agent: CCTV-HealthMonitor\r\n\r\n"
    ).encode("ascii", errors="ignore")
    try:
        with socket.create_connection((host, port), timeout=timeout) as sock:
            sock.settimeout(timeout)
            sock.sendall(request)
            reply = sock.recv(256)
        return reply.startswith(b"RTSP/")
    except OSError:
        return False


class CameraHealthMonitor(QThread):
    """
    정지 중인 카메라를 주기적으로 RTSP OPTIONS 로 확인한다.

    사용법:
        monitor.set_targets({camera_id: source, ...})   # UI 스레드에서 수시로 갱신
        monitor.health_checked.connect(slot)             # (camera_id, alive, checked_at)
    """

    health_checked = Signal(str, bool, float)   # (camera_id, 응답 여부, 확인 시각 epoch)

    def __init__(self, interval_s: int = 30, timeout_s: float = 2.0,
                 max_parallel: int = 8, parent=None):
        super().__init__(parent)
        self.interval_s = interval_s
        self.timeout_s = timeout_s
        self.max_parallel = max_parallel

        self._targets: Dict[str, str] = {}
        self._mutex = QMutex()
        self._wake = QWaitCondition()
        self._running = False

    # ---------------- UI 스레드에서 호출 ---------------- #
    def set_targets(self, targets: Dict[str, str]):
        """감시할 카메라 {camera_id: source} 를 통째로 교체한다."""
        with QMutexLocker(self._mutex):
            self._targets = dict(targets)

    def check_now(self):
        """대기 중인 주기를 건너뛰고 즉시 한 번 확인한다."""
        with QMutexLocker(self._mutex):
            self._wake.wakeAll()

    def start(self, *args, **kwargs):
        self._running = True
        super().start(*args, **kwargs)

    def request_stop(self):
        """정지 요청 (기다리지 않음)."""
        with QMutexLocker(self._mutex):
            self._running = False
            self._wake.wakeAll()

    def stop(self, timeout_ms: int = 3000) -> bool:
        self.request_stop()
        ok = self.wait(timeout_ms)
        if not ok:
            logger.warning("CameraHealthMonitor 가 제한 시간 내에 종료되지 않았습니다.")
        return ok

    # ---------------- 감시 스레드 ---------------- #
    def run(self):
        logger.info(f"카메라 상태 감시 시작 (주기 {self.interval_s}초, RTSP OPTIONS)")
        with ThreadPoolExecutor(max_workers=self.max_parallel,
                                thread_name_prefix="health") as pool:
            while self._running:
                with QMutexLocker(self._mutex):
                    targets = dict(self._targets)

                jobs = {}
                for cid, source in targets.items():
                    parsed = parse_rtsp_target(source)
                    if parsed:   # RTSP 가 아닌 소스(USB/파일)는 확인하지 않는다
                        jobs[cid] = pool.submit(probe_rtsp, *parsed, self.timeout_s)

                checked_at = time.time()
                for cid, fut in jobs.items():
                    if not self._running:
                        break
                    alive = fut.result()
                    with QMutexLocker(self._mutex):
                        still_target = cid in self._targets   # 확인 도중 스트리밍 시작/삭제됨
                    if still_target:
                        self.health_checked.emit(cid, alive, checked_at)

                # 다음 주기까지 대기 (정지/즉시 확인 요청 시 바로 깨어남)
                self._mutex.lock()
                if self._running:
                    self._wake.wait(self._mutex, int(self.interval_s * 1000))
                self._mutex.unlock()
        logger.info("카메라 상태 감시 종료")
