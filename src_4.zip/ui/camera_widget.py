"""
gui/camera_widget.py
카메라 영상 표시 위젯 (수정본: 타입별 배지 색상 및 텍스트 적용)
"""

from PySide6.QtWidgets import (
    QFrame, QLabel, QVBoxLayout, QHBoxLayout, QSizePolicy, QPushButton
)
from PySide6.QtCore import Qt, Slot, Signal, QTimer, QRect, QSize
from PySide6.QtGui import QImage, QPixmap, QPainter, QPen, QColor, QFont, QBrush
import cv2
from typing import Optional, List, Dict
import time
import qtawesome as qta
from loguru import logger
from core.models import FrameData, Detection, CameraStatus, CameraConfig


class CameraWidget(QFrame):
    """개별 카메라 영상 표시 위젯"""

    # 시그널
    double_clicked = Signal(str)  # camera_id
    open_in_new_window = Signal(str) # camera_id

    # 카메라 타입별 스타일 정의 (텍스트, 배경색)
    TYPE_STYLE_MAP = {
        "rtsp": ("RTSP", "#f85149"),  # Red
        "usb":  ("USB", "#3b82f6"),   # Blue
        "file": ("FILE", "#6b7280"),  # Gray
        "http": ("HTTP", "#10b981"),  # Green
        "default": ("LIVE", "#f85149") # 기본값
    }

    # 클래스 ID별 색상 (COCO 기준)
    CLASS_ID_COLORS: Dict[int, QColor] = {
        0: QColor(255, 85, 85),    # person
        1: QColor(170, 85, 255),   # bicycle
        2: QColor(85, 255, 85),    # car
        3: QColor(255, 85, 170),   # motorcycle
        4: QColor(255, 170, 85),   # bus
        5: QColor(85, 170, 255),   # truck
        6: QColor(255, 255, 85),   # cat
        7: QColor(85, 255, 170),   # dog
    }
    DEFAULT_COLOR = QColor(255, 255, 85)

    def __init__(self, config: CameraConfig, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setAttribute(Qt.WA_Hover, True)
        self.config = config
        self.camera_id = config.camera_id

        self._current_frame_data: Optional[FrameData] = None
        self._latest_detections: Optional[List[Detection]] = None
        self._last_detection_time = 0.0
        self._show_detections = True
        self._status = CameraStatus.DISCONNECTED
        self._fps = 0.0
        self._resolution = (0, 0)

        self.class_id_colors = self.CLASS_ID_COLORS.copy()

        self._is_flashing = False
        self._flash_on = False
        self._flash_timer = QTimer(self)
        self._flash_timer.setInterval(500)
        self._flash_timer.timeout.connect(self._toggle_flash_border)

        self._detection_timeout_timer = QTimer(self)
        self._detection_timeout_timer.setSingleShot(True)
        self._detection_timeout_timer.setInterval(2000)
        self._detection_timeout_timer.timeout.connect(self._stop_flashing)

        self._setup_ui()
        self._update_border_style()
        self._update_status_indicator()

        self._use_high_res_frame = False

    def _setup_ui(self):
        """UI 구성"""
        self.setObjectName("CameraWidget")
        self.setMinimumSize(280, 300)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(1)

        # 상단 헤더
        self.header_frame = QFrame()
        self.header_frame.setObjectName("frameHeader")
        self.header_frame.setFixedHeight(26)

        header_layout = QHBoxLayout(self.header_frame)
        header_layout.setContentsMargins(8, 2, 8, 2)
        header_layout.setSpacing(6)

        # 상태 인디케이터
        self.status_indicator = QLabel()
        self.status_indicator.setObjectName("labelStatus")
        self.status_indicator.setFixedSize(10, 10)
        header_layout.addWidget(self.status_indicator)

        # 타입 배지 (LIVE -> RTSP/USB/FILE 등)
        self.live_badge = QLabel()
        self.live_badge.setObjectName("labelLive")
        self.live_badge.setVisible(False)
        # 초기 텍스트 및 색상 설정
        self._update_badge_style()
        header_layout.addWidget(self.live_badge)

        # 카메라 이름
        self.name_label = QLabel(self.config.name)
        self.name_label.setObjectName("labelCameraName")
        header_layout.addWidget(self.name_label)

        header_layout.addStretch()

        # 새 창 아이콘
        self.new_window_btn = QPushButton()
        self.new_window_btn.setObjectName("new_window_btn")
        self.new_window_btn.setIcon(qta.icon('mdi6.open-in-new', color='#f3f4f6'))
        self.new_window_btn.setFixedSize(22, 22)
        self.new_window_btn.setIconSize(QSize(16, 16))
        self.new_window_btn.setToolTip("새 창으로 보기")
        self.new_window_btn.clicked.connect(lambda: self.open_in_new_window.emit(self.camera_id))
        self.new_window_btn.setVisible(False)
        header_layout.addWidget(self.new_window_btn)

        # 탐지 아이콘
        self.detection_icon = QLabel("🔍")
        self.detection_icon.setObjectName("labelDetection")
        self.detection_icon.setVisible(self.config.detection_enabled)
        header_layout.addWidget(self.detection_icon)

        # 녹화 아이콘
        self.recording_icon = QLabel("🔴")
        self.recording_icon.setObjectName("labelRecording")
        self.recording_icon.setVisible(self.config.recording_enabled)
        header_layout.addWidget(self.recording_icon)

        layout.addWidget(self.header_frame)

        # 비디오 표시 라벨
        self.video_label = QLabel("📷 연결 대기중...")
        self.video_label.setObjectName("labelVideo")
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        layout.addWidget(self.video_label)

        # 하단 푸터
        self.footer_frame = QFrame()
        self.footer_frame.setObjectName("frameFooter")
        self.footer_frame.setFixedHeight(22)

        footer_layout = QHBoxLayout(self.footer_frame)
        footer_layout.setContentsMargins(8, 2, 8, 2)
        footer_layout.setSpacing(10)

        self.fps_label = QLabel("0 FPS")
        self.fps_label.setObjectName("labelFPS")
        self.fps_label.setVisible(False)
        footer_layout.addWidget(self.fps_label)

        self.resolution_label = QLabel("0x0")
        self.resolution_label.setObjectName("labelResolution")
        footer_layout.addWidget(self.resolution_label)

        footer_layout.addStretch()

        self.detection_count_label = QLabel("Objects: 0")
        self.detection_count_label.setObjectName("labelDetectionCount")
        footer_layout.addWidget(self.detection_count_label)

        layout.addWidget(self.footer_frame)

    def _update_badge_style(self):
        """카메라 타입에 따라 배지의 텍스트와 색상을 업데이트합니다."""
        source_type = getattr(self.config, 'source_type', 'rtsp').lower()
        text, color = self.TYPE_STYLE_MAP.get(source_type, self.TYPE_STYLE_MAP["default"])

        self.live_badge.setText(text)
        self.live_badge.setStyleSheet(f"""
            background-color: {color}; 
            color: white; 
            border-radius: 3px; 
            padding: 2px 4px; 
            font-weight: bold; 
            font-size: 10px;
        """)

    def _update_border_style(self):
        """위젯의 테두리 스타일을 동적으로 업데이트합니다."""
        if self._is_flashing and self._flash_on:
            self.setStyleSheet("#CameraWidget { border: 3px solid #ef4444; border-radius: 8px; }")
        else:
            self.setStyleSheet("")
            self.style().unpolish(self)
            self.style().polish(self)
        self.update()

    def _start_flashing(self):
        if not self._is_flashing:
            self._is_flashing = True
            self._flash_on = True
            self._flash_timer.start()
            self._update_border_style()

    def _stop_flashing(self):
        if self._is_flashing:
            self._is_flashing = False
            self._flash_timer.stop()
            self._flash_on = False
            self._update_border_style()

    @Slot()
    def _toggle_flash_border(self):
        self._flash_on = not self._flash_on
        self._update_border_style()

    def enterEvent(self, event):
        self.setProperty("hovered", True)
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.setProperty("hovered", False)
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()
        super().leaveEvent(event)

    def _update_status_indicator(self):
        colors = {
            CameraStatus.ACTIVE: "#3fb950",
            CameraStatus.CONNECTING: "#d29922",
            CameraStatus.DISCONNECTED: "#6e7681",
            CameraStatus.ERROR: "#f85149",
            CameraStatus.PAUSED: "#d29922",
        }
        color = colors.get(self._status, "#6e7681")
        self.status_indicator.setStyleSheet(f"background-color: {color}; border-radius: 5px;")

    @Slot(object)
    def update_raw_frame(self, frame_data: FrameData):
        if frame_data.camera_id != self.camera_id: return
        self._current_frame_data = frame_data
        self._render_frame()

    @Slot(object)
    def update_detections(self, frame_data: FrameData):
        if frame_data.camera_id != self.camera_id: return
        self._latest_detections = frame_data.detections
        self._last_detection_time = time.time()
        count = frame_data.detection_count
        self.detection_count_label.setText(f"Objects: {count}")
        if count > 0:
            if not self._is_flashing: self._start_flashing()
            self._detection_timeout_timer.start()

    @Slot(object)
    def update_frame(self, frame_data: FrameData):
        if frame_data.camera_id != self.camera_id: return
        self._current_frame_data = frame_data
        self._latest_detections = frame_data.detections
        self._last_detection_time = time.time()
        count = frame_data.detection_count
        self.detection_count_label.setText(f"Objects: {count}")
        if count > 0:
            if not self._is_flashing: self._start_flashing()
            self._detection_timeout_timer.start()
        self._render_frame()

    def _render_frame(self):
        if self._current_frame_data is None: return
        frame = self._current_frame_data.frame
        if frame is None: return
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_frame.shape
        bytes_per_line = ch * w
        q_image = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(q_image)
        if self._show_detections and self._latest_detections:
            if time.time() - self._last_detection_time < 0.5:
                pixmap = self._draw_detections(pixmap, self._latest_detections)
        scaled_pixmap = pixmap.scaled(self.video_label.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        self.video_label.setPixmap(scaled_pixmap)

    def _draw_detections(self, pixmap: QPixmap, detections: List[Detection]) -> QPixmap:
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.TextAntialiasing)
        font = QFont("SUIT", 9, QFont.Bold)
        painter.setFont(font)
        padding = 2
        for det in detections:
            bg_color = self.class_id_colors.get(det.class_id, self.DEFAULT_COLOR)
            luminance = 0.299 * bg_color.red() + 0.587 * bg_color.green() + 0.114 * bg_color.blue()
            text_color = QColor(0, 0, 0) if luminance > 128 else QColor(255, 255, 255)
            x1, y1, x2, y2 = det.bbox_xyxy
            pen = QPen(bg_color, 1)
            painter.setPen(pen)
            painter.setBrush(Qt.NoBrush)
            painter.drawRect(x1, y1, x2 - x1, y2 - y1)
            label = f"{det.class_name} {det.confidence:.0%}"
            fm = painter.fontMetrics()
            text_rect = fm.boundingRect(label)
            label_rect = text_rect.adjusted(-padding, -padding, padding, padding)
            label_h = label_rect.height()
            if y1 < label_h + 2:
                label_rect.moveTo(x1, y2 - label_h)
            else:
                label_rect.moveTo(x1, y1 - label_h)
            bg_color.setAlpha(180)
            painter.setBrush(QBrush(bg_color))
            painter.setPen(Qt.NoPen)
            painter.drawRoundedRect(label_rect, 4, 4)
            painter.setPen(text_color)
            painter.drawText(label_rect, Qt.AlignCenter, label)
        painter.end()
        return pixmap

    @Slot(str, object)
    def update_status(self, camera_id: str, status: CameraStatus):
        if camera_id != self.camera_id: return
        self._status = status
        self._update_status_indicator()
        self.live_badge.setVisible(status == CameraStatus.ACTIVE)
        self.new_window_btn.setVisible(status == CameraStatus.ACTIVE)
        if status == CameraStatus.DISCONNECTED:
            self.video_label.clear()
            self.video_label.setText("📷 연결 대기중...")
            self._stop_flashing()
        elif status == CameraStatus.CONNECTING:
            self.video_label.setText("🔄 연결 중...")
        elif status == CameraStatus.ERROR:
            self.video_label.setText("❌ 연결 오류")
            self._stop_flashing()

    @Slot(str, float)
    def update_fps(self, camera_id: str, fps: float):
        if camera_id != self.camera_id: return
        self._fps = fps
        self.fps_label.setText(f"{fps:.0f} FPS")
        self.fps_label.setVisible(True)
        if fps < 10: self.fps_label.setStyleSheet("color: #f85149; font-weight: bold;")
        elif fps < 24: self.fps_label.setStyleSheet("color: #d29922; font-weight: bold;")
        else: self.fps_label.setStyleSheet("color: #3fb950; font-weight: bold;")

    @Slot(str, int, int)
    def update_resolution(self, camera_id: str, width: int, height: int):
        if camera_id != self.camera_id: return
        self._resolution = (width, height)
        self.resolution_label.setText(f"{width}x{height}")

    def set_detection_visible(self, visible: bool):
        self._show_detections = visible
        if self._current_frame_data: self._render_frame()

    def update_config(self, config: CameraConfig):
        """설정 업데이트 및 배지 스타일 갱신"""
        self.config = config
        self.name_label.setText(config.name)
        self.detection_icon.setVisible(config.detection_enabled)
        self.recording_icon.setVisible(config.recording_enabled)
        self._update_badge_style() # 타입 변경 시 색상/텍스트 즉시 반영

    def set_custom_colors(self, custom_colors: Dict[str, str]):
        self.class_id_colors = self.CLASS_ID_COLORS.copy()
        if not custom_colors: return
        for cls_id_str, color_hex in custom_colors.items():
            try:
                cls_id = int(cls_id_str)
                self.class_id_colors[cls_id] = QColor(color_hex)
            except (ValueError, TypeError): pass

    def mouseDoubleClickEvent(self, event):
        self.double_clicked.emit(self.camera_id)
        super().mouseDoubleClickEvent(event)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._current_frame_data: self._render_frame()

    def set_high_resolution_view(self, enabled: bool):
        """이 위젯을 고해상도 프레임 표시 모드로 설정"""
        self._use_high_res_frame = bool(enabled)
        if self._current_frame_data is not None:
            self._render_frame()