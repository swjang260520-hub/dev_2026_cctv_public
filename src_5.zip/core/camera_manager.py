"""
core/camera_manager.py
카메라 관리 비즈니스 로직 - UI 의존성 없음
"""

import cv2
import time
import threading
from typing import Optional, Dict, List
from urllib.parse import quote

from .models import CameraConfig, CameraStatus, FrameData, mask_url
from loguru import logger

class CameraCapture:
    """
    OpenCV를 이용한 카메라 프레임 캡처 클래스
    - RTSP, 동영상 파일, 웹캠 지원
    """
    
    # [설정] 서비스 안정화를 위한 최대 프레임 너비 제한
    # - 640 : 기본 분할 화면 (다채널 performance/안정성 중시)
    # - 1920: 단독/최대화 화면 (FHD 고해상도 제한, 4K 이상 과부하 방지)
    MAX_FRAME_WIDTH = 640
    MAX_FHD_WIDTH = 1920

    def __init__(self, config: CameraConfig):
        self.config = config
        self.cap: Optional[cv2.VideoCapture] = None
        
        self.source_fps = 0.0          # 원본 소스 FPS (파일 등)
        self.measured_fps = 0.0        # 실시간 측정 FPS
        self.frame_width = 0
        self.frame_height = 0
        
        # 내부 FPS 계산용
        self._frame_count = 0
        self._last_fps_calc_time = time.time()
        self._last_frame_time = time.time()

    def connect(self) -> bool:
        """카메라 연결"""
        logger.info(f"카메라 연결 시도: {mask_url(self.config.source)}")
        
        connect_source = self.config.get_opencv_source()
        source_str = str(connect_source)

        #backend = cv2.CAP_GSTREAMER if source_str.startswith("rtsp://") else cv2.CAP_ANY
        backend = cv2.CAP_FFMPEG if source_str.startswith("rtsp://") else cv2.CAP_ANY
        self.cap = cv2.VideoCapture(connect_source, backend)

        # RTSP는 일반적으로 cap.set()으로 해상도를 변경할 수 없습니다.
        # 20260810 swjang USB 카메라인 경우 1080p(1920x1080) 해상도 설정
        if self.config.source_type == "usb":
            # (선택) 1080p 30fps 원활한 수신을 위해 MJPG 코덱 지정
            self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)

        if not self.cap or not self.cap.isOpened():
            logger.error(f"카메라 연결 실패: {mask_url(self.config.source)}")
            return False
        
        # OpenCV 내부 버퍼 누적으로 인한 지연을 제거, 
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # 버퍼 1개로 제한
        self.cap.set(cv2.CAP_PROP_FPS, 15)        # FPS 명시

        # --- 원본 FPS 및 해상도 가져오기 ---
        self.source_fps = self.cap.get(cv2.CAP_PROP_FPS)
        self.frame_width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.frame_height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        # 웹캠 등 FPS가 0으로 나오는 경우, 기본값 30으로 설정
        if self.source_fps == 0:
            self.source_fps = 30.0
            logger.warning(f"'{self.config.camera_id}'의 원본 FPS가 0입니다. 기본값 30으로 설정합니다.")

        self._last_frame_time = time.time()
        logger.success(f"카메라 연결 성공: {mask_url(self.config.source)} (원본 FPS: {self.source_fps:.2f})")
        return True

    @property
    def max_allowed_width(self) -> int:
        """그리드/추론용 프레임의 최대 너비"""
        return self.MAX_FRAME_WIDTH

    @property
    def frame_size(self):
        """그리드/추론용 프레임 크기 반환"""
        max_w = self.MAX_FRAME_WIDTH
        if self.frame_width > max_w and self.frame_width > 0:
            height = int(self.frame_height * max_w / self.frame_width)
            return max_w, height
        return self.frame_width, self.frame_height
    
    @staticmethod
    def _resize_to_max_width(frame, max_width: int):
        height, width = frame.shape[:2]
        if width <= max_width:
            return frame

        new_height = max(1, int(height * max_width / width))
        return cv2.resize(
            frame,
            (max_width, new_height),
            interpolation=cv2.INTER_AREA
        )

    def read_frame(self, include_high_res: bool = False) -> Optional[FrameData]:
        """프레임 읽기 및 FPS 계산"""
        if not self.cap or not self.cap.isOpened():
            return None

        ret, source_frame = self.cap.read()
        if not ret:
            return None
        
        # AI 추론과 메인 그리드에는 작은 프레임 사용
        grid_frame = self._resize_to_max_width(
            source_frame, self.MAX_FRAME_WIDTH
        )
        # 분리 창이 하나라도 열려 있을 때만 고해상도 프레임 보관
        high_res_frame = None
        if include_high_res:
            high_res_frame = self._resize_to_max_width(
                source_frame, self.MAX_FHD_WIDTH
            )

        current_time = time.time()
        delta_time = current_time - self._last_frame_time
        if delta_time > 0:
            self.measured_fps = 1.0 / delta_time
        self._last_frame_time = current_time

        return FrameData(
            camera_id=self.config.camera_id,
            frame=grid_frame,
            timestamp=current_time,
            fps=self.measured_fps,
            high_res_frame=high_res_frame,
        )

    def release(self):
        """자원 해제"""
        if self.cap:
            self.cap.release()
            self.cap = None
        logger.info(f"카메라 자원 해제: {self.config.camera_id}")



class CameraManager:
    """카메라 목록 관리 (순수 Python)"""
    
    def __init__(self):
        self._cameras: Dict[str, CameraConfig] = {}
        self._lock = threading.Lock()
    
    def add_camera(self, config: CameraConfig) -> str:
        """카메라 추가"""
        with self._lock:
            self._cameras[config.camera_id] = config
            return config.camera_id
    
    def update_camera(self, camera_id: str, config: CameraConfig):
        """카메라 업데이트"""
        with self._lock:
            if camera_id in self._cameras:
                config.camera_id = camera_id
                self._cameras[camera_id] = config
    
    def remove_camera(self, camera_id: str) -> bool:
        """카메라 삭제"""
        with self._lock:
            if camera_id in self._cameras:
                del self._cameras[camera_id]
                return True
            return False
    
    def get_camera(self, camera_id: str) -> Optional[CameraConfig]:
        """카메라 조회"""
        with self._lock:
            return self._cameras.get(camera_id)
    
    def get_all_cameras(self) -> List[CameraConfig]:
        """전체 카메라 목록"""
        with self._lock:
            return list(self._cameras.values())
    
    def get_enabled_cameras(self) -> List[CameraConfig]:
        """활성화된 카메라 목록"""
        with self._lock:
            return [c for c in self._cameras.values() if c.enabled]
    
    @property
    def total_count(self) -> int:
        return len(self._cameras)
    
    def get_stats(self) -> Dict:
        """통계 반환"""
        with self._lock:
            enabled = sum(1 for c in self._cameras.values() if c.enabled)
            return {
                'total': len(self._cameras),
                'enabled': enabled,
                'disabled': len(self._cameras) - enabled
            }